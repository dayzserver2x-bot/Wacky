# v8 — Display Names, Profile Icons, Paged Leaderboard
- All embeds use Discord **display names** (global display names)
- /factory shows your **profile icon** as the embed thumbnail
- /leaderboard is **paged** and shows the page leader's icon
- New `/profile [@user]` command: shows a player's stats with their avatar
Includes: infinite tiers, upgrades, items shop, prestige, crafting, interactive UI.
