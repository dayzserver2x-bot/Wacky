import discord
from discord.ext import tasks
from discord import app_commands
import json
import os
import traceback
from dotenv import load_dotenv
import asyncio
import cogs.automation
from cogs import lab
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")

ERROR_LOG_CHANNEL = 1437865546891788369

# -----------------------------
#    ORIGINAL BOT CLASS
# -----------------------------
intents = discord.Intents.default()
intents.message_content = True

class FactoryBot(discord.Client):
    def __init__(self):
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        # sync slash commands
        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

    async def on_ready(self):
        print(f"Bot online as {self.user}")
        await self.tree.sync()
        print("Slash commands synced.")

        # -------------------------------------------------------------
        # START MACHINE TICK LOOP
        # -------------------------------------------------------------
        try:
            from cogs import machines

            if hasattr(machines, "machine_tick"):
                if not machines.machine_tick.is_running():
                    machines.machine_tick.start()
                    print("✅ machine_tick loop started.")
                else:
                    print("ℹ️ machine_tick loop already running.")
            else:
                print("⚠️ machine_tick not found in cogs.machines")
        except Exception as e:
            print("❌ Could not start machine_tick loop:", e)

        # -------------------------------------------------------------
        # START FACTORY LOOPS (passive + worker pay)
        # -------------------------------------------------------------
        try:
            import cogs.factory_tiers as factory_tiers

            # passive_income loop (prestige / craft_discount only now)
            if hasattr(factory_tiers, "passive_income"):
                if not factory_tiers.passive_income.is_running():
                    factory_tiers.passive_income.start()
                    print("✅ passive_income loop started.")
                else:
                    print("ℹ️ passive_income loop already running.")
            else:
                print("⚠️ passive_income not found in factory_tiers.")

            # worker salary loop
            if hasattr(factory_tiers, "worker_pay_loop"):
                if not factory_tiers.worker_pay_loop.is_running():
                    factory_tiers.worker_pay_loop.start()
                    print("✅ worker_pay_loop started (worker salary).")
                else:
                    print("ℹ️ worker_pay_loop already running.")
            else:
                print("⚠️ worker_pay_loop not found in factory_tiers.")
        except Exception as e:
            print("❌ Could not start factory loops:", e)


client = FactoryBot()

# ----------------------------
# Load players + migration
# ----------------------------
DATA_FILE = "players.json"

def load_players():
    # If file doesn’t exist or is empty, start with an empty dict
    if not os.path.exists(DATA_FILE) or os.path.getsize(DATA_FILE) == 0:
        print("players.json missing or empty, starting with fresh data.")
        return {}

    with open(DATA_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            # File exists but is not valid JSON
            print("Warning: players.json is invalid JSON, resetting it to empty {}.")
            return {}

players = load_players()

# migrate workers format
for uid, p in players.items():
    if isinstance(p.get("workers"), int):
        count = p["workers"]
        p["workers"] = {
            "money": count,
            "machine": 0,
            "craft": 0,
            "prestige": 0,
            "storage": 0
        }

def save_data():
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(players, f, indent=4)

# write back migrated / cleaned data on startup
save_data()


def ensure_player(uid):
    return uid in players and "factory_name" in players[uid]


# ----------------------------
# Your original 12 setup functions
# ----------------------------
from cogs.economy import setup as economy_setup
from cogs.factory_tiers import setup as tier_setup
from cogs.upgrades import setup as upgrades_setup
from cogs.items import setup as items_setup
from cogs.prestige import setup as prestige_setup
from cogs.crafting import setup as crafting_setup
from cogs.ui import setup as ui_setup
from cogs.leaderboard import setup as leaderboard_setup
from cogs.profile import setup as profile_setup
from cogs.machines import setup as machines_setup
from cogs.shipping_center import setup as shipping_setup
from cogs.automation import setup as automation_setup
from cogs.maintenance import setup as maintenance_setup
from cogs.feedback import setup as feedback_setup
from cogs.devpanel import setup as devpanel_setup
from cogs.starter_guide import setup as starter_guide_setup
from cogs.tutorial import setup as tutorial_setup
from cogs.crafting_extended import setup as crafting_extended_setup
from cogs.daily import setup as daily_setup
from cogs.daily import claim_daily_core
from cogs.token_shop import setup as token_shop_setup
from cogs.contracts import setup as contracts_setup
from cogs.npc_orders import setup as npc_orders_setup
from cogs.build import setup as build_setup

# load all cogs normally
economy_setup(client, players, save_data, ensure_player)
tier_setup(client, players, save_data, ensure_player)
upgrades_setup(client, players, save_data, ensure_player)
items_setup(client, players, save_data, ensure_player)
prestige_setup(client, players, save_data, ensure_player)
crafting_setup(client, players, save_data, ensure_player)
ui_setup(client, players, save_data, ensure_player)
leaderboard_setup(client, players, save_data, ensure_player)
profile_setup(client, players, save_data, ensure_player)
machines_setup(client, players, save_data, ensure_player)
maintenance_setup(client, players, save_data, ensure_player)
shipping_setup(client, players, save_data, ensure_player)
starter_guide_setup(client, players, save_data, ensure_player)
tutorial_setup(client, players, save_data, ensure_player)
crafting_extended_setup(client, players, save_data, ensure_player)
contracts_setup(client, players, save_data, ensure_player)  

devpanel_setup(client, players, save_data, ensure_player)
npc_orders_setup(client, players, save_data, ensure_player)

automation_setup(client, players, save_data, ensure_player)
daily_setup(client, players, save_data, ensure_player) 
build_setup(client, players, save_data, ensure_player)

# plug in Research Lab
lab.setup(client, players, save_data, ensure_player)
# feedback stays manual
feedback_setup(client)
token_shop_setup(client, players, save_data, ensure_player)


# -----------------------------
# Error logging
# -----------------------------
@client.event
async def on_error(event, *args, **kwargs):
    channel = client.get_channel(ERROR_LOG_CHANNEL)
    if channel:
        formatted_error = traceback.format_exc()
        await channel.send(
            f"⚠️ **Global Error in `{event}`**\n```py\n{formatted_error}\n```"
        )


@client.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    """
    Global error handler for slash commands. Logs all uncaught errors.
    """
    try:
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "❌ An unexpected error occurred while processing that command.",
                ephemeral=True,
            )
        else:
            await interaction.followup.send(
                "❌ An unexpected error occurred while processing that command.",
                ephemeral=True,
            )
    except Exception:
        pass

    channel = client.get_channel(ERROR_LOG_CHANNEL)
    if channel:
        formatted_error = "".join(traceback.TracebackException.from_exception(error).format())
        await channel.send(
            f"⚠️ **Slash Command Error**\n"
            f"User: {interaction.user.mention} (`{interaction.user.id}`)\n"
            f"Command: `{interaction.command}`\n"
            f"Channel: {interaction.channel.mention if interaction.channel else 'DM or unknown'}\n"
            f"```py\n{formatted_error}\n```"
        )


# -----------------------------
# Status command (if you had one)
# -----------------------------
@client.tree.command(name="system_status", description="Developer: check core system wiring.")
@app_commands.default_permissions(administrator=True)
async def system_status(interaction: discord.Interaction):
    from cogs import machines

    errors = []
    ok = True

    # Basic checks
    if client.user is None:
        ok = False
        errors.append("❌ Bot user is None?")
    else:
        errors.append(f"✅ Logged in as {client.user} (`{client.user.id}`)")

    players_count = len(players)
    if players_count == 0:
        ok = False
        errors.append("⚠️ No player data loaded")
    else:
        errors.append(f"👥 {players_count} player profiles loaded")

    if machines.players_ref is None or machines.save_data_ref is None:
        ok = False
        errors.append("⚠️ Machine system references not initialized")
    else:
        errors.append("✅ Machines references loaded")

    color = discord.Color.green() if ok else discord.Color.red()
    embed = discord.Embed(title="🧭 Wacky Factory System Status", color=color)
    embed.description = "\n".join(errors)
    await interaction.response.send_message(embed=embed, ephemeral=False)


@client.event
async def on_interaction(interaction: discord.Interaction):
    data = interaction.data or {}

    # Route tutorial buttons (custom_id starts with tut_)
    if interaction.type.name == "component":
        cid = data.get("custom_id", "")
        if isinstance(cid, str) and cid.startswith("tut_"):
            from cogs.tutorial import tutorial_button_handler
            await tutorial_button_handler(interaction)
            return

    # Debug logging
    print("DEBUG INTERACTION:", data)


# run bot
if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN missing in .env")

client.run(TOKEN)
