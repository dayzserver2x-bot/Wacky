import discord
import random
import time
from discord import app_commands, Interaction
from discord.ui import View, Button, Select

# Try to pull real items from your crafting system
try:
    from cogs.crafting import RECIPES
    CONTRACT_ITEMS = list(RECIPES.keys())
except Exception:
    # Fallback if crafting isn't available for some reason
    CONTRACT_ITEMS = [
        "Planks", "Glass", "Scrap Metal", "Circuit Board",
        "Servo Motor", "Gear Assembly", "Logic Core", "AI Module"
    ]

# 🔹 NEW: Starter-friendly items list (for low-tier players)
STARTER_ITEMS = {
    "Planks",
    "Glass",
    "Scrap Metal",
    "Circuit Board",
    "Servo Motor",
    "Gear Assembly",
    # you can add more very-basic things here if you want:
    # "Charcoal", "Iron Plate", "Copper Wire", ...
}

CONTRACT_LIFETIME = 3 * 60 * 60  # 3 hours


def ensure_contract_schema(p: dict):
    """Make sure the player has the fields we need."""
    p.setdefault("contracts", [])
    p.setdefault("contracts_last_refresh", 0)
    p.setdefault("contracts_next_id", 1)
    p.setdefault("wacky_tokens", 0)  # just in case


def _generate_one_contract(p: dict) -> dict:
    """Create a single contract dict for this player."""
    tier = max(1, p.get("tier", 1))

    # 🔹 NEW: pick from starter-only pool for low tiers
    if CONTRACT_ITEMS:
        if tier <= 2:
            # Try to filter to starter items only
            pool = [name for name in CONTRACT_ITEMS if name in STARTER_ITEMS]
            # If somehow none of the starter names exist in RECIPES,
            # fall back to the full list so it never crashes.
            if not pool:
                pool = CONTRACT_ITEMS
        else:
            # Higher tiers can use the full contract item list
            pool = CONTRACT_ITEMS
        item = random.choice(pool)
    else:
        # Absolute fallback if nothing is configured
        item = "Planks"

    # Amount scales a bit with tier
    min_amt = 5 * tier
    max_amt = 15 * tier
    amount = random.randint(min_amt, max_amt)

    # Money reward roughly scales with tier & amount
    base_value = 150 * tier
    reward_money = base_value * (amount // 5)

    # Occasionally give a token
    if amount >= 20 or tier >= 3:
        reward_tokens = random.choice([0, 1, 1])  # 2/3 chance of 1 token
    else:
        reward_tokens = 0

    now = int(time.time())
    cid = p.get("contracts_next_id", 1)
    p["contracts_next_id"] = cid + 1

    return {
        "id": cid,
        "item": item,
        "amount": amount,
        "reward_money": reward_money,
        "reward_tokens": reward_tokens,
        "created_at": now,
        "expires_at": now + CONTRACT_LIFETIME,
        "fulfilled": False,
    }


def refresh_contracts_if_needed(p: dict, force: bool = False):
    """
    If contracts are old/empty, generate a new batch.
    Keeps old completed ones in the history, but only shows active ones.
    """
    ensure_contract_schema(p)
    now = int(time.time())

    # Cleanup expired contracts
    new_list = []
    for c in p["contracts"]:
        if c.get("expires_at", 0) > now or c.get("fulfilled"):
            new_list.append(c)
    p["contracts"] = new_list

    # Decide if we need to refresh
    last = p.get("contracts_last_refresh", 0)
    active = [c for c in p["contracts"] if not c.get("fulfilled") and c.get("expires_at", 0) > now]

    if force or not active or (now - last) > CONTRACT_LIFETIME:
        # Generate 3 new contracts
        for _ in range(3):
            p["contracts"].append(_generate_one_contract(p))
        p["contracts_last_refresh"] = now


def get_visible_contracts(p: dict):
    now = int(time.time())
    ensure_contract_schema(p)
    return [c for c in p["contracts"] if c.get("expires_at", 0) > now]


def format_time_remaining(seconds: int) -> str:
    if seconds <= 0:
        return "Expired"
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    parts = []
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    if not parts:
        parts.append(f"{s}s")
    return " ".join(parts)


def build_contracts_embed(user: discord.User, p: dict) -> discord.Embed:
    now = int(time.time())
    tokens = p.get("wacky_tokens", 0)

    embed = discord.Embed(
        title="📜 Contracts Board",
        description=(
            f"Complete contracts by delivering items from your inventory.\n"
            f"You currently have **{tokens}** 🔹 Wacky Tokens.\n\n"
            "Select a contract from the dropdown and click **Deliver** to turn it in."
        ),
        color=discord.Color.orange()
    )

    contracts = get_visible_contracts(p)
    if not contracts:
        embed.add_field(
            name="No contracts available",
            value="Check back later for new opportunities.",
            inline=False
        )
        return embed

    for c in contracts:
        remaining = c.get("expires_at", 0) - now
        time_str = format_time_remaining(remaining)
        status = "✅ Completed" if c.get("fulfilled") else "🟡 Available"

        line = (
            f"**Item:** {c['item']} ×{c['amount']}\n"
            f"**Reward:** ${c['reward_money']:,}"
        )
        if c.get("reward_tokens", 0):
            line += f" + {c['reward_tokens']} 🔹"

        line += f"\n**Expires in:** {time_str}\n**Status:** {status}"

        embed.add_field(
            name=f"Contract #{c['id']}",
            value=line,
            inline=False
        )

    embed.set_footer(text=f"Requested by {user.display_name}")
    return embed


class ContractSelect(Select):
    def __init__(self, parent_view: "ContractsView", p: dict):
        self.parent_view = parent_view
        contracts = get_visible_contracts(p)

        options = []
        for c in contracts:
            label = f"#{c['id']} • {c['item']} ×{c['amount']}"
            desc = f"${c['reward_money']:,}"
            if c.get("reward_tokens", 0):
                desc += f" + {c['reward_tokens']} 🔹"

            options.append(discord.SelectOption(
                label=label,
                value=str(c["id"]),
                description=desc[:100]
            ))

        if not options:
            options = [discord.SelectOption(
                label="No contracts available",
                value="none",
                description="Come back later!"
            )]

        super().__init__(
            placeholder="Select a contract to focus...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: Interaction):
        value = self.values[0]
        if value == "none":
            return await interaction.response.send_message(
                "There are no active contracts right now.",
                ephemeral=True
            )

        self.parent_view.selected_id = int(value)
        await interaction.response.send_message(
            f"📌 Selected contract **#{value}**. Now click **Deliver** to turn it in (if you have the items).",
            ephemeral=True
        )


class DeliverButton(Button):
    def __init__(self, parent_view: "ContractsView"):
        super().__init__(
            label="Deliver 📦",
            style=discord.ButtonStyle.success
        )
        self.parent_view = parent_view

    async def callback(self, interaction: Interaction):
        uid = self.parent_view.uid
        players = self.parent_view.players
        save_data = self.parent_view.save_data

        p = players.get(uid)
        if not p:
            return await interaction.response.send_message(
                "Could not load your player data. Try again.",
                ephemeral=True
            )

        if self.parent_view.selected_id is None:
            return await interaction.response.send_message(
                "Select a contract from the dropdown first.",
                ephemeral=True
            )

        ensure_contract_schema(p)
        now = int(time.time())
        contract_id = self.parent_view.selected_id

        # Find the contract
        contract = None
        for c in p["contracts"]:
            if c.get("id") == contract_id:
                contract = c
                break

        if not contract:
            return await interaction.response.send_message(
                "That contract no longer exists. Try refreshing.",
                ephemeral=True
            )

        if contract.get("fulfilled"):
            return await interaction.response.send_message(
                "That contract is already completed.",
                ephemeral=True
            )

        if contract.get("expires_at", 0) <= now:
            return await interaction.response.send_message(
                "That contract has expired. Wait for new ones.",
                ephemeral=True
            )

        # Check inventory
        inv = p.setdefault("inventory", {})
        item = contract["item"]
        amount = contract["amount"]

        if inv.get(item, 0) < amount:
            return await interaction.response.send_message(
                f"❌ You don't have enough **{item}**.\n"
                f"Required: {amount}, You have: {inv.get(item, 0)}",
                ephemeral=True
            )

        # Pay out
        inv[item] -= amount
        if inv[item] <= 0:
            inv.pop(item, None)

        money = contract.get("reward_money", 0)
        tokens = contract.get("reward_tokens", 0)
        p["money"] = p.get("money", 0) + money
        p["wacky_tokens"] = p.get("wacky_tokens", 0) + tokens

        contract["fulfilled"] = True
        save_data()

        # Update board
        embed = build_contracts_embed(interaction.user, p)
        await interaction.response.edit_message(embed=embed, view=self.parent_view)

        reward_line = f"✅ Contract #{contract_id} completed!\n💵 +${money:,}"
        if tokens:
            reward_line += f"\n🔹 +{tokens} Wacky Token(s)"

        await interaction.followup.send(reward_line, ephemeral=True)


class RefreshContractsButton(Button):
    def __init__(self, parent_view: "ContractsView"):
        super().__init__(
            label="Refresh 🔄",
            style=discord.ButtonStyle.secondary
        )
        self.parent_view = parent_view

    async def callback(self, interaction: Interaction):
        uid = self.parent_view.uid
        players = self.parent_view.players
        save_data = self.parent_view.save_data

        p = players.get(uid)
        if not p:
            return await interaction.response.send_message(
                "Could not load your player data.",
                ephemeral=True
            )

        # For now, free refresh (you can later charge tokens)
        refresh_contracts_if_needed(p, force=True)
        save_data()

        embed = build_contracts_embed(interaction.user, p)
        self.parent_view.selected_id = None
        await interaction.response.edit_message(embed=embed, view=self.parent_view)
        await interaction.followup.send("🔄 Contracts refreshed!", ephemeral=True)


class ContractsView(View):
    def __init__(self, uid: str, players: dict, save_data):
        super().__init__(timeout=180)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.selected_id = None

        p = players.get(uid, {})
        ensure_contract_schema(p)

        # Components
        self.add_item(ContractSelect(self, p))
        self.add_item(DeliverButton(self))
        self.add_item(RefreshContractsButton(self))

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.uid)


def setup(client, players, save_data, ensure_player):
    @client.tree.command(name="contracts", description="View and complete factory contracts for rewards.")
    async def contracts_cmd(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first to create your factory.",
                ephemeral=True
            )

        p = players[uid]
        ensure_contract_schema(p)
        refresh_contracts_if_needed(p)
        save_data()

        embed = build_contracts_embed(interaction.user, p)
        view = ContractsView(uid, players, save_data)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=False)
