# cogs/world_data.py

LOCATIONS = {
    # ---------- EARTH BIOMES ----------
    "Grasslands": {
        "kind": "earth",
        "tier_req": 1,
        "cost": 0,  # spawn / starting area
        "desc": "Balanced production rates and easy access to basic resources.",
        "bonus": {"Wood": 1.2, "Stone": 1.1},
        "mine_table": {
            "Wood": 50,
            "Stone": 30,
            "Coal": 20,
        },
    },
    "Desert": {
        "kind": "earth",
        "tier_req": 1,
        "cost": 2500,
        "desc": "Abundant Sand and Coal, but less Water and Wood.",
        "bonus": {"Sand": 1.5, "Coal": 1.3, "Water": 0.7, "Wood": 0.5},
        "mine_table": {
            "Sand": 60,
            "Coal": 30,
            "Glass Shards": 10,
        },
    },
    "Forest": {
        "kind": "earth",
        "tier_req": 1,
        "cost": 4000,
        "desc": "High Wood and Resin output, slower metal refining.",
        "bonus": {"Wood": 2.0, "Resin": 1.5, "Refined Copper": 0.8},
        "mine_table": {
            "Wood": 65,
            "Resin": 25,
            "Mushrooms": 10,
        },
    },
    "Mountain": {
        "kind": "earth",
        "tier_req": 2,
        "cost": 6000,
        "desc": "Rich in metals, but energy costs increase.",
        "bonus": {"Iron Ore": 1.6, "Scrap Metal": 1.4, "fuel_efficiency": 0.8},
        "mine_table": {
            "Iron Ore": 55,
            "Stone": 30,
            "Crystal Shard": 15,
        },
    },
    "Coastline": {
        "kind": "earth",
        "tier_req": 2,
        "cost": 8000,
        "desc": "Water-based resources thrive; increased oil refining output.",
        "bonus": {"Water": 2.0, "Refined Oil": 1.3},
        "mine_table": {
            "Water": 50,
            "Fish": 30,
            "Crude Oil Barrel": 20,
        },
    },

    # ---------- SPACE STAGE ----------
    "Earth Orbit": {
        "kind": "space",
        "tier_req": 3,
        "cost": 12000,
        "desc": "Gateway to off-world industry. Basic orbital mining routes.",
        "bonus": {"fuel_efficiency": 1.1, "Scrap Metal": 1.2},
        "mine_table": {
            "Space Scrap": 50,
            "Scrap Metal": 30,
            "Iron Ore": 20,
        },
    },
    "Luna Base": {
        "kind": "space",
        "tier_req": 3,
        "cost": 18000,
        "desc": "Moon outpost with good stone and rare dust.",
        "bonus": {"Stone": 1.4, "Crystal Shard": 1.2},
        "mine_table": {
            "Stone": 50,
            "Crystal Shard": 25,
            "Lunar Dust": 25,
        },
    },
    "Mars Outpost": {
        "kind": "space",
        "tier_req": 4,
        "cost": 25000,
        "desc": "Harsh but rich in metals and exotic dust.",
        "bonus": {"Iron Ore": 1.8, "Carbon Alloy": 1.2},
        "mine_table": {
            "Iron Ore": 60,
            "Carbon Dust": 25,
            "Martian Rock": 15,
        },
    },
    "Asteroid Belt": {
        "kind": "space",
        "tier_req": 4,
        "cost": 30000,
        "desc": "High-risk, high-reward mining of dense ores.",
        "bonus": {"Refined Copper": 1.4, "Quantum Chip": 1.1},
        "mine_table": {
            "Iron Ore": 30,
            "Refined Copper": 30,
            "Rare Ore Chunk": 40,
        },
    },
    "Titan Station": {
        "kind": "space",
        "tier_req": 5,
        "cost": 40000,
        "desc": "Late-game hub for advanced tech and exotic fuels.",
        "bonus": {"Refined Oil": 1.5, "Quantum Chip": 1.3},
        "mine_table": {
            "Refined Oil": 40,
            "Nanoplastic": 30,
            "Quantum Chip": 30,
        },
    },
}

# ---------- DERIVED REGION CONFIG FOR TRAVEL / MINING / HAZARDS ----------

REGIONS = {}

for _name, _data in LOCATIONS.items():
    kind = _data.get("kind", "earth")
    tier_req = _data.get("tier_req", 1)

    # Fuel + hazard tuned by kind and tier
    if kind == "earth":
        # Grasslands free, others a bit fuel
        base_fuel = 0 if _name == "Grasslands" else 2
        fuel_cost = base_fuel + max(0, (tier_req - 1) * 2)
        hazard = 0.03 + 0.02 * max(0, tier_req - 1)  # ~3–7%
    else:  # space
        base_fuel = 10
        fuel_cost = base_fuel + max(0, (tier_req - 3) * 4)
        hazard = 0.12 + 0.03 * max(0, tier_req - 3)  # ~12–21%

    REGIONS[_name] = {
        "kind": kind,
        "tier_req": tier_req,
        "fuel_cost": fuel_cost,
        "hazard_chance": hazard,
        "env_bonuses": _data.get("bonus", {}),
        # Which item names can be mined here (used by mining logic)
        "allowed_items": set(_data.get("mine_table", {}).keys()),
    }
