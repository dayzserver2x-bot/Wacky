import discord
from discord import app_commands, Interaction
from cogs.factory_tiers import WORKER_PAY_PER_HOUR  # NEW


def setup(client, players, save_data, ensure_player):

    @client.tree.command(
        name="profile",
        description="Show your factory profile with your Discord display name & avatar."
    )
    async def profile(interaction: Interaction, user: discord.User | None = None):
        target = user or interaction.user
        uid = str(target.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("That user hasn't started a factory yet.")

        p = players[uid]

        # ---- Workers: X total and Y per hour ----
        w = p.get("workers", 0)
        if isinstance(w, dict):
            total_workers = sum(int(v) for v in w.values())
        else:
            total_workers = int(w) if w else 0

        hourly_income = total_workers * WORKER_PAY_PER_HOUR

        embed = discord.Embed(
            title=f"{target.display_name} — {p['factory_name']}",
            description=(
                f"**Tier:** {p['tier']}  •  **Prestige:** {p.get('prestige', 0)} "
                f"(x{p.get('prestige_mult', 1.0):.2f})\n"
                f"**Money:** ${p['money']}\n"
                f"**Production:** {p['production']}\n"
                f"**Workers:** {total_workers} → **${hourly_income}** per hour"
            ),
            color=discord.Color.blurple()
        )

        if hasattr(target.display_avatar, "url"):
            embed.set_thumbnail(url=target.display_avatar.url)

        inv = p.get("inventory", {})
        inv_text = ", ".join([f"{k}×{v}" for k, v in inv.items()]) or "None"
        embed.add_field(name="Inventory", value=inv_text, inline=False)

        upgrades = ", ".join(p.get("owned_upgrades", [])) or "None"
        embed.add_field(name="Upgrades", value=upgrades, inline=False)

        await interaction.response.send_message(embed=embed)
