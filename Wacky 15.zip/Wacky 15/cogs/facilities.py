# cogs/facilities.py

import discord
import random

from discord import Interaction
from discord.ui import View, Button

# ✅ For type checking of FactoryView without causing circular imports
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from cogs.ui import FactoryView

# We reuse helpers / constants from your main UI cog
from cogs.ui import BackToFactoryButton, worker_cost, BASE_CAPACITY


class FacilitiesView(View):
    """Top-level facilities hub opened from the Factory view."""
    LAB_COST_MONEY = 5000
    LAB_COST_ITEMS = {
        "Scrap Metal": 100,
        "Copper Wire": 50,
    }

    SHIPPING_CENTER_COST_MONEY = 25000  # Keep in sync with SC_COST in shipping_center.py

    def __init__(self, factory_view: "FactoryView"):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players

        # Buttons
        self.add_item(self.ResearchLabButton(self))
        self.add_item(self.StorageWarehouseButton(self))
        self.add_item(self.LogisticsHubButton(self))
        self.add_item(BackToFactoryButton(factory_view))

    def get_embed(self, user):
        """Main embed for the Facilities hub."""
        p = self.players.get(self.uid, {})
        facilities_desc = []

        # Research Lab status
        if p.get("research_lab_built"):
            facilities_desc.append("🧪 **Research Lab** – Built")
        else:
            facilities_desc.append(
                f"🧪 **Research Lab** – Not built (Cost: ${self.LAB_COST_MONEY:,} + items)"
            )

        # Storage Warehouse status
        storage_lv = p.get("workers", {}).get("storage", 0)
        base = BASE_CAPACITY
        capacity = base + storage_lv * 200
        facilities_desc.append(
            f"📦 **Storage Warehouse** – {storage_lv} workers, capacity {capacity}"
        )

        # Shipping Center status
        if p.get("shipping_center_unlocked"):
            facilities_desc.append("🚚 **Logistics Hub / Shipping Center** – Unlocked")
        else:
            facilities_desc.append(
                f"🚚 **Logistics Hub / Shipping Center** – Locked "
                f"(Build Shipping Center first, cost: ${self.SHIPPING_CENTER_COST_MONEY:,})"
            )

        embed = discord.Embed(
            title="🏗️ Factory Facilities",
            description="\n".join(facilities_desc),
            color=discord.Color.gold()
        )
        embed.set_footer(text="Manage your advanced factory infrastructure here.")
        return embed

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.uid)

    # ---------------- RESEARCH LAB ----------------

    class ResearchLabButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="Research Lab 🧪",
                style=discord.ButtonStyle.secondary
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            uid = self.parent_view.uid
            players = self.parent_view.players
            p = players.setdefault(uid, {})

            # If the lab is not built yet, show a build-confirmation view
            if not p.get("research_lab_built"):
                # Make a temporary view that just holds the confirm button
                build_view = View(timeout=180)
                build_view.add_item(FacilitiesView.BuildResearchLabButton(self.parent_view))

                embed = discord.Embed(
                    title="Build Research Lab?",
                    description=(
                        "Construct the **Research Lab** to unlock special recipes like Rocket Fuel.\n\n"
                        f"Cost: **${FacilitiesView.LAB_COST_MONEY:,}** plus:\n"
                        f"- Scrap Metal ×{FacilitiesView.LAB_COST_ITEMS['Scrap Metal']}\n"
                        f"- Copper Wire ×{FacilitiesView.LAB_COST_ITEMS['Copper Wire']}\n"
                    ),
                    color=discord.Color.orange()
                )
                await interaction.response.edit_message(embed=embed, view=build_view)
                return

            # If lab is already built, open the actual lab view
            lab = ResearchLabView(self.parent_view.factory_view)
            embed = lab.get_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=lab)



    class BuildResearchLabButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="Confirm Build Research Lab",
                style=discord.ButtonStyle.success
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            uid = self.parent_view.uid
            players = self.parent_view.players
            p = players.setdefault(uid, {})
            inv = p.setdefault("inventory", {})

            missing = []
            if inv.get("Scrap Metal", 0) < FacilitiesView.LAB_COST_ITEMS["Scrap Metal"]:
                missing.append(f"Scrap Metal ×{FacilitiesView.LAB_COST_ITEMS['Scrap Metal']}")
            if inv.get("Copper Wire", 0) < FacilitiesView.LAB_COST_ITEMS["Copper Wire"]:
                missing.append(f"Copper Wire ×{FacilitiesView.LAB_COST_ITEMS['Copper Wire']}")

            if p.get("money", 0) < FacilitiesView.LAB_COST_MONEY:
                missing.append(f"${FacilitiesView.LAB_COST_MONEY:,} in money")

            if missing:
                return await interaction.response.send_message(
                    "❌ You don't have enough resources to build the Research Lab:\n"
                    + "\n".join(f"- {m}" for m in missing),
                    ephemeral=False
                )

            # Pay costs
            p["money"] -= FacilitiesView.LAB_COST_MONEY
            inv["Scrap Metal"] -= FacilitiesView.LAB_COST_ITEMS["Scrap Metal"]
            inv["Copper Wire"] -= FacilitiesView.LAB_COST_ITEMS["Copper Wire"]

            p["research_lab_built"] = True
            self.parent_view.factory_view.save_data()

            lab = ResearchLabView(self.parent_view.factory_view)
            embed = lab.get_embed(interaction.user)
            await interaction.response.edit_message(
                content="✅ Research Lab constructed!",
                embed=embed,
                view=lab
            )

    # ---------------- STORAGE WAREHOUSE ----------------

    class StorageWarehouseButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="Storage Warehouse 📦",
                style=discord.ButtonStyle.secondary
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            warehouse = StorageWarehouseView(self.parent_view.factory_view)
            embed = warehouse.get_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=warehouse)

    class LogisticsHubButton(Button):
            def __init__(self, parent):
                super().__init__(
                    label="Logistics Hub 🚚",
                    style=discord.ButtonStyle.secondary
                )
                self.parent_view = parent

            async def callback(self, interaction: Interaction):
                # Import Shipping Center helpers (exported in its setup)
                from cogs import shipping_center

                uid = self.parent_view.uid
                players = self.parent_view.players
                p = players.setdefault(uid, {})

                # Ensure basic schema keys exist (mirrors shipping_center.ensure_schema)
                p.setdefault("shipping_center_owned", False)
                p.setdefault("shipping_center_unlocked", False)
                p.setdefault("shipping_orders", [])
                p.setdefault("accepted_order", None)
                p.setdefault("workers", p.get("workers", {}))

                # Gate access if they haven't bought the center yet
                if not p.get("shipping_center_unlocked"):
                    embed = discord.Embed(
                        title="Logistics Hub Locked",
                        description=(
                            "You need to **buy the Shipping Center** using `/shippingcenter` "
                            "before you can access the Logistics Hub.\n\n"
                            f"Cost: **${shipping_center.SC_COST:,}**"
                        ),
                        color=discord.Color.red()
                    )
                    await interaction.response.edit_message(embed=embed, view=self.parent_view)
                    return

                # Use helpers exported by shipping_center.setup
                try:
                    build_orders_embed = shipping_center.build_orders_embed
                    SCBoardView = shipping_center.SCBoardView
                except AttributeError:
                    # Shipping Center cog not initialized correctly
                    embed = discord.Embed(
                        title="Shipping Center Error",
                        description="The Shipping Center module is not initialized. Please try again later.",
                        color=discord.Color.red()
                    )
                    await interaction.response.edit_message(embed=embed, view=self.parent_view)
                    return

                embed = build_orders_embed(uid)
                view = SCBoardView(uid, locked=False)
                await interaction.response.edit_message(embed=embed, view=view)



class ResearchLabView(View):
    """Research Lab for special crafting-only items like Rocket Fuel."""
    def __init__(self, factory_view: "FactoryView"):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players

        self.add_item(self.CraftRocketFuelButton(self))
        self.add_item(self.BackToFacilitiesButton(self))
        self.add_item(BackToFactoryButton(factory_view))

    def get_embed(self, user):
        p = self.players.get(self.uid, {})
        inv = p.get("inventory", {})

        rocket_fuel = inv.get("Rocket Fuel", 0)
        scrap = inv.get("Scrap Metal", 0)
        oil = inv.get("Barrel of Oil", 0)
        catalysts = inv.get("Chemical Catalyst", 0)

        embed = discord.Embed(
            title="🧪 Research Lab",
            description=(
                "Welcome to the Research Lab! Here you can craft advanced items like **Rocket Fuel**.\n\n"
                "Current Rocket Fuel stock: **{rocket_fuel}**\n"
                "Recipe (example):\n"
                "- Scrap Metal ×10\n"
                "- Barrel of Oil ×5\n"
                "- Chemical Catalyst ×1\n"
            ).format(
                rocket_fuel=rocket_fuel
            ),
            color=discord.Color.purple()
        )
        return embed

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.uid)

    class CraftRocketFuelButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="Craft Rocket Fuel",
                style=discord.ButtonStyle.success
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            uid = self.parent_view.uid
            players = self.parent_view.players
            p = players.setdefault(uid, {})
            inv = p.setdefault("inventory", {})

            # Example costs
            needed = {
                "Scrap Metal": 10,
                "Barrel of Oil": 5,
                "Chemical Catalyst": 1,
            }

            missing = []
            for item, amt in needed.items():
                if inv.get(item, 0) < amt:
                    missing.append(f"{item} ×{amt}")

            if missing:
                return await interaction.response.send_message(
                    "❌ You don't have enough materials to craft Rocket Fuel:\n"
                    + "\n".join(f"- {m}" for m in missing),
                    ephemeral=False
                )

            # Pay costs
            for item, amt in needed.items():
                inv[item] -= amt

            # Give Rocket Fuel
            inv["Rocket Fuel"] = inv.get("Rocket Fuel", 0) + 1

            self.parent_view.factory_view.save_data()

            embed = self.parent_view.get_embed(interaction.user)
            await interaction.response.edit_message(
                content="✅ Crafted **1 Rocket Fuel**!",
                embed=embed,
                view=self.parent_view
            )

    class BackToFacilitiesButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="⬅️ Back to Facilities",
                style=discord.ButtonStyle.secondary
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            facilities = FacilitiesView(self.parent_view.factory_view)
            embed = facilities.get_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=facilities)


class StorageWarehouseView(View):
    """Facility for managing storage workers & capacity."""
    def __init__(self, factory_view: "FactoryView"):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players

        self.add_item(self.HireStorageWorkerButton(self))
        self.add_item(self.BackToFacilitiesButton(self))
        self.add_item(BackToFactoryButton(factory_view))

    def get_embed(self, user):
        p = self.players.get(self.uid, {})
        workers = p.get("workers", {})
        storage_lv = workers.get("storage", 0)

        base = BASE_CAPACITY
        capacity = base + storage_lv * 200  # ✅ unified with main UI & economy

        embed = discord.Embed(
            title="📦 Storage Warehouse",
            description=(
                "Manage your storage workers.\n\n"
                f"• Storage Workers: **{storage_lv}**\n"
                f"• Capacity: **{capacity}** items (base {base} + 200 per worker)\n"
            ),
            color=discord.Color.gold()
        )
        return embed

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.uid)

    class HireStorageWorkerButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="Hire Storage Worker",
                style=discord.ButtonStyle.success
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            uid = self.parent_view.uid
            players = self.parent_view.players
            p = players.setdefault(uid, {})
            workers = p.setdefault("workers", {})
            storage_lv = workers.get("storage", 0)

            # ✅ fixed: correct worker_cost usage
            cost = worker_cost(p, "storage")

            if p.get("money", 0) < cost:
                return await interaction.response.send_message(
                    f"❌ You need **${cost:,}** to hire a Storage Worker. "
                    f"You only have **${p.get('money', 0):,}**.",
                    ephemeral=False
                )

            p["money"] -= cost
            workers["storage"] = storage_lv + 1

            self.parent_view.factory_view.save_data()

            embed = self.parent_view.get_embed(interaction.user)
            await interaction.response.edit_message(
                content=f"✅ Hired a Storage Worker for **${cost:,}**!",
                embed=embed,
                view=self.parent_view
            )

    class BackToFacilitiesButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="⬅️ Back to Facilities",
                style=discord.ButtonStyle.secondary
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            facilities = FacilitiesView(self.parent_view.factory_view)
            embed = facilities.get_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=facilities)


# optional no-op setup so your loader doesn't yell
def setup(client, players, save_data, ensure_player):
    # Facilities are driven from FactoryView's Facilities button in ui.py
    pass
