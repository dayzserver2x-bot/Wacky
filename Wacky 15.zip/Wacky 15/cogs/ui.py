import discord
import time
from cogs.daily import claim_daily_core
from cogs.factory_tiers import WORKER_PAY_PER_HOUR 
from cogs.npc_orders import RUSTY_MISSIONS, MAX_RUSTY_MISSION_STEP, get_rusty_progress

# Optional import so the UI can read the same items as /tokens_shop
try:
    from cogs.token_shop import COSMETIC_ITEMS as TOKEN_SHOP_ITEMS
except Exception:
    TOKEN_SHOP_ITEMS = {}

# Optional import so the UI can read the player market data (from cogs.market)
try:
    from cogs.market import market as PLAYER_MARKET
except Exception:
    PLAYER_MARKET = None


# ---------------- NORMALIZE MACHINE NAME ----------------
def normalize(name: str):
    """Normalize machine names so ownership comparisons always match."""
    return (
        str(name)
        .lower()
        .replace(" ", "_")
        .replace("-", "_")
        .strip()
    )

from discord import Interaction
from discord.ui import View, Button, Select, button

from cogs.machines import MachinePanel
from cogs.crafting import CraftMenu
from cogs.machine_data import MACHINES, MACHINE_DATA
from cogs.sell_ui import open_sell_menu
from cogs.world_data import LOCATIONS, REGIONS  # 🌍 import regions & locations

NEON_COLOR = discord.Color.teal()
AMBER_ORANGE = discord.Color.from_str("#FFB300")

FACTORY_EMOJIS = {1: "🔧", 2: "⚙️", 3: "🔥", 4: "🚀"}

BASE_WORKER_COST = {
    "money": 50,
    "machine": 100,
    "craft": 150,
    "prestige": 250,
    "storage": 120,
}
WORKER_GROWTH = 1.15
BASE_CAPACITY = 200


def worker_cost(p, kind: str) -> int:
    w = p.get("workers", {})
    count = w.get(kind, 0)
    base = BASE_WORKER_COST[kind]
    return int(round(base * (WORKER_GROWTH ** count)))
def add_tutorial_field(embed: discord.Embed, p: dict):
    """Attach a small 'Next Step' field based on tutorial_stage."""
    stage = int(p.get("tutorial_stage", 0) or 0)

    # Treat missing / 0 as step 1 so old saves get pulled into the tutorial
    if stage <= 0:
        stage = 1
        p["tutorial_stage"] = 1

    if stage == 1:
        embed.add_field(
            name="⭐ Tutorial — Step 1/3: Mine resources",
            value=(
                "**Goal:** Mine your first basic resources.\n\n"
                "1. Press **Mine ⛏️** below (this runs your starter machines).\n"
                "2. You can also explore **World 🌍** from the menu.\n"
                "3. Aim for at least: **5 Coal, 5 Wood, 5 Stone**."
            ),
            inline=False,
        )
    elif stage == 2:
        embed.add_field(
            name="⭐ Tutorial — Step 2/3: Craft an item",
            value=(
                "**Goal:** Craft your first item.\n\n"
                "1. Open **Craft 🧩** from the menu.\n"
                "2. Pick **Planks** or any simple Tier 1 recipe.\n"
                "3. Craft it once using the resources you mined.\n\n"
                "Doing this should advance the tutorial to contracts."
            ),
            inline=False,
        )
    elif stage == 3:
        embed.add_field(
            name="⭐ Tutorial — Step 3/3: Do a contract",
            value=(
                "**Goal:** Complete your first contract.\n\n"
                "1. Use the **Contracts 📜** button below.\n"
                "2. Accept an easy starter contract (Planks/Glass/etc).\n"
                "3. Mine and craft until you have the items, then **Deliver**.\n\n"
                "Finishing one contract completes the tutorial!"
            ),
            inline=False,
        )
    # stage >= 4 → no tutorial field (normal mode)

def fmt_embed(user, p):
    icon = FACTORY_EMOJIS.get(min(p.get("tier", 1), 4), "🏭")
    w = p.setdefault("workers", {"money": 0, "machine": 0, "craft": 0, "prestige": 0, "storage": 0})
    capacity = BASE_CAPACITY + w.get("storage", 0) * 200
    inv_count = sum(p.get("inventory", {}).values())

    # total workers + hourly income using the shared constant
    total_workers = sum(int(v) for v in w.values())
    hourly_income = total_workers * WORKER_PAY_PER_HOUR

    # 🔹 pull cosmetics from player
    title = p.get("active_title") or "No title"
    theme = p.get("profile_theme", "default")
    badges = "".join(p.get("profile_badges", [])) or "None"

    embed = discord.Embed(
        title=f"{icon} {p.get('factory_name','Factory')} — Neon Control Panel",
        description=(
            f"**Owner:** {user.display_name}\n"
            f"**Title:** {title}\n"
            f"**Theme:** {theme}\n"
            f"**Badges:** {badges}\n"
            f"**Tier:** {p.get('tier', 1)}  •  **Prestige:** {p.get('prestige', 0)} "
            f"(x{p.get('prestige_mult', 1.0):.2f})\n"
            f"**Money:** ${p.get('money', 0)}\n"
            f"**Wacky Tokens:** {p.get('wacky_tokens', 0)} 🔹\n"
            f"**Daily Streak:** {p.get('daily_streak', 0)} days\n"
            f"**Location:** {p.get('location', 'Grasslands')}\n"
            f"**Production:** {p.get('production', 1)} /work\n"
            f"**Inventory:** {inv_count}/{capacity}\n\n"
            f"**Workers**\n"
            f"💵 {w.get('money',0)}  ⚙️ {w.get('machine',0)}  🧪 {w.get('craft',0)}  "
            f"🌟 {w.get('prestige',0)}  📦 {w.get('storage',0)}\n"
            f"Workers: {total_workers} → **${hourly_income}** per hour"
        ),
        color=NEON_COLOR
    )

    if hasattr(user.display_avatar, "url"):
        embed.set_thumbnail(url=user.display_avatar.url)

    embed.set_footer(text="Work: 15m cooldown • Use the menu below to manage factory features")
    return embed


# -------------------- NEW INVENTORY VIEW --------------------

class InventoryView(View):
    def __init__(self, parent, user):
        super().__init__(timeout=60)
        self.parent = parent
        self.user = user

    @button(label="⬅️ Back", style=discord.ButtonStyle.danger)
    async def back(self, interaction: Interaction, _):
        p = self.parent.players[self.parent.uid]
        await interaction.response.edit_message(
            embed=fmt_embed(interaction.user, p),
            view=self.parent
        )


# ---------------- COMMON BACK BUTTON ----------------

class BackToFactoryButton(Button):
    def __init__(self, parent_view):
        super().__init__(label="⬅️ Back to Factory", style=discord.ButtonStyle.secondary)
        self.parent_view = parent_view

    async def callback(self, interaction: Interaction):
        p = self.parent_view.players[self.parent_view.uid]
        await interaction.response.edit_message(
            embed=fmt_embed(interaction.user, p),
            view=self.parent_view
        )


# ---------------- MACHINE SHOP ----------------

class MachineConfirmView(View):
    def __init__(self, uid, players, save_data, machine, return_factory: "FactoryView"):
        super().__init__(timeout=60)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.machine = machine
        self.return_factory = return_factory  # 🔙 what we return to

    async def _back_to_factory(self, interaction: Interaction, message: str):
        """Return to the main FactoryView on this message."""
        p = self.players[self.uid]

        # 1) Turn this message back into the factory panel
        await interaction.response.edit_message(
            embed=fmt_embed(interaction.user, p),
            view=self.return_factory,
        )

        # 2) Send a small info line about what happened
        await interaction.followup.send(
            message,
            ephemeral=False,
            delete_after=60  # 👈 auto-delete after 60 seconds
        )


    @button(label="Buy Machine ✅", style=discord.ButtonStyle.success)
    async def buy(self, interaction: Interaction, _):
        p = self.players[self.uid]
        cost = MACHINES[self.machine]["buy"]

        if p["money"] < cost:
            return await self._back_to_factory(
                interaction,
                f"💸 Not enough money. You need **${cost:,}**.",
            )

        p["money"] -= cost
        p.setdefault("machines", {})
        # base state; extra fields (xp/durability) are injected in setup()
        p["machines"][self.machine] = {
            "level": 1,
            "running": False,
            "progress": 0,
        }
        self.save_data()

        await self._back_to_factory(
            interaction,
            f"✅ Bought **{self.machine}** successfully!",
        )

    @button(label="Cancel ❌", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: Interaction, _):
        await self._back_to_factory(interaction, "❌ Purchase cancelled.")




class MachineListSelect(Select):
    def __init__(self, uid, players, save_data, return_factory: "FactoryView"):
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.return_factory = return_factory

        p = players[uid]
        tier = p.get("tier", 1)

        # Only count machines with level > 0 as owned
        owned = {
            normalize(name)
            for name, data in p.get("machines", {}).items()
            if isinstance(data, dict) and data.get("level", 0) > 0
        }

        options = []
        for machine_id, data in MACHINES.items():
            normalized_id = normalize(machine_id)

            # Tier gate
            if data.get("min_tier", 1) > tier:
                continue

            # Output info
            out = MACHINE_DATA.get(machine_id, {}).get("output", {})
            item = next(iter(out.keys()), "?")
            qty = next(iter(out.values()), "?")
            price = data.get("buy", "?")

            if normalized_id in owned:
                options.append(discord.SelectOption(
                    label=f"{machine_id} (Owned)",
                    value=f"owned::{machine_id}",
                    description=f"Already purchased • Produces {qty}× {item}/cycle",
                    emoji="🔒"
                ))
            else:
                options.append(discord.SelectOption(
                    label=machine_id,
                    value=machine_id,
                    description=f"${price} • Produces {qty}× {item}/cycle"
                ))

        options = options[:25]
        if not options:
            options = [discord.SelectOption(label="No machines available", value="none")]

        super().__init__(placeholder="Select a machine…", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: Interaction):
        value = self.values[0]

        if value.startswith("owned::"):
            name = value.split("::", 1)[1]
            return await interaction.response.send_message(
                f"🔒 You already own **{name}**.",
                ephemeral=False
            )

        if value == "none":
            return await interaction.response.send_message("No machines available.", ephemeral=False)

        # Build a confirm embed on the SAME message
        price = MACHINES.get(value, {}).get("buy", 0)
        embed = discord.Embed(
            title="🏪 Machine Shop",
            description=f"Would you like to **buy {value}** for **${price:,}**?",
            color=discord.Color.gold()
        )
        confirm_view = MachineConfirmView(
            self.uid,
            self.players,
            self.save_data,
            value,
            self.return_factory,  # 🔙 pass factory view
        )
        await interaction.response.edit_message(embed=embed, view=confirm_view)



class MachineShopView(View):
    def __init__(self, uid, players, save_data, return_factory: "FactoryView"):
        super().__init__(timeout=120)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.return_factory = return_factory

        self.add_item(MachineListSelect(uid, players, save_data, return_factory))
        # Optional UX: visible back button
        self.add_item(BackToFactoryButton(return_factory))

    async def interaction_check(self, interaction):
        return str(interaction.user.id) == self.uid



# ---------------- MACHINE BROWSER (Tiered) ----------------

def build_machine_tier_map():
    """Dynamically builds tier groups from MACHINE_DATA tiers."""
    tiers = {}
    for name, data in MACHINE_DATA.items():
        tier = data.get("tier", 1)
        # Map tier numbers into 3 broad groups: 1–3, 4–6, 7–10
        if tier <= 3:
            key = "1-3"
        elif tier <= 6:
            key = "4-6"
        else:
            key = "7-10"

        tiers.setdefault(key, set()).add(name)
    return tiers


class MachineTierMenuView(View):
    def __init__(self, factory_view):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players
        self.map = build_machine_tier_map()

        self.add_item(self.TierButton(self, "1-3", 1, "Tier 1–3 🔩"))
        self.add_item(self.TierButton(self, "4-6", 4, "Tier 4–6 ⚙️"))
        self.add_item(self.TierButton(self, "7-10", 7, "Tier 7–10 🚀"))
        self.add_item(BackToFactoryButton(factory_view))

    def get_embed(self, user):
        return discord.Embed(
            title="🤖 My Machines",
            description=(
                "Browse **only the machines you own**, grouped by tier range.\n"
                "Use the Machine Shop to purchase new machines."
            ),
            color=discord.Color.teal()
        )

    class TierButton(Button):
        def __init__(self, parent, key, required_tier, label):
            super().__init__(label=label, style=discord.ButtonStyle.primary)
            self.parent_view = parent
            self.key = key
            self.required_tier = required_tier

        async def callback(self, interaction: Interaction):
            p = self.parent_view.players[self.parent_view.uid]
            tier = p.get("tier", 1)
            if tier < self.required_tier:
                return await interaction.response.send_message(
                    f"🔒 Requires factory Tier **{self.required_tier}+**.",
                    ephemeral=False
                )

            # ✅ SHOW ONLY OWNED MACHINES in this tier group
            owned = set(p.get("machines", {}).keys())
            tier_group = set(self.parent_view.map.get(self.key, set()))
            owned_lower = {x.lower() for x in owned}
            names = [
                n for n in sorted(MACHINE_DATA.keys())
                if n.lower() in owned_lower and n in tier_group
            ]

            embed = discord.Embed(
                title=f"🤖 Machines — Tier {self.key}",
                description=("Select a machine to view details." if names else "You don't own any machines in this tier range yet."),
                color=discord.Color.teal()
            )
            # ✅ Create a view that holds the OwnedMachineSelect dropdown
            view = discord.ui.View(timeout=120)
            view.add_item(OwnedMachineSelect(self.parent_view.factory_view, names))

            await interaction.response.edit_message(embed=embed, view=view)


class TierMachineSelect(Select):
    def __init__(self, parent_view, names):
        safe = list(names)[:25]
        options = []
        for n in safe:
            data = MACHINE_DATA.get(n, {})
            # Price lives in MACHINES; avoid KeyError
            price = MACHINES.get(n, {}).get("buy", "?")
            out_map = data.get("output", {})
            output_name = next(iter(out_map.keys()), "?")
            desc = f"${price} • {output_name}"
            options.append(discord.SelectOption(label=n, value=n, description=desc))

        if not options:
            options = [discord.SelectOption(label="No machines yet", value="none")]

        super().__init__(placeholder="Select a machine…", options=options)
        self.parent_view = parent_view

    async def callback(self, interaction: Interaction):
        name = self.values[0]
        if name == "none":
            return await interaction.response.send_message("🚫 None available.", ephemeral=False)
        data = MACHINE_DATA[name]
        out_item = next(iter(data.get("output", {}).keys()), "?")
        out_qty = next(iter(data.get("output", {}).values()), "?")
        base_time = data.get("base_time", "?")
        embed = discord.Embed(
            title=f"⚙️ {name}",
            description=f"**Produces:** {out_qty}× {out_item}/cycle\n**Base Time:** {base_time}s",
            color=discord.Color.blurple()
        )
        view = MachineInfoView(self.parent_view.factory_view, name)
        await interaction.response.edit_message(embed=embed, view=view)


class OwnedMachineSelect(discord.ui.Select):
    def __init__(self, factory_view, names):
        self.factory_view = factory_view
        self.names = names

        player = factory_view.players.get(factory_view.uid)
        owned = player.get("machines", {}) if player else {}

        options = []
        for name in names:
            if name not in owned or name not in MACHINE_DATA:
                continue
            # 🧠 Skip machines that are level 0 (not actually owned)
            if owned[name].get("level", 0) <= 0:
                continue

            m = owned[name]
            data = MACHINE_DATA[name]
            level = m.get("level", 0)
            tier = data.get("tier", 1)
            running = "✅" if m.get("running") else "⛔"

            out_map = data.get("output", {})
            output_item = next(iter(out_map.keys()), "?")
            desc = f"Lvl {level} • Tier {tier} • {output_item} • {running}"

            options.append(discord.SelectOption(label=name, value=name, description=desc))

        if not options:
            options = [
                discord.SelectOption(label="No owned machines", value="none", description="You don't own any in this tier.")
            ]

        super().__init__(
            placeholder="Select a machine...",
            options=options,
            min_values=1,
            max_values=1
        )

    async def callback(self, interaction: discord.Interaction):
        name = self.values[0]
        if name == "none":
            return await interaction.response.send_message("🚫 You don't own any machines yet.", ephemeral=False)

        # ✅ Import and open the main machine panel (with Start/Stop/Upgrade buttons)
        panel = MachinePanel(
            self.factory_view.uid,
            self.factory_view.players,
            self.factory_view.save_data,
            return_factory=FactoryView(
                self.factory_view.uid,
                self.factory_view.players,
                self.factory_view.save_data,
                self.factory_view.ensure_player,
                self.factory_view.client
            )
        )

        # Open that specific machine inside the panel (so it jumps straight to controls)
        await panel.open_machine(interaction, name)


class MachineInfoView(View):
    def __init__(self, factory_view, name):
        super().__init__(timeout=120)
        self.factory_view = factory_view
        self.name = name
        self.add_item(BackToFactoryButton(factory_view))
        self.add_item(Button(label="Upgrade 🔼", style=discord.ButtonStyle.success))
        self.add_item(Button(label="Start ▶️", style=discord.ButtonStyle.primary))

    async def interaction_check(self, interaction):
        return str(interaction.user.id) == self.factory_view.uid


# ---------------- RECIPE BROWSER (Tiered) ----------------

def build_recipe_tier_map():
    # Known groupings by name to approximate tiers without changing recipes.py
    t1_3 = {
        "Charcoal","Planks","Glass","Concrete Mix","Scrap Metal","Molten Ingot","Copper Wire",
        "Silicon Chunk","Crude Oil Barrel","Resin",
        "Steel Sheet","Iron Plate","Refined Copper","Circuit Board",
        "Carbon Alloy","Silicon Ingot","Plastic Polymer","Insulated Wire","Lubricant Fluid","Refined Oil","Nanoplastic"
    }
    t4_6 = {
        "Servo Motor","Gear Assembly","Logic Core","AI Module","Motor Housing","Cooling Unit","Copper Coil",
        "Precision Gear","Control Chip","Hydraulic Pump","Sensor Module","Power Regulator","Hydraulic Frame",
        "Industrial Frame","Power Cell",
        "Gizmo","Servo Pack","Control Unit","Drone","Assembler",
        "Reinforced Steel","Hull Plating","Ship Frame","Cargo Engine","Navigation Core"
    }
    t7_10 = {
        "Quantum Chip","Cargo Ship"
    }
    return {"1-3": t1_3, "4-6": t4_6, "7-10": t7_10}


class TierRecipeListView(View):
    def __init__(self, tier_menu_view, tier_label, recipe_names):
        super().__init__(timeout=180)
        self.factory_view = tier_menu_view.factory_view
        self.tier_menu_view = tier_menu_view
        self.tier_label = tier_label
        self.add_item(self.TierRecipeSelect(tier_menu_view, tier_label, recipe_names))
        self.add_item(Button(label="⬅️ Back to Tier Menu", style=discord.ButtonStyle.secondary))
        self.add_item(BackToFactoryButton(self.factory_view))

    class TierRecipeSelect(Select):
        def __init__(self, parent_view, tier_label, recipe_names):
            self.parent_view = parent_view
            self.tier_label = tier_label
            safe_names = list(recipe_names)[:25]
            options = []
            from cogs.crafting import RECIPES
            for name in safe_names:
                data = RECIPES.get(name)
                if not data:
                    continue
                reqs = ", ".join([f"{k}×{v}" for k, v in data["inputs"].items()])
                desc = f"${data['money']} • {reqs}"
                if len(desc) > 100:
                    desc = desc[:95] + "…"
                options.append(discord.SelectOption(label=name, value=name, description=desc))
            if not options:
                options = [discord.SelectOption(label="No recipes in this tier", value="none")]
            super().__init__(placeholder=f"Recipes (Tier {tier_label})", min_values=1, max_values=1, options=options)

        async def callback(self, interaction: Interaction):
            item = self.values[0]
            if item == "none":
                return await interaction.response.send_message("🚫 No recipes available here yet.", ephemeral=False)
            from cogs.crafting import RECIPES
            data = RECIPES[item]
            req = "\n".join([f"• {mat} × {amt}" for mat, amt in data["inputs"].items()])
            embed = discord.Embed(
                title=f"📦 {item}",
                description=f"**Cost:** ${data['money']}\n\n**Requires:**\n{req}",
                color=AMBER_ORANGE
            )
            view = View(timeout=120)
            view.add_item(Button(label="⬅️ Back to Tier Menu", style=discord.ButtonStyle.secondary))
            view.add_item(BackToFactoryButton(self.parent_view.factory_view))
            await interaction.response.edit_message(embed=embed, view=view)


class TierMenuView(View):
    def __init__(self, factory_view, players, uid):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.players = players
        self.uid = uid
        self.map = build_recipe_tier_map()

        self.add_item(self.TierButton(self, "1-3", required_tier=1, label="Tier 1–3 🔩"))
        self.add_item(self.TierButton(self, "4-6", required_tier=4, label="Tier 4–6 ⚙️"))
        self.add_item(self.TierButton(self, "7-10", required_tier=7, label="Tier 7–10 🚀"))
        self.add_item(BackToFactoryButton(factory_view))

    def get_embed(self, user):
        embed = discord.Embed(
            title="📘 Recipe Browser",
            description="Choose a tier range to browse recipes. Locked tiers require a higher factory tier.",
            color=AMBER_ORANGE
        )
        embed.set_footer(text="Max 25 recipes per dropdown (Discord limit).")
        return embed

    class TierButton(Button):
        def __init__(self, parent, key, required_tier, label):
            super().__init__(label=label, style=discord.ButtonStyle.primary)
            self.parent_view = parent
            self.key = key
            self.required_tier = required_tier

        async def callback(self, interaction: Interaction):
            p = self.parent_view.players[self.parent_view.uid]
            current_tier = p.get("tier", 1)
            if current_tier < self.required_tier:
                return await interaction.response.send_message(
                    f"🔒 Requires factory Tier **{self.required_tier}+**.",
                    ephemeral=False
                )

            from cogs.crafting import RECIPES
            names = [n for n in self.parent_view.map[self.key] if n in RECIPES]

            embed = discord.Embed(
                title=f"📘 Recipes — Tier {self.key}",
                description=f"Showing recipes unlocked for Tier {self.key}.",
                color=AMBER_ORANGE
            )

            view = TierRecipeListView(self.parent_view, self.key, names)
            await interaction.response.edit_message(embed=embed, view=view)

    async def interaction_check(self, interaction):
        return str(interaction.user.id) == self.uid


# ---------------- WORKER SELECT ----------------

class WorkerSelect(Select):
    def __init__(self, player):
        # 🧱 Storage Worker removed here – they live in Storage Warehouse now
        options = [
            discord.SelectOption(label="💵 Money Worker", value="money", description="Increases work earnings"),
            discord.SelectOption(label="⚙️ Machine Worker", value="machine", description="Improves machine efficiency"),
            discord.SelectOption(label="🧪 Craft Worker", value="craft", description="Speeds up crafting"),
            discord.SelectOption(label="🌟 Prestige Worker", value="prestige", description="Boosts prestige income"),
        ]
        super().__init__(placeholder="Select worker type to hire", options=options, min_values=1, max_values=1)
        self.player = player

    async def callback(self, interaction: Interaction):
        kind = self.values[0]
        parent_view = self.view
        await parent_view.hire_worker(interaction, kind)

class MarketView(View):
    """Buttons for the player market embed (buy/sell/help + back)."""

    def __init__(self, factory_view: "FactoryView"):
        super().__init__(timeout=180)
        self.factory_view = factory_view

        self.add_item(self.BuyButton(self))
        self.add_item(self.SellButton(self))
        self.add_item(BackToFactoryButton(factory_view))

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.factory_view.uid)

    class BuyButton(Button):
        def __init__(self, parent: "MarketView"):
            super().__init__(label="Buy 🛒", style=discord.ButtonStyle.success)
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            # Just explains how to buy, since the actual logic is in /market_buy
            await interaction.response.send_message(
                "To buy something from the market, use:\n"
                "`/market_buy <listing_id>`\n\n"
                "Use the IDs shown in the market embed above.",
                ephemeral=True
            )

    class SellButton(Button):
        def __init__(self, parent: "MarketView"):
            super().__init__(label="Sell 📤", style=discord.ButtonStyle.primary)
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            # Same idea: point to the slash command that actually does the work
            await interaction.response.send_message(
                "To list an item for sale on the market, use:\n"
                "`/market_sell`\n\n"
                "You can also use `/market_my` to see your listings.",
                ephemeral=True
            )

# ---------------- MENU SELECT ----------------

class MenuSelect(Select):
    def __init__(self, player):
        options = [
            discord.SelectOption(label="Workers 👷", value="workers"),
            discord.SelectOption(label="My Machines 🤖📋", value="machines"),
            discord.SelectOption(label="Inventory 📦", value="inventory"),
            discord.SelectOption(label="Craft 🧩", value="craft"),
            discord.SelectOption(label="Recipe Book 📘", value="recipes"),
            discord.SelectOption(label="Sell 💰", value="sell"),
            discord.SelectOption(label="World 🌍", value="world"),
            discord.SelectOption(label="Market 🏪", value="market"),
        ]

        super().__init__(placeholder="▼ Open Menu", min_values=1, max_values=1, options=options)
        self.player = player

    async def callback(self, interaction: Interaction):
        v: "FactoryView" = self.view
        choice = self.values[0]

        if choice == "workers":
            await v.open_workers_dropdown(interaction)

        elif choice == "machines":
            # ✅ Open machine browser that shows OWNED machines only, grouped by tier
            view = MachineTierMenuView(v)
            embed = view.get_embed(interaction.user)
            await interaction.response.send_message(embed=embed, view=view)

        elif choice == "inventory":
            p = v.players[v.uid]
            inv = p.get("inventory", {})

            embed = discord.Embed(title="📦 Inventory", color=discord.Color.blurple())
            if inv:
                items_list = list(inv.items())[:25]
                lines = [f"**{item}** × {amt}" for item, amt in items_list]
                if len(inv) > 25:
                    lines.append(f"…and {len(inv) - 25} more items hidden (Discord limit)")
                embed.description = "\n".join(lines)
            else:
                embed.description = "Your inventory is **empty**."

            await interaction.response.send_message(embed=embed, view=InventoryView(v, interaction.user))

        elif choice == "craft":
            await interaction.response.send_message(
                "Pick something to craft:",
                view=CraftMenu(v.players, v.uid, v.save_data, v.ensure_player)
            )

        elif choice == "recipes":
            view = TierMenuView(v, v.players, v.uid)
            embed = view.get_embed(interaction.user)
            await interaction.response.send_message(embed=embed, view=view)

        elif choice == "sell":
            embed, view = await open_sell_menu(
                interaction,
                v.uid,
                v.players,
                v.save_data,
                return_factory=v,  # so Back knows where to return
            )
            await interaction.response.send_message(embed=embed, view=view)

        elif choice == "world":
            p = v.players[v.uid]
            world_view = WorldView(v, interaction.user, p)
            await interaction.response.send_message(embed=world_view.embed, view=world_view)

        elif choice == "market":
            # Player Market browser hooked into /factory
            p = v.players[v.uid]
            money = p.get("money", 0)

            # If there is no market data or no listings, show an empty-board embed
            if not PLAYER_MARKET or not PLAYER_MARKET.get("listings"):
                empty_embed = discord.Embed(
                    title="🏪 Galactic Trade Market",
                    description=(
                        "The market board is **empty** right now.\n\n"
                        "Use **`/market_sell`** to list items and start trading!"
                    ),
                    color=discord.Color.dark_gray()
                )
                empty_embed.add_field(
                    name="Your Balance",
                    value=f"💵 ${money:,}",
                    inline=False
                )
                empty_embed.set_footer(text="Tip: Mine, craft, then sell your surplus.")
                return await interaction.response.send_message(
                    embed=empty_embed,
                    view=MarketView(v),
                    ephemeral=False
                )

            # There ARE listings – show them nicely
            listings = sorted(
                PLAYER_MARKET["listings"],
                key=lambda x: x.get("id", 0)
            )[:10]

            embed = discord.Embed(
                title="🏪 Galactic Trade Market",
                description=(
                    "Buy and sell items with other factory owners.\n"
                    "• `/market_buy <listing_id>` — buy a listing\n"
                    "• `/market_sell` — create a listing\n"
                    "• `/market_my` — view your listings\n"
                ),
                color=discord.Color.gold()
            )

            embed.add_field(name="Your Balance", value=f"💵 ${money:,}", inline=False)
            embed.add_field(
                name="Listings Shown",
                value=f"{len(listings)} active offers (max 10 shown)",
                inline=False
            )

            for l in listings:
                seller = l.get("seller")
                seller_mention = f"<@{seller}>" if seller else "Unknown"
                price_per = l.get("price_per", 0)
                qty = l.get("quantity", 0)
                total_price = price_per * qty
                created_ts = l.get("created", 0)
                created_str = f"<t:{created_ts}:R>" if created_ts else "N/A"

                embed.add_field(
                    name=f"[ID #{l['id']}] 📦 {l['item']} ×{qty}",
                    value=(
                        f"👤 Seller: {seller_mention}\n"
                        f"💰 Price: `${price_per:,}` each (**${total_price:,}** total)\n"
                        f"🕒 Listed: {created_str}"
                    ),
                    inline=False
                )

            embed.set_footer(text="Use /market_buy <id> to purchase an offer.")
            await interaction.response.send_message(
                embed=embed,
                view=MarketView(v),
                ephemeral=False
            )



# ---------------- TOKEN SHOP VIEW (TABBED) ----------------

class TokenShopView(View):
    """
    Multi-tab token shop:
      - Titles
      - Themes
      - Badges

    Uses TOKEN_SHOP_ITEMS from cogs.token_shop.
    """

    def __init__(self, factory_view: "FactoryView", user: discord.User):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players
        self.current_tab = "title"  # default tab

        # Tab buttons
        self.add_item(self.TitlesTab(self))
        self.add_item(self.ThemesTab(self))
        self.add_item(self.BadgesTab(self))

        # Back to factory
        self.add_item(BackToFactoryButton(factory_view))

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == self.uid

    # --------- Embed builder ---------

    def build_embed(self, user: discord.User, tab: str) -> discord.Embed:
        self.current_tab = tab
        p = self.players.get(self.uid, {})
        tokens = p.get("wacky_tokens", 0)

        tab_names = {
            "title": "Titles 🎖",
            "theme": "Themes 🎨",
            "badge": "Badges 🏅",
        }
        tab_label = tab_names.get(tab, "Shop")

        embed = discord.Embed(
            title=f"🎨 Wacky Token Shop — {tab_label}",
            description=(
                f"You have **{tokens}** 🔹 Wacky Tokens.\n"
                "Use `/tokens_buy <item_id>` to purchase an item.\n\n"
                f"**Current tab:** {tab_label}\n"
                "_More cosmetic types coming soon…_"
            ),
            color=discord.Color.gold()
        )

        # Filter items by type (title/theme/badge)
        items = [
            (item_id, item)
            for item_id, item in TOKEN_SHOP_ITEMS.items()
            if item.get("type") == tab
        ]

        if not items:
            embed.add_field(
                name="(Empty)",
                value="No items in this tab yet.",
                inline=False
            )
            return embed

        for item_id, item in items:
            embed.add_field(
                name=f"{item['name']} — `{item_id}`",
                value=f"{item['description']}\n**Price:** {item['price']} 🔹",
                inline=False
            )

        return embed

    # --------- Tab Buttons ---------

    class TitlesTab(Button):
        def __init__(self, parent: "TokenShopView"):
            super().__init__(label="Titles 🎖", style=discord.ButtonStyle.primary)
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            embed = self.parent_view.build_embed(interaction.user, "title")
            await interaction.response.edit_message(embed=embed, view=self.parent_view)

    class ThemesTab(Button):
        def __init__(self, parent: "TokenShopView"):
            super().__init__(label="Themes 🎨", style=discord.ButtonStyle.primary)
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            embed = self.parent_view.build_embed(interaction.user, "theme")
            await interaction.response.edit_message(embed=embed, view=self.parent_view)

    class BadgesTab(Button):
        def __init__(self, parent: "TokenShopView"):
            super().__init__(label="Badges 🏅", style=discord.ButtonStyle.primary)
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            embed = self.parent_view.build_embed(interaction.user, "badge")
            await interaction.response.edit_message(embed=embed, view=self.parent_view)

class CosmeticsView(View):
    """Profile & cosmetics editor powered by Wacky Tokens."""

    def __init__(self, factory_view: "FactoryView", user: discord.User):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players
        self.save_data = factory_view.save_data

        p = self.players.get(self.uid, {})
        # Ensure cosmetic fields exist
        p.setdefault("owned_titles", [])
        p.setdefault("owned_themes", [])
        p.setdefault("owned_badges", [])
        p.setdefault("active_title", None)
        p.setdefault("profile_theme", "default")
        p.setdefault("profile_badges", [])

        # Onboarding flags
        p.setdefault("seen_cosmetics_tip", False)
        p.setdefault("seen_token_shop_tip", False)

        # Dropdowns + back button
        self.add_item(self.TitleSelect(self, p))
        self.add_item(self.ThemeSelect(self, p))
        self.add_item(self.BadgeSelect(self, p))
        self.add_item(BackToFactoryButton(factory_view)) 


    def build_embed(self, user: discord.User) -> discord.Embed:
        p = self.players.get(self.uid, {})
        title = p.get("active_title") or "None"
        theme = p.get("profile_theme", "default")
        badges = "".join(p.get("profile_badges", [])) or "None"

        embed = discord.Embed(
            title="🎭 Profile & Cosmetics",
            description=(
                "Customize how your factory looks in the UI.\n\n"
                f"**Current title:** {title}\n"
                f"**Current theme:** {theme}\n"
                f"**Badges:** {badges}\n\n"
                "Use the dropdowns below to equip items you own from the Wacky Token Shop."
            ),
            color=discord.Color.purple()
        )
        embed.set_footer(text="Cosmetics are purely visual – flex on style, not stats.")
        return embed

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.uid)

    # ---------- TITLE SELECT ----------

    class TitleSelect(Select):
        def __init__(self, parent_view: "CosmeticsView", p: dict):
            self.parent_view = parent_view
            owned_titles = list(p.get("owned_titles", []))
            options: list[discord.SelectOption] = []

            for title in owned_titles:
                options.append(discord.SelectOption(
                    label=title,
                    value=title,
                    description=f"Equip the **{title}** title."
                ))

            if options:
                options.insert(0, discord.SelectOption(
                    label="(No title)",
                    value="none",
                    description="Remove your current title."
                ))
            else:
                options = [discord.SelectOption(
                    label="No titles owned",
                    value="none",
                    description="Buy titles in the Wacky Token Shop."
                )]

            super().__init__(
                placeholder="Equip a title…",
                min_values=1,
                max_values=1,
                options=options
            )

        async def callback(self, interaction: Interaction):
            uid = self.parent_view.uid
            p = self.parent_view.players[uid]

            choice = self.values[0]
            if choice == "none":
                p["active_title"] = None
                msg = "Removed your active title."
            else:
                if choice not in p.get("owned_titles", []):
                    return await interaction.response.send_message(
                        "You don't own that title yet. Buy it from the Wacky Token Shop.",
                        ephemeral=True,
                    )
                p["active_title"] = choice
                msg = f"Equipped title: **{choice}**"

            self.parent_view.save_data()
            embed = self.parent_view.build_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=self.parent_view)
            await interaction.followup.send(msg, ephemeral=True)

    # ---------- THEME SELECT ----------

    # ---------- THEME SELECT ----------

    class ThemeSelect(Select):
        def __init__(self, parent_view: "CosmeticsView", p: dict):
            self.parent_view = parent_view
            owned_ids = list(p.get("owned_themes", []))
            options: list[discord.SelectOption] = []

            # If they don't own any themes, just show a dummy entry
            if not owned_ids:
                options = [discord.SelectOption(
                    label="No themes owned",
                    value="default",
                    description="Buy themes in the Wacky Token Shop."
                )]
            else:
                # Only show themes they actually own
                for item_id, item in TOKEN_SHOP_ITEMS.items():
                    if item.get("type") != "theme":
                        continue
                    if item_id not in owned_ids:
                        continue

                    options.append(discord.SelectOption(
                        label=item["name"],
                        value=item_id,
                        description=item.get("description", "")[:100]
                    ))

                # Default theme is always available
                options.insert(0, discord.SelectOption(
                    label="Default theme",
                    value="default",
                    description="Use the standard factory look."
                ))

            super().__init__(
                placeholder="Equip a profile theme…",
                min_values=1,
                max_values=1,
                options=options
            )

        async def callback(self, interaction: Interaction):
            uid = self.parent_view.uid
            p = self.parent_view.players[uid]
            owned_ids = set(p.get("owned_themes", []))

            choice = self.values[0]

            if choice == "default":
                p["profile_theme"] = "default"
                msg = "Switched back to the default theme."
            else:
                # Safety: don't allow equipping unowned themes
                if choice not in owned_ids:
                    return await interaction.response.send_message(
                        "You don't own that theme yet. Buy it from the Wacky Token Shop.",
                        ephemeral=True,
                    )

                item = TOKEN_SHOP_ITEMS.get(choice)
                # store either the internal key or fall back to the id
                theme_key = item.get("value", choice) if item else choice
                display_name = item["name"] if item else theme_key

                p["profile_theme"] = theme_key
                msg = f"Equipped theme: **{display_name}**"

            self.parent_view.save_data()
            embed = self.parent_view.build_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=self.parent_view)
            await interaction.followup.send(msg, ephemeral=True)


    # ---------- BADGE SELECT (multi) ----------

    # ---------- BADGE SELECT (multi) ----------

    class BadgeSelect(Select):
        def __init__(self, parent_view: "CosmeticsView", p: dict):
            self.parent_view = parent_view
            owned_ids = list(p.get("owned_badges", []))
            options: list[discord.SelectOption] = []

            if not owned_ids:
                options = [discord.SelectOption(
                    label="No badges owned",
                    value="none",
                    description="Buy badges in the Wacky Token Shop."
                )]
                min_vals, max_vals = 1, 1
            else:
                for item_id, item in TOKEN_SHOP_ITEMS.items():
                    if item.get("type") != "badge":
                        continue
                    if item_id not in owned_ids:
                        continue

                    display = item.get("emoji") or item["name"]
                    emoji_arg = display if len(display) <= 2 else None

                    options.append(discord.SelectOption(
                        label=item["name"],
                        value=item_id,
                        description=item.get("description", "")[:100],
                        emoji=emoji_arg
                    ))

                min_vals, max_vals = 0, min(len(options), 5)

            super().__init__(
                placeholder="Toggle your profile badges…",
                min_values=min_vals,
                max_values=max_vals,
                options=options
            )

        async def callback(self, interaction: Interaction):
            uid = self.parent_view.uid
            p = self.parent_view.players[uid]
            owned_ids = set(p.get("owned_badges", []))

            if "none" in self.values:
                p["profile_badges"] = []
                msg = "Cleared all badges."
            else:
                # Safety check: ensure they own everything they're equipping
                for choice in self.values:
                    if choice not in owned_ids:
                        return await interaction.response.send_message(
                            "You don't own one of those badges yet. Buy it from the Wacky Token Shop.",
                            ephemeral=True,
                        )

                badges = []
                for choice in self.values:
                    item = TOKEN_SHOP_ITEMS.get(choice)
                    display = (item.get("emoji") or item["name"]) if item else choice
                    badges.append(display)

                p["profile_badges"] = badges
                msg = f"Equipped {len(badges)} badge(s)."

            self.parent_view.save_data()
            embed = self.parent_view.build_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=self.parent_view)
            await interaction.followup.send(msg, ephemeral=True)


# ---------------- WORLD / TRAVEL VIEWS ----------------

class WorldView(View):
    class VisitPlanetsButton(Button):
        def __init__(self, parent):
            super().__init__(label="🪐 Visit Planets", style=discord.ButtonStyle.primary)
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            view = LocationSelectView(self.parent_view.factory_view)
            embed = discord.Embed(
                title="🪐 Regions & Travel",
                description="Select a region to travel to. Space regions require a spaceship and fuel.",
                color=discord.Color.blurple()
            )
            await interaction.response.edit_message(embed=embed, view=view)

    class TradeHubButton(Button):
        def __init__(self, parent):
            super().__init__(label="🏪 Trade Hub", style=discord.ButtonStyle.primary)
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            p = self.parent_view.factory_view.players[self.parent_view.factory_view.uid]
            ship = p.get("spaceship", {})

            embed = discord.Embed(
                title="🏪 Trade Hub",
                description=(
                    "Regional markets coming soon.\n\n"
                    f"Spaceship owned: **{ship.get('owned', False)}**\n"
                    f"Fuel: **{ship.get('fuel', 0)}/{ship.get('max_fuel', 100)}**"
                ),
                color=discord.Color.gold()
            )
            await interaction.response.edit_message(
                embed=embed,
                view=SimpleBackToWorldView(self.parent_view)
            )

    class BackButton(Button):
        def __init__(self, parent):
            super().__init__(label="🏭 Back to Factory", style=discord.ButtonStyle.secondary)
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            p = self.parent_view.factory_view.players[self.parent_view.factory_view.uid]
            await interaction.response.edit_message(
                embed=fmt_embed(interaction.user, p),
                view=self.parent_view.factory_view
            )

    def __init__(self, factory_view, user, player):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.user = user
        self.player = player
        self.embed = self.make_embed()

        # Buttons (nested classes)
        self.add_item(WorldView.VisitPlanetsButton(self))
        self.add_item(WorldView.TradeHubButton(self))
        self.add_item(WorldView.BackButton(self))

    def make_embed(self):
        current_region = self.player.get("location", self.player.get("region", "Grasslands"))
        embed = discord.Embed(
            title="🌍 World Overview",
            description="Explore new territories, trade resources, and expand your industrial empire!",
            color=discord.Color.green()
        )

        embed.add_field(name="🪐 Current Region", value=current_region, inline=False)
        embed.add_field(
            name="🚀 Available Routes",
            value="• Luna Base\n• Mars Outpost\n• Asteroid Belt\n• Titan Station",
            inline=False
        )
        embed.add_field(
            name="📈 Trade Hubs",
            value="• Earth Hub (common goods)\n• Mars Exchange (rare ores)\n• Titan Market (advanced tech)",
            inline=False
        )
        return embed

    async def interaction_check(self, interaction: Interaction):
        return str(interaction.user.id) == str(self.factory_view.uid)


class SimpleBackToWorldView(View):
    def __init__(self, world_view):
        super().__init__(timeout=120)
        self.world_view = world_view
        self.add_item(self.Back(world_view))

    class Back(Button):
        def __init__(self, world_view):
            super().__init__(label="⬅️ Back", style=discord.ButtonStyle.secondary)
            self.world_view = world_view

        async def callback(self, interaction: Interaction):
            await interaction.response.edit_message(
                embed=self.world_view.embed,
                view=self.world_view
            )


class LocationSelectView(View):
    def __init__(self, factory_view):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players

        self.add_item(self.RegionSelect(self))
        self.add_item(BackToFactoryButton(factory_view))

    async def interaction_check(self, interaction: Interaction):
        return str(interaction.user.id) == self.uid

    class RegionSelect(Select):
        def __init__(self, parent_view):
            from cogs.world_data import REGIONS
            self.parent_view = parent_view
            p = parent_view.players[parent_view.uid]
            owned = set(p.get("owned_locations", []))
            tier = p.get("tier", 1)

            options = []
            for name, data in REGIONS.items():
                status_bits = []
                if name in owned:
                    status_bits.append("Owned")
                cost = data.get("fuel_cost", 0)
                if cost:
                    status_bits.append(f"{cost} fuel")
                if tier < data.get("tier_req", 1):
                    status_bits.append(f"Tier {data['tier_req']}+")
                desc = ", ".join(status_bits) or "Available"
                kind = data.get("kind", "earth").title()
                options.append(discord.SelectOption(
                    label=f"{name} ({kind})",
                    value=name,
                    description=desc[:100]
                ))

            options = options[:25] or [discord.SelectOption(label="No regions", value="none")]
            super().__init__(placeholder="Select a region…", min_values=1, max_values=1, options=options)

        async def callback(self, interaction: Interaction):
            import time as _time
            from cogs.world_data import REGIONS
            name = self.values[0]
            if name == "none":
                return await interaction.response.send_message("No regions to travel to.", ephemeral=False)

            uid = self.parent_view.uid
            players = self.parent_view.players
            save_data = self.parent_view.factory_view.save_data
            p = players[uid]
            region = REGIONS.get(name)

            if not region:
                return await interaction.response.send_message("Unknown region.", ephemeral=False)

            # Tier gate
            if p.get("tier", 1) < region.get("tier_req", 1):
                return await interaction.response.send_message(
                    f"🔒 {name} requires factory Tier **{region['tier_req']}+**.",
                    ephemeral=False
                )

            # Spaceship requirement for space regions
            if region.get("kind") == "space":
                ship = p.setdefault("spaceship", {})
                if not ship.get("owned", False):
                    return await interaction.response.send_message(
                        "❌ You need a **Spaceship** to travel to space regions.\n"
                        "Tip: you can later add a Shipyard to sell ships.",
                        ephemeral=False
                    )

            # Travel cooldown check
            now = int(_time.time())
            if now < p.get("travel_cooldown_until", 0):
                remaining = p["travel_cooldown_until"] - now
                return await interaction.response.send_message(
                    f"⏳ Travel systems cooling down. Wait **{remaining}s**.",
                    ephemeral=False
                )

            # Fuel check
            ship = p.setdefault("spaceship", {})
            fuel_cost = region.get("fuel_cost", 0)
            eff_mult = max(0.5, 1.0 - 0.05 * ship.get("upgrades", {}).get("fuel_efficiency", 0))
            effective_cost = max(0, int(fuel_cost * eff_mult))
            if ship.get("fuel", 0) < effective_cost:
                return await interaction.response.send_message(
                    f"⛽ Not enough fuel. Need **{effective_cost}**, have **{ship.get('fuel', 0)}**.",
                    ephemeral=False
                )

            # Spend fuel + own location + cooldown
            ship["fuel"] -= effective_cost
            p.setdefault("owned_locations", [])
            if name not in p["owned_locations"]:
                p["owned_locations"].append(name)

            p["location"] = name
            p["travel_cooldown_until"] = now + (20 if region.get("kind") == "earth" else 60)

            save_data()

            await interaction.response.send_message(
                f"🧭 You travel to **{name}**.\nFuel used: **{effective_cost}**.",
                ephemeral=False
            )
            await interaction.message.edit(
                embed=fmt_embed(interaction.user, p),
                view=self.parent_view.factory_view
            )

class WelcomeView(View):
    """Shown the first time a user runs /factory after /start."""

    def __init__(self, uid, players, save_data, ensure_player, client):
        super().__init__(timeout=180)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.ensure_player = ensure_player
        self.client = client

    def _init_player_data(self):
        p = self.players.setdefault(self.uid, {})

        # Only give the starter pack once, when they *first* start the factory
        if not p.get("factory_started"):
            p["factory_started"] = True

            # 🔹 Starter tokens – ACTUAL reward
            p["wacky_tokens"] = p.get("wacky_tokens", 0) + 10

            # Optional: free starter theme / badge
            # starter_theme_id = "theme_industrial"
            # p.setdefault("owned_themes", [])
            # if starter_theme_id not in p["owned_themes"]:
            #     p["owned_themes"].append(starter_theme_id)

        # Ensure cosmetic fields exist (safety)
        p.setdefault("owned_titles", [])
        p.setdefault("owned_themes", [])
        p.setdefault("owned_badges", [])
        p.setdefault("active_title", None)
        p.setdefault("profile_theme", "default")
        p.setdefault("profile_badges", [])

        self.save_data()

    @button(label="Start My Factory", style=discord.ButtonStyle.success, emoji="🛠️")
    async def start_factory(self, interaction: Interaction, _: Button):
        # Only the owner can press this
        if str(interaction.user.id) != self.uid:
            return await interaction.response.send_message(
                "This setup panel isn’t for you. Run `/factory` to start **your** own factory.",
                ephemeral=True,
            )

        # Initialize starter data + flag
        self._init_player_data()

        # Show the normal FactoryView
        view = FactoryView(self.uid, self.players, self.save_data, self.ensure_player, self.client)
        embed = fmt_embed(interaction.user, self.players[self.uid])

        await interaction.response.edit_message(embed=embed, view=view)

    @button(label="What can I do here?", style=discord.ButtonStyle.secondary, emoji="❓")
    async def help_button(self, interaction: Interaction, _: Button):
        await interaction.response.send_message(
            (
                "Welcome to **Wacky Factory**!\n\n"
                "• Mine and run machines to produce items\n"
                "• Craft advanced materials and ship orders\n"
                "• Earn 💵 money and 🔹 Wacky Tokens\n"
                "• Spend tokens on titles, themes, and badges in the Token Shop\n\n"
                "Press **Start My Factory** when you’re ready – you can always learn by exploring."
            ),
            ephemeral=True,
        )

    async def interaction_check(self, interaction: Interaction) -> bool:
        # Only the owner can use this welcome view
        return str(interaction.user.id) == self.uid

# ---------------- MAIN FACTORY VIEW ----------------

class FactoryView(View):
    def __init__(self, uid, players, save_data, ensure_player, client):
        super().__init__(timeout=180)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.ensure_player = ensure_player
        self.client = client

        player = players.get(uid, {})
        self.add_item(MenuSelect(player))

    async def interaction_check(self, interaction):
        return str(interaction.user.id) == self.uid

    async def open_workers_dropdown(self, interaction: Interaction):
        p = self.players[self.uid]

        class WorkerMenuView(View):
            def __init__(self, parent, player):
                super().__init__(timeout=60)
                self.parent = parent
                self.player = player
                self.add_item(WorkerSelect(player))

            async def hire_worker(self, interaction: Interaction, kind: str):
                p = self.parent.players[self.parent.uid]
                cost = worker_cost(p, kind)

                if p.get("money", 0) < cost:
                    return await interaction.response.send_message(
                        f"Not enough money. Need ${cost}.",
                        ephemeral=False
                    )

                p["money"] -= cost
                p["workers"][kind] += 1
                self.parent.save_data()
                await interaction.response.send_message(
                    f"✅ Hired **{kind.title()} Worker**!",
                    ephemeral=False
                )

                await interaction.message.edit(
                    embed=fmt_embed(interaction.user, p),
                    view=self.parent
                )

        await interaction.response.send_message("Hire a worker:", view=WorkerMenuView(self, p))

    @button(label="Machine Shop 🏪", style=discord.ButtonStyle.primary)
    async def shop_btn(self, interaction: Interaction, _):
        # Fresh FactoryView instance to return to (views should not be reused across messages)
        return_factory = FactoryView(
            self.uid,
            self.players,
            self.save_data,
            self.ensure_player,
            self.client
        )

        embed = discord.Embed(
            title="🏪 Machine Shop",
            description="Select a machine to purchase.",
            color=discord.Color.gold()
        )
        view = MachineShopView(self.uid, self.players, self.save_data, return_factory)

        await interaction.response.send_message(embed=embed, view=view)

    @button(label="Facilities 🏗️", style=discord.ButtonStyle.primary)
    async def facilities_btn(self, interaction: Interaction, _):
        # 👇 local import to avoid circular import at module load time
        from cogs.facilities import FacilitiesView

        view = FacilitiesView(self)
        embed = view.get_embed(interaction.user)
        await interaction.response.send_message(embed=embed, view=view)

    @button(label="Token Shop 🔹", style=discord.ButtonStyle.secondary)
    async def token_shop_btn(self, interaction: Interaction, _):
        p = self.players[self.uid]
        tokens = p.get("wacky_tokens", 0)

        # If shop items aren't available for some reason
        if not TOKEN_SHOP_ITEMS:
            return await interaction.response.send_message(
                f"🎨 The Token Shop is under construction.\n"
                f"You currently have **{tokens}** 🔹 Wacky Tokens.",
                ephemeral=False
            )

        # Use the new multi-tab view
        view = TokenShopView(self, interaction.user)
        embed = view.build_embed(interaction.user, "title")  # default tab: Titles

        await interaction.response.send_message(
            embed=embed,
            view=view,
            ephemeral=False
        )

        # Onboarding: first-time tip when they actually visit the shop
        if tokens > 0 and not p.get("seen_token_shop_tip"):
            p["seen_token_shop_tip"] = True
            self.save_data()

            await interaction.followup.send(
                (
                    "🔹 **Wacky Token Shop**\n"
                    "Spend your Wacky Tokens on cosmetic goodies:\n"
                    "• Titles – little nameplates under your profile\n"
                    "• Themes – change the look of your factory panel\n"
                    "• Badges – small flex icons on your profile\n\n"
                    "Earn more tokens from daily rewards, events, and special contracts."
                ),
                ephemeral=True,
            )


    @button(label="Recipe Browser 📘", style=discord.ButtonStyle.primary)
    async def recipe_browser_btn(self, interaction: Interaction, _):
        view = TierMenuView(self, self.players, self.uid)
        embed = view.get_embed(interaction.user)
        await interaction.response.send_message(embed=embed, view=view)

    @button(label="Mine ⛏️", style=discord.ButtonStyle.green)
    async def mine_btn(self, interaction: Interaction, _):
        import time as _time, random
        from cogs.world_data import REGIONS

        p = self.players[self.uid]

        # 15-minute cooldown (same as old Work button)
        now = int(_time.time())
        cooldown = p.get("work_cooldown", 0)

        if now < cooldown:
            remaining = cooldown - now
            return await interaction.response.send_message(
                f"⏳ Your miners are still recovering! Try again in **{remaining // 60}m {remaining % 60}s**.",
                ephemeral=False
            )

        # Get region info
        region_name = p.get("location", "Grasslands")
        region = REGIONS.get(region_name)

        if not region:
            return await interaction.response.send_message("This region has no mining data yet.", ephemeral=False)

        machines = p.get("machines", {})
        if not machines:
            return await interaction.response.send_message("You have no machines to mine with.", ephemeral=False)

        # Collect mining-capable machines (your advanced system)
    # Collect mining-capable machines
        mine_targets = []

        allowed = region.get("allowed_items")

        for m_name, m_state in machines.items():
            if not isinstance(m_state, dict):
                continue
            if m_state.get("durability", 100) <= 0:
                continue

            data = MACHINE_DATA.get(m_name)
            if not data:
                continue

            for item, base_qty in data.get("output", {}).items():
                # If a region has no allowed_items defined, treat it as "everything allowed"
                if not allowed or item in allowed:
                    mine_targets.append((m_name, m_state, item, base_qty))



        if not mine_targets:
            return await interaction.response.send_message(
                "None of your machines can mine anything in this region.",
                ephemeral=False,
            )

        # Mining output container
        loot = {}
        hazards = []
        hazard_chance = region.get("hazard_chance", 0.1)

        for m_name, m_state, item, base_qty in mine_targets:
            level = m_state.get("level", 1)

            # Level scaling
            qty = int(base_qty * (1 + 0.2 * (level - 1)))

            # Region bonus
            qty = int(qty * region.get("env_bonuses", {}).get(item, 1.0))

            # Add loot
            loot[item] = loot.get(item, 0) + qty

            # XP
            m_state["xp"] = m_state.get("xp", 0) + random.randint(5, 12)
            # Level-up logic
            needed = 100 * level
            if m_state["xp"] >= needed and level < 10:
                m_state["xp"] -= needed
                m_state["level"] += 1

            # Durability
            dmg = random.randint(1, 4)
            m_state["durability"] = max(0, m_state.get("durability", 100) - dmg)

            # Hazards (medium risk)
            if random.random() < hazard_chance:
                extra = random.randint(3, 7)
                m_state["durability"] = max(0, m_state["durability"] - extra)
                hazards.append(f"⚠️ {m_name} took **{extra}%** extra damage from hazards.")

        # Add loot to inventory
        p.setdefault("inventory", {})
        for item, qty in loot.items():
            p["inventory"][item] = p["inventory"].get(item, 0) + qty

        # Set NEW cooldown: 15 minutes
        p["work_cooldown"] = now + 15 * 60
        self.save_data()

        # Build response embed
        desc = "\n".join([f"• {k} × {v}" for k, v in loot.items()])
        if hazards:
            desc += "\n\n" + "\n".join(hazards)

        embed = discord.Embed(
            title=f"⛏️ Mining in {region_name}",
            description=desc,
            color=discord.Color.green()
        )

        await interaction.response.send_message(embed=embed)

    @button(label="Daily 🎁", style=discord.ButtonStyle.success)
    async def daily_btn(self, interaction, _):
        uid = self.uid  # same uid you use everywhere else

        # Use the shared daily logic from cogs.daily
        result = claim_daily_core(uid)

        # Already claimed today
        if not result["ok"] and result.get("already_claimed"):
            remaining = result["remaining"] or 0
            hours = remaining // 3600
            minutes = (remaining % 3600) // 60
            return await interaction.response.send_message(
                f"⏳ Not ready yet. Try again in **{hours}h {minutes}m**.\n"
                f"Current streak: **{result.get('streak', 0)}** days.",
                ephemeral=False
            )

        # Some other error (shouldn’t normally happen)
        if not result["ok"]:
            return await interaction.response.send_message(
                "⚠️ Something went wrong with your daily. Ping the dev.",
                ephemeral=False
            )

        # Successful claim
        p = result["player"]
        streak = result["streak"]
        money = result["money"]
        coal = result["coal"]
        tokens = result["tokens"]

        # 1) update the main factory panel
        await interaction.response.edit_message(
            embed=fmt_embed(interaction.user, p),
            view=self
        )

        # 2) popup with rewards
        lines = [
            f"🎁 Daily claimed! Streak: **{streak}** days.",
            f"💵 + **${money}**",
        ]
        if coal:
            lines.append(f"⛏️ + **{coal} Coal**")
        if tokens:
            lines.append(f"🔹 + **{tokens} Wacky Token(s)**")

        await interaction.followup.send("\n".join(lines), ephemeral=False)
    @button(label="Contracts 📜", style=discord.ButtonStyle.secondary)
    async def contracts_btn(self, interaction: Interaction, _):
        # Local import so the bot doesn't crash if the cog is missing
        from cogs.contracts import (
            ContractsView,
            build_contracts_embed,
            ensure_contract_schema,
            refresh_contracts_if_needed,
        )

        uid = self.uid
        p = self.players.get(uid)
        if not p:
            return await interaction.response.send_message(
                "Could not load your factory data. Try again.",
                ephemeral=True
            )

        # Make sure contract data exists and refresh the list
        ensure_contract_schema(p)
        refresh_contracts_if_needed(p)
        self.save_data()

        # Build the contracts board + interactive view
        embed = build_contracts_embed(interaction.user, p)
        view = ContractsView(uid, self.players, self.save_data)

        await interaction.response.send_message(
            embed=embed,
            view=view,
            ephemeral=False
        )
    @button(label="Profile 🎭", style=discord.ButtonStyle.secondary)
    async def profile_btn(self, interaction: Interaction, _):
        # If token shop isn't set up, just show a simple summary
        if not TOKEN_SHOP_ITEMS:
            p = self.players[self.uid]
            title = p.get("active_title") or "None"
            theme = p.get("profile_theme", "default")
            badges = "".join(p.get("profile_badges", [])) or "None"

            embed = discord.Embed(
                title="🎭 Profile & Cosmetics",
                description=(
                    "The Wacky Token Shop has no cosmetic items configured yet.\n\n"
                    f"**Title:** {title}\n"
                    f"**Theme:** {theme}\n"
                    f"**Badges:** {badges}"
                ),
                color=discord.Color.purple()
            )
            return await interaction.response.send_message(embed=embed, ephemeral=False)

        # Normal path: full cosmetics editor
        view = CosmeticsView(self, interaction.user)
        embed = view.build_embed(interaction.user)
        await interaction.response.send_message(
            embed=embed,
            view=view,
            ephemeral=False
        )

        # Onboarding: first-time tip for the cosmetics screen
        p = self.players[self.uid]
        if not p.get("seen_cosmetics_tip"):
            p["seen_cosmetics_tip"] = True
            self.save_data()

            await interaction.followup.send(
                (
                    "🎭 **Profile & Cosmetics**\n"
                    "Use this panel to equip titles, themes, and badges you’ve unlocked "
                    "from the Wacky Token Shop. Everything here is **purely cosmetic** – "
                    "no gameplay advantage, just extra style."
                ),
                ephemeral=True,
            )



    @button(label="Stats 📊", style=discord.ButtonStyle.secondary)
    async def stats_btn(self, interaction, _):
        p = self.players[self.uid]

        total_workers = sum(p.get("workers", {}).values())
        inv = p.get("inventory", {})
        capacity = 200 + p.get("workers", {}).get("storage", 0) * 200

        machines = p.get("machines", {})
        owned_machines = {
            k: v for k, v in machines.items()
            if isinstance(v, dict) and v.get("level", 0) > 0
        }

        total_machines = len(owned_machines)
        running_machines = sum(1 for v in owned_machines.values() if v.get("running"))
        total_levels = sum(v.get("level", 0) for v in owned_machines.values())

        machine_names = list(owned_machines.keys())
        if total_machines > 0:
            limited_names = machine_names[:25]
            machine_list = ", ".join(limited_names)
            if total_machines > 25:
                machine_list += f" …(+{total_machines - 25} more)"
        else:
            machine_list = "None"

        stats_text = (
            f"**Factory Stats**\n"
            f"• Tier: {p.get('tier', 1)}\n"
            f"• Prestige: {p.get('prestige', 0)} (×{p.get('prestige_mult', 1.0):.2f})\n"
            f"• Production: {p.get('production', 1)} /work\n"
            f"• Inventory: {sum(inv.values())}/{capacity}\n"
            f"• Workers: {total_workers} total\n"
            f"• Machines Owned: {total_machines} ({running_machines} running)\n"
            f"• Machine Levels: {total_levels} total\n"
            f"• Machine List: {machine_list}\n"
            f"• Money: ${p.get('money', 0):,}\n"
            f"• Location: {p.get('location', 'Grasslands')}\n"
        )

        embed = discord.Embed(
            title="📊 Factory Overview",
            description=stats_text,
            color=discord.Color.teal()
        )

        await interaction.response.send_message(embed=embed, ephemeral=False)

    @button(label="Tier Up 🚀", style=discord.ButtonStyle.danger)
    async def tier_btn(self, interaction, _):
        p = self.players[self.uid]

        tier = p.get("tier", 1)
        cost = int(15000 * (2.25 ** (tier - 1)))

        if p.get("money", 0) < cost:
            return await interaction.response.send_message(
                f"💸 You need **${cost:,}** to upgrade to Tier {tier + 1}.",
                ephemeral=False
            )

        p["money"] -= cost
        p["tier"] += 1

        p["production"] = max(1, int(p["production"] * 1.25))

        self.save_data()
        await interaction.response.edit_message(
            embed=fmt_embed(interaction.user, p),
            view=self
        )

        await interaction.followup.send(
            f"🚀 **Tier {p['tier']} Unlocked!** Your factory’s efficiency increased by 25%.",
            ephemeral=False
        )

    @button(label="Refresh 🔄", style=discord.ButtonStyle.gray)
    async def refresh_btn(self, interaction, _):
        p = self.players[self.uid]
        await interaction.response.edit_message(embed=fmt_embed(interaction.user, p), view=self)

    @button(label="Help ❓", style=discord.ButtonStyle.secondary)
    async def help_btn(self, interaction, _):
        from cogs.help_ui import HelpPanel
        panel = HelpPanel()
        await interaction.response.send_message(
            embed=panel.build_embed("basics"),
            view=panel,
            ephemeral=False
        )

    @discord.ui.button(label="Dev 🛠️", style=discord.ButtonStyle.danger, row=4)
    async def dev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        from cogs.devpanel import DevPanel, TargetSelect
        if interaction.user.id != 691108551258800128:
            return await interaction.response.send_message("Access denied.", ephemeral=False)

        uid = str(interaction.user.id)
        panel = DevPanel(uid, self.players, self.save_data, self.client)

        for item in panel.children:
            if isinstance(item, TargetSelect):
                try:
                    await item.populate_options()
                except TypeError:
                    if hasattr(item, "populate"):
                        await item.populate()

        await interaction.response.send_message(
            embed=panel.get_embed(),
            view=panel,
            ephemeral=False
        )


# ----------- Simple Recipe List (existing menu path) -----------

class RecipeDetailView(View):
    def __init__(self, parent_view, item, data):
        super().__init__(timeout=60)
        self.parent_view = parent_view
        self.item = item
        self.data = data
        self.add_item(BackToRecipeListButton(parent_view))

    async def interaction_check(self, interaction):
        return str(interaction.user.id) == self.parent_view.uid


class BackToRecipeListButton(Button):
    def __init__(self, parent_view):
        super().__init__(label="⬅️ Back", style=discord.ButtonStyle.secondary)
        self.parent_view = parent_view

    async def callback(self, interaction: Interaction):
        embed = discord.Embed(title="📘 Crafting Recipes", color=discord.Color.blue())
        embed.description = "Select a recipe to view details."
        view = RecipeListView(self.parent_view)
        await interaction.response.edit_message(embed=embed, view=view)


class RecipeListSelect(Select):
    def __init__(self, parent_view, recipes):
        safe_recipes = list(recipes)[:25]
        options = [discord.SelectOption(label=item, value=item) for item in safe_recipes]
        super().__init__(placeholder="Select a recipe...", options=options, min_values=1, max_values=1)
        self.parent_view = parent_view

    async def callback(self, interaction: Interaction):
        from cogs.crafting import RECIPES
        item = self.values[0]
        data = RECIPES[item]
        req = "\n".join([f"• {mat} × {amt}" for mat, amt in data["inputs"].items()])
        embed = discord.Embed(title=f"📦 {item}", color=discord.Color.blue())
        embed.add_field(name=f"Cost: ${data['money']}", value=req, inline=False)
        view = RecipeDetailView(self.parent_view, item, data)
        await interaction.response.edit_message(embed=embed, view=view)


class RecipeListView(View):
    def __init__(self, parent_view):
        super().__init__(timeout=120)
        self.parent_view = parent_view
        from cogs.crafting import RECIPES
        self.add_item(RecipeListSelect(parent_view, RECIPES.keys()))
        self.add_item(BackToFactoryButton(parent_view))

    async def interaction_check(self, interaction):
        return str(interaction.user.id) == self.parent_view.uid


# ---------------- SETUP ----------------

def setup(client, players, save_data, ensure_player):
    for p in players.values():
        p.setdefault("workers", {"money": 0, "machine": 0, "craft": 0, "prestige": 0, "storage": 0})
        p.setdefault("shipping_center_unlocked", p.get("shipping_center_owned", False))

        # 🌍 world defaults
        p.setdefault("location", "Grasslands")
        p.setdefault("owned_locations", [p["location"]])
        p.setdefault("travel_cooldown_until", 0)

        # 🚀 spaceship defaults
        p.setdefault("spaceship", {
            "owned": False,
            "tier": 1,
            "fuel": 0,
            "max_fuel": 100,
            "upgrades": {"fuel_efficiency": 0, "shield": 0, "cargo": 0},
        })

        # ⚙️ machine durability / xp defaults
        machines = p.get("machines", {})
        for m_state in machines.values():
            if isinstance(m_state, dict):
                m_state.setdefault("level", 1)
                m_state.setdefault("xp", 0)
                m_state.setdefault("durability", 100)
                m_state.setdefault("max_durability", 100)

    @client.tree.command(name="factory", description="Open your neon-themed factory control panel.")
    async def factory(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")

        players[uid]["factory_channel"] = interaction.channel.id
        p = players[uid]

        # FIRST-TIME FLOW: if they haven't started their factory UI yet
        if not p.get("factory_started"):
            welcome_embed = discord.Embed(
                title="🏭 Welcome to Wacky Factory!",
                description=(
                    "You’ve just been put in charge of a very wacky industrial complex.\n\n"
                    "Press **Start My Factory** to:\n"
                    "• Initialize your factory data\n"
                    "• Get some starter 🔹 Wacky Tokens\n"
                    "• Unlock basic cosmetics and access the control panel\n\n"
                    "You can always come back with `/factory` to manage and upgrade everything."
                ),
                color=discord.Color.blurple()
            )
            view = WelcomeView(uid, players, save_data, ensure_player, client)
            return await interaction.response.send_message(embed=welcome_embed, view=view)

        # NORMAL PATH: returning users go straight to the panel
        await interaction.response.send_message(
            embed=fmt_embed(interaction.user, p),
            view=FactoryView(uid, players, save_data, ensure_player, client)
        )



# ---------------- RESEARCH LAB & FACILITIES ----------------

# ---------------- RESEARCH LAB & FACILITIES ----------------

# ---------------- RESEARCH LAB & FACILITIES ----------------

class ResearchLabView(View):
    """Inside the lab you can directly craft Rocket Fuel as an inventory item."""
    # 🔧 Rocket Fuel recipe: change these values any time
    ROCKET_FUEL_COST_ITEMS = {
        "Crude Oil Barrel": 3,
    }
    ROCKET_FUEL_COST_MONEY = 500

    def __init__(self, factory_view: "FactoryView"):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players

        # buttons inside the lab
        self.add_item(self.CraftRocketFuelButton(self))
        self.add_item(BackToFactoryButton(factory_view))

    def get_embed(self, user):
        p = self.players.get(self.uid, {})
        inv = p.get("inventory", {})
        money = p.get("money", 0)
        fuel = inv.get("Rocket Fuel", 0)

        # Build cost line from the recipe dict
        cost_parts = [f"{item} ×{amt}" for item, amt in self.ROCKET_FUEL_COST_ITEMS.items()]
        cost_line = " , ".join(cost_parts) + f", ${self.ROCKET_FUEL_COST_MONEY}"

        # Build "you currently have" lines for each ingredient
        have_lines = []
        for item, amt in self.ROCKET_FUEL_COST_ITEMS.items():
            have_lines.append(f"• {item} ×{inv.get(item, 0)}")

        embed = discord.Embed(
            title="🧪 Research Lab",
            description=(
                "Welcome to your **Research Lab**!\n\n"
                "__Rocket Fuel Synthesis__\n"
                f"• Cost per Rocket Fuel: {cost_line}\n\n"
                "__You currently have:__\n"
                + "\n".join(have_lines) + "\n"
                f"• Money: ${money}\n"
                f"• Rocket Fuel: ×{fuel}\n\n"
                "Use the button below to synthesize **Rocket Fuel**."
            ),
            color=discord.Color.purple()
        )
        return embed

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.uid)

    class CraftRocketFuelButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="Craft 1 Rocket Fuel ⛽",
                style=discord.ButtonStyle.success
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            p = self.parent_view.players[self.parent_view.uid]
            inv = p.setdefault("inventory", {})

            # 👉 check ingredients
            missing = []
            for item, needed in ResearchLabView.ROCKET_FUEL_COST_ITEMS.items():
                if inv.get(item, 0) < needed:
                    missing.append(f"{item} ×{needed}")
            if p.get("money", 0) < ResearchLabView.ROCKET_FUEL_COST_MONEY:
                missing.append(f"${ResearchLabView.ROCKET_FUEL_COST_MONEY}")

            if missing:
                return await interaction.response.send_message(
                    "❌ You don't have enough resources:\n"
                    + "\n".join(f"• {m}" for m in missing),
                    ephemeral=False
                )

            # ✅ pay costs
            for item, needed in ResearchLabView.ROCKET_FUEL_COST_ITEMS.items():
                inv[item] = inv.get(item, 0) - needed
                if inv[item] <= 0:
                    inv.pop(item, None)

            p["money"] -= ResearchLabView.ROCKET_FUEL_COST_MONEY

            # add rocket fuel
            inv["Rocket Fuel"] = inv.get("Rocket Fuel", 0) + 1

            # save + refresh
            self.parent_view.factory_view.save_data()

            await interaction.response.send_message(
                "✅ Synthesized **1 Rocket Fuel**!",
                ephemeral=False
            )
            await interaction.message.edit(
                embed=self.parent_view.get_embed(interaction.user),
                view=self.parent_view
            )


class StorageWarehouseView(View):
    """Facility view to showcase and hire Storage Workers."""
    def __init__(self, factory_view: "FactoryView"):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players
        self.save_data = factory_view.save_data

        self.add_item(self.HireStorageWorkerButton(self))
        self.add_item(self.BackToFacilitiesButton(self))
        self.add_item(BackToFactoryButton(factory_view))

    def get_embed(self, user):
        p = self.players.get(self.uid, {})
        w = p.get("workers", {})
        storage_workers = w.get("storage", 0)
        capacity = BASE_CAPACITY + storage_workers * 200
        inv_count = sum(p.get("inventory", {}).values())
        next_cost = worker_cost(p, "storage")

        desc = (
            "Your **Storage Warehouse** houses all storage staff and extra inventory space.\n\n"
            f"• Storage Workers: **{storage_workers}**\n"
            f"• Capacity: **{inv_count}/{capacity}** items\n"
            f"• Next Storage Worker cost: **${next_cost}**\n\n"
            "Hire additional Storage Workers here to expand your warehouse capacity."
        )

        embed = discord.Embed(
            title="🏗️ Storage Warehouse",
            description=desc,
            color=discord.Color.dark_gold()
        )
        return embed

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.uid)

    class HireStorageWorkerButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="Hire Storage Worker 📦",
                style=discord.ButtonStyle.success
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            p = self.parent_view.players[self.parent_view.uid]
            w = p.setdefault("workers", {"money": 0, "machine": 0, "craft": 0, "prestige": 0, "storage": 0})

            cost = worker_cost(p, "storage")
            if p.get("money", 0) < cost:
                return await interaction.response.send_message(
                    f"❌ Not enough money. Need **${cost}** to hire a Storage Worker.",
                    ephemeral=False
                )

            p["money"] -= cost
            w["storage"] += 1
            self.parent_view.save_data()

            await interaction.response.send_message(
                f"✅ Hired **1 Storage Worker**! You now have **{w['storage']}**.",
                ephemeral=False
            )
            await interaction.message.edit(
                embed=self.parent_view.get_embed(interaction.user),
                view=self.parent_view
            )

    class BackToFacilitiesButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="⬅️ Back to Facilities",
                style=discord.ButtonStyle.secondary
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            facilities = FacilitiesView(self.parent_view.factory_view)
            embed = discord.Embed(
                title="🧩 Facilities",
                description=(
                    "Manage permanent factory buildings.\n\n"
                    "• Research Lab (craftable)\n"
                    "• Storage Warehouse (capacity & storage workers)\n"
                    "More facilities coming soon…"
                ),
                color=discord.Color.orange()
            )
            await interaction.response.edit_message(embed=embed, view=facilities)


class FacilitiesView(View):
    """Facilities menu – includes building / entering the Research Lab."""
    LAB_COST_ITEMS = {"Scrap Metal": 10, "Copper Wire": 5}
    LAB_COST_MONEY = 500

    def __init__(self, factory_view: "FactoryView"):
        super().__init__(timeout=180)
        self.factory_view = factory_view
        self.uid = factory_view.uid
        self.players = factory_view.players

        p = self.players.get(self.uid, {})

        # --- Research Lab entry ---
        if p.get("has_research_lab", False):
            self.add_item(self.ResearchLabButton(self))
        else:
            self.add_item(self.BuildResearchLabButton(self))

        # --- Storage Warehouse entry (always visible) ---
        self.add_item(self.StorageWarehouseButton(self))

        # Back to main factory
        self.add_item(BackToFactoryButton(factory_view))

    def get_embed(self, user):
        """Build the main Facilities menu embed."""
        embed = discord.Embed(
            title="🧩 Facilities",
            description=(
                "Manage permanent factory buildings.\n\n"
                "• Research Lab (craftable)\n"
                "• Storage Warehouse (capacity & storage workers)\n"
                "More facilities coming soon…"
            ),
            color=discord.Color.orange()
        )
        return embed

    async def interaction_check(self, interaction: Interaction) -> bool:
        return str(interaction.user.id) == str(self.uid)

    class ResearchLabButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="🧪 Research Lab",
                style=discord.ButtonStyle.success
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            lab = ResearchLabView(self.parent_view.factory_view)
            embed = lab.get_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=lab)

    class BuildResearchLabButton(Button):
        def __init__(self, parent):
            label = (
                "Build Research Lab — Requires: "
                f"Scrap Metal ×{FacilitiesView.LAB_COST_ITEMS['Scrap Metal']}, "
                f"Copper Wire ×{FacilitiesView.LAB_COST_ITEMS['Copper Wire']}, "
                f"${FacilitiesView.LAB_COST_MONEY}"
            )
            super().__init__(
                label=label,
                style=discord.ButtonStyle.primary
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            p = self.parent_view.players[self.parent_view.uid]
            inv = p.setdefault("inventory", {})

            missing = []
            if inv.get("Scrap Metal", 0) < FacilitiesView.LAB_COST_ITEMS["Scrap Metal"]:
                missing.append(f"Scrap Metal ×{FacilitiesView.LAB_COST_ITEMS['Scrap Metal']}")
            if inv.get("Copper Wire", 0) < FacilitiesView.LAB_COST_ITEMS["Copper Wire"]:
                missing.append(f"Copper Wire ×{FacilitiesView.LAB_COST_ITEMS['Copper Wire']}")
            if p.get("money", 0) < FacilitiesView.LAB_COST_MONEY:
                missing.append(f"${FacilitiesView.LAB_COST_MONEY}")

            if missing:
                return await interaction.response.send_message(
                    "❌ You don't have enough resources to build the Research Lab:\n"
                    + "\n".join(f"• {m}" for m in missing),
                    ephemeral=False
                )

            # pay costs
            inv["Scrap Metal"] -= FacilitiesView.LAB_COST_ITEMS["Scrap Metal"]
            inv["Copper Wire"] -= FacilitiesView.LAB_COST_ITEMS["Copper Wire"]
            p["money"] -= FacilitiesView.LAB_COST_MONEY

            # unlock lab
            p["has_research_lab"] = True
            self.parent_view.factory_view.save_data()

            # jump straight into the lab
            lab = ResearchLabView(self.parent_view.factory_view)
            embed = lab.get_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=lab)
            await interaction.followup.send(
                "🏗️ You built the **Research Lab**! Welcome to advanced research.",
                ephemeral=False
            )

    class StorageWarehouseButton(Button):
        def __init__(self, parent):
            super().__init__(
                label="📦 Storage Warehouse",
                style=discord.ButtonStyle.primary
            )
            self.parent_view = parent

        async def callback(self, interaction: Interaction):
            warehouse = StorageWarehouseView(self.parent_view.factory_view)
            embed = warehouse.get_embed(interaction.user)
            await interaction.response.edit_message(embed=embed, view=warehouse)
