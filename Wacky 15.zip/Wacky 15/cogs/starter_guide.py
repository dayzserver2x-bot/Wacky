import discord
from discord import app_commands

def setup(client, players, save_data, ensure_player):

    @client.tree.command(
        name="starter_guide",
        description="Post the Wacky Factory Starter Guide (persistent message)"
    )
    async def starter_guide(interaction: discord.Interaction):

        embed = discord.Embed(
            title="🧰 Wacky Factory — Starter Guide",
            color=0xFFD400,
            description=(
                "Welcome to **Wacky Factory!** Here's your starter progression path:\n\n"
                "**1. Start Your Factory** — Use `/start` and then `/factory` to open your control panel.\n"
                "**2. Run Your Starter Machines** — In the Machines menu, start your Tier 0 machines (like Junk Shredder & Dirt Sifter) to generate **Scrap Bits**, **Scrap Metal**, and basic ores.\n"
                "**3. Sell & Reinvest** — Use the dropdown on `/factory` to sell extra items and buy more machines.\n"
                "**4. Craft Early Basics** — Use `/recipes` to browse and `/craft` to turn scrap and ore into higher-value items (like **Scrap Metal**, **Copper Wire**, and basic components).\n"
                "**5. Follow a Starter Goal** — Try to build up a small stockpile of Scrap Metal & Copper Wire; they're used everywhere for upgrades and new machines.\n"
                "**6. Upgrade Factory Tier** — Gain more machine slots, power, and worker capacity.\n"
                "**7. Automate & Expand** — Hire workers, unlock Facilities, and let the factory run itself.\n"
                "**8. Prestige Later** — When you're strong, reset for permanent boosts.\n\n"
            )
        )

        embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1260082849482307644.webp")
        embed.set_footer(text="Wacky Factory — Build. Craft. Automate. Chaos.")

        # Acknowledge the command (ephemeral)
        await interaction.response.send_message(
            "Starter Guide posted!",
            ephemeral=True
        )

        # Send the visible persistent embed
        await interaction.channel.send(embed=embed)
