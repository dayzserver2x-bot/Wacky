# cogs/dev_response.py
import discord
import json
import os
from difflib import SequenceMatcher

DEV_ROLE_ID       = 333333333333333333  # optional, used only if you want to tag dev role
DASHBOARD_CHANNEL = 1439739957521682524

STATS_FILE      = "feedback_stats.json"
REPORT_LOG_FILE = "feedback_reports.json"

CATEGORY_KEYWORDS = {
    "🐞 Bug": [
        "bug", "crash", "error", "broken", "stuck",
        "freeze", "glitch", "not working", "fails",
        "dupe", "duplicate", "exploit"
    ],
    "⚙️ Machine Issue": [
        "machine", "durability", "cycle", "automation",
        "output", "fuel", "blueprint"
    ],
    "🛠 Crafting / Items": [
        "craft", "recipe", "material", "item", "resource"
    ],
    "🏗 Building": [
        "building", "construct", "structure"
    ],
    "💰 Economy / Balance": [
        "money", "balance", "inflation", "expensive", "cheap",
        "price", "cost"
    ],
    "🎨 UI / Visual": [
        "embed", "ui", "layout", "design", "interface"
    ],
    "💡 Suggestion": [
        "suggest", "idea", "improvement", "feature", "add"
    ],
    "🔧 Performance": [
        "lag", "slow", "delay", "performance", "tick", "loop"
    ]
}

CRITICAL_KEYWORDS = [
    "crash", "lock", "freeze", "hang",
    "fatal", "break", "exploit", "dupe",
    "critical", "urgent", "major"
]


def detect_categories(text: str):
    text = text.lower()
    matched = []

    for category, keywords in CATEGORY_KEYWORDS.items():
        if any(k in text for k in keywords):
            matched.append(category)

    return matched or ["❓ Unclassified"]


def is_critical(text: str) -> bool:
    text = text.lower()
    return any(kw in text for kw in CRITICAL_KEYWORDS)


class DevResponse:
    def __init__(self, client: discord.Client):
        self.client = client
        self.stats = self._load_json(STATS_FILE, {})
        self.report_log = self._load_json(REPORT_LOG_FILE, [])

    # ---------------- JSON helpers ----------------
    def _load_json(self, path, default):
        if not os.path.exists(path):
            with open(path, "w") as f:
                json.dump(default, f, indent=4)
            return default
        with open(path, "r") as f:
            try:
                return json.load(f)
            except Exception:
                return default

    def _save_json(self, path, data):
        with open(path, "w") as f:
            json.dump(data, f, indent=4)

    # ---------------- duplicate + stats -----------
    def find_duplicate(self, text: str):
        best_match = None
        best_score = 0

        for entry in self.report_log:
            old_text = entry["text"]
            score = SequenceMatcher(None, text.lower(), old_text.lower()).ratio() * 100
            if score > 70 and score > best_score:
                best_score = score
                best_match = {"id": entry["id"], "score": score}

        return best_match

    def update_stats(self, categories, is_critical_flag, is_duplicate=False):
        for c in categories:
            self.stats[c] = self.stats.get(c, 0) + 1

        if is_critical_flag:
            self.stats["🔥 Critical"] = self.stats.get("🔥 Critical", 0) + 1

        if is_duplicate:
            self.stats["🔁 Duplicates"] = self.stats.get("🔁 Duplicates", 0) + 1

        self.stats["total"] = self.stats.get("total", 0) + 1

        self._save_json(STATS_FILE, self.stats)

    async def update_dashboard(self, guild: discord.Guild):
        """Create or update the feedback dashboard embed in the dashboard channel."""
        channel = guild.get_channel(DASHBOARD_CHANNEL)
        if channel is None:
            return

        # Reload stats fresh
        self.stats = self._load_json(STATS_FILE, self.stats)

        total      = self.stats.get("total", 0)
        critical   = self.stats.get("🔥 Critical", 0)
        duplicates = self.stats.get("🔁 Duplicates", 0)

        embed = discord.Embed(
            title="📊 Wacky Factory Feedback Dashboard",
            color=discord.Color.blue(),
            description="Live summary of all feedback, bugs, and suggestions."
        )

        embed.add_field(name="📌 Total Reports", value=str(total), inline=False)
        embed.add_field(name="🔥 Critical Issues", value=str(critical), inline=True)
        embed.add_field(name="🔁 Possible Duplicates", value=str(duplicates), inline=True)

        # Category breakdown (excluding special keys)
        for cat, count in self.stats.items():
            if cat in ("total", "🔥 Critical", "🔁 Duplicates"):
                continue
            embed.add_field(name=cat, value=str(count), inline=True)

        # Single message dashboard: just send a new one each time
        await channel.send(embed=embed)

    # ---------------- main entry: auto_classify ---
    async def auto_classify(self, msg: discord.Message):
        """Add category, critical flags, duplicate tag, and update dashboard."""
        if not msg.embeds:
            return

        embed = msg.embeds[0]
        report_text = embed.description or ""

        # Detect categories
        categories = detect_categories(report_text)
        cat_formatted = ", ".join(categories)

        embed.add_field(
            name="📌 Categories",
            value=cat_formatted,
            inline=False
        )

        # Critical detection
        critical_flag = is_critical(report_text)
        if critical_flag:
            embed.title = "🔥 CRITICAL BUG REPORT"
            embed.color = discord.Color.red()

            dev_role = msg.guild.get_role(DEV_ROLE_ID)
            if dev_role:
                await msg.reply(f"🔥 Critical issue detected! {dev_role.mention}")

        # Duplicate detection
        duplicate = self.find_duplicate(report_text)
        is_dup_flag = False
        if duplicate:
            is_dup_flag = True
            link = f"https://discord.com/channels/{msg.guild.id}/{msg.channel.id}/{duplicate['id']}"
            embed.add_field(
                name="🔁 Possible Duplicate",
                value=f"Similar to [this report]({link}) ({duplicate['score']:.1f}% text match).",
                inline=False
            )

        # Log this report
        self.report_log.append({
            "id": msg.id,
            "text": report_text
        })
        self._save_json(REPORT_LOG_FILE, self.report_log)

        # Update stats + dashboard
        self.update_stats(categories, critical_flag, is_dup_flag)
        await self.update_dashboard(msg.guild)

        # Save modified embed
        await msg.edit(embed=embed)


# --------------- setup called from main.py ---------------
def setup(client: discord.Client):
    helper = DevResponse(client)
    # attach to client so feedback.py can use it
    client.dev_response = helper

    # Optional: quick stats slash command
    @client.tree.command(name="feedbackstats", description="View basic feedback statistics.")
    async def feedbackstats(interaction: discord.Interaction):
        stats = helper._load_json(STATS_FILE, helper.stats)
        total = stats.get("total", 0)
        critical = stats.get("🔥 Critical", 0)
        duplicates = stats.get("🔁 Duplicates", 0)

        embed = discord.Embed(
            title="📊 Feedback Stats (Summary)",
            color=discord.Color.blue()
        )
        embed.add_field(name="Total Reports", value=str(total), inline=False)
        embed.add_field(name="Critical Issues", value=str(critical), inline=True)
        embed.add_field(name="Duplicates", value=str(duplicates), inline=True)

        await interaction.response.send_message(embed=embed, ephemeral=True)
