# cogs/token_shop.py
import discord
from discord import app_commands, Interaction

# Simple cosmetic shop config
COSMETIC_ITEMS = {
    # -------- Titles --------
    "title_foreman": {
        "name": "Title: Foreman",
        "description": "Unlocks the **Foreman** title.",
        "price": 3,
        "type": "title",
        "value": "Foreman",
    },
    "title_shift_supervisor": {
        "name": "Title: Shift Supervisor",
        "description": "You keep the chaos barely under control.",
        "price": 5,
        "type": "title",
        "value": "Shift Supervisor",
    },
    "title_quantum_overseer": {
        "name": "Title: Quantum Overseer",
        "description": "A rare title for factories that bend reality.",
        "price": 10,
        "type": "title",
        "value": "Quantum Overseer",
    },
    # extra titles
    "title_cargo_tycoon": {
        "name": "Title: Cargo Tycoon",
        "description": "Master of shipping lanes and logistics.",
        "price": 4,
        "type": "title",
        "value": "Cargo Tycoon",
    },
    "title_overclocked": {
        "name": "Title: Overclocked",
        "description": "Runs their machines a little too hot.",
        "price": 6,
        "type": "title",
        "value": "Overclocked",
    },
    "title_dimensional_foreman": {
        "name": "Title: Dimensional Foreman",
        "description": "Supervises factories across parallel universes.",
        "price": 8,
        "type": "title",
        "value": "Dimensional Foreman",
    },
    "title_wacky_magnate": {
        "name": "Title: Wacky Magnate",
        "description": "An eccentric billionaire of industry.",
        "price": 12,
        "type": "title",
        "value": "Wacky Magnate",
    },

    # -------- Profile Themes --------
    "theme_industrial": {
        "name": "Theme: Industrial Steel",
        "description": "A rugged, heavy industry look for your factory panel.",
        "price": 6,
        "type": "theme",
        "value": "industrial",  # stored in profile_theme
    },
    "theme_arcane": {
        "name": "Theme: Arcane Reactor",
        "description": "Glowy, mysterious, slightly unsafe.",
        "price": 8,
        "type": "theme",
        "value": "arcane",
    },
    # extra themes
    "theme_neon_grid": {
        "name": "Theme: Neon Grid",
        "description": "Bright neon lines and holographic dashboards.",
        "price": 7,
        "type": "theme",
        "value": "neon_grid",
    },
    "theme_rustbelt": {
        "name": "Theme: Rustbelt Classic",
        "description": "Greasy metal, faded paint, and old warning signs.",
        "price": 5,
        "type": "theme",
        "value": "rustbelt",
    },
    "theme_cosmic_lab": {
        "name": "Theme: Cosmic Lab",
        "description": "Cold blues, starfields, and experimental reactors.",
        "price": 9,
        "type": "theme",
        "value": "cosmic_lab",
    },

    # -------- Badges --------
    "badge_golden_gear": {
        "name": "Badge: Golden Gear",
        "description": "Displays a golden gear badge on your profile.",
        "price": 4,
        "type": "badge",
        "value": "🟡⚙️",
    },
    "badge_logistics_goblin": {
        "name": "Badge: Logistics Goblin",
        "description": "For players who live in the Shipping Center.",
        "price": 4,
        "type": "badge",
        "value": "🧌📦",
    },
    "badge_night_shift": {
        "name": "Badge: Night Shift",
        "description": "For the ones who grind at ungodly hours.",
        "price": 4,
        "type": "badge",
        "value": "🌙🛠️",
    },
    # extra badges
    "badge_daily_grinder": {
        "name": "Badge: Daily Grinder",
        "description": "For players who never skip their daily reward.",
        "price": 3,
        "type": "badge",
        "value": "📅⚡",
    },
    "badge_millionaire": {
        "name": "Badge: Factory Millionaire",
        "description": "Flex that first million dollars.",
        "price": 6,
        "type": "badge",
        "value": "💰🏭",
    },
    "badge_contractor": {
        "name": "Badge: Master Contractor",
        "description": "Lives on the contracts board.",
        "price": 4,
        "type": "badge",
        "value": "📜📦",
    },
    "badge_ship_captain": {
        "name": "Badge: Ship Captain",
        "description": "Knows their way around space logistics.",
        "price": 5,
        "type": "badge",
        "value": "🚀🛰️",
    },
    "badge_token_whale": {
        "name": "Badge: Token Whale",
        "description": "Big spender in the Wacky Token Shop.",
        "price": 10,
        "type": "badge",
        "value": "🐋🔹",
    },
    "badge_wacky_logo": {
        "name": "Badge: Wacky Factory OG",
        "description": "Supports the factory from the early days.",
        "price": 8,
        "type": "badge",
        "value": "🏭✨",
    },
}

def setup(client, players, save_data, ensure_player):

    def ensure_cosmetics(uid: str):
        """Make sure cosmetic fields exist for this player."""
        p = players.setdefault(uid, {})
        p.setdefault("wacky_tokens", 0)

        # Titles are stored by visible title text, e.g. "Foreman"
        p.setdefault("owned_titles", [])
        p.setdefault("active_title", None)

        # Themes and badges are stored by item_id from COSMETIC_ITEMS
        p.setdefault("owned_themes", [])
        p.setdefault("owned_badges", [])

        # Currently equipped cosmetics
        p.setdefault("profile_theme", "default")
        p.setdefault("profile_badges", [])

        return p


    # ---------------- /tokens ----------------
    @client.tree.command(name="tokens", description="Check your Wacky Tokens.")
    async def tokens_cmd(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first to create your factory.",
                ephemeral=False
            )

        p = ensure_cosmetics(uid)
        await interaction.response.send_message(
            f"You have **{p['wacky_tokens']}** 🔹 Wacky Tokens.",
            ephemeral=False
        )

    # ---------------- /tokens_shop ----------------
    @client.tree.command(name="tokens_shop", description="Browse cosmetic items purchasable with Wacky Tokens.")
    async def tokens_shop_cmd(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first to create your factory.",
                ephemeral=False
            )

        p = ensure_cosmetics(uid)
        tokens = p["wacky_tokens"]

        embed = discord.Embed(
            title="🎨 Wacky Token Shop",
            description=(
                f"You have **{tokens}** 🔹 Wacky Tokens.\n"
                "Use `/tokens_buy <item_id>` to purchase an item."
            ),
            color=discord.Color.gold()
        )

        for item_id, item in COSMETIC_ITEMS.items():
            embed.add_field(
                name=f"{item['name']} — `{item_id}`",
                value=f"{item['description']}\n**Price:** {item['price']} 🔹",
                inline=False
            )

        await interaction.response.send_message(embed=embed, ephemeral=False)

    # ---------------- /tokens_buy <item_id> ----------------
    @client.tree.command(name="tokens_buy", description="Buy a cosmetic item with your Wacky Tokens.")
    async def tokens_buy_cmd(interaction: Interaction, item_id: str):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first.",
                ephemeral=False
            )

        p = ensure_cosmetics(uid)
        item = COSMETIC_ITEMS.get(item_id)

        if not item:
            return await interaction.response.send_message(
                "That `item_id` doesn't exist. Use `/tokens_shop` to see valid IDs.",
                ephemeral=False
            )

        price = item["price"]
        if p["wacky_tokens"] < price:
            return await interaction.response.send_message(
                f"You need **{price}** 🔹 Wacky Tokens but only have **{p['wacky_tokens']}**.",
                ephemeral=False
            )

        # Spend tokens
           # Spend tokens
        p["wacky_tokens"] -= price

        # Apply cosmetic effect
        if item["type"] == "title":
            # Titles are tracked by their visible text, e.g. "Foreman"
            title = item["value"]
            if title not in p["owned_titles"]:
                p["owned_titles"].append(title)
            # auto-equip it
            p["active_title"] = title

        elif item["type"] == "theme":
            # Themes are tracked by item_id + a short key in profile_theme
            theme_key = item["value"]  # e.g. "industrial"
            if item_id not in p["owned_themes"]:
                p["owned_themes"].append(item_id)
            p["profile_theme"] = theme_key

        elif item["type"] == "badge":
            # Badges are tracked by item_id and displayed as emoji/text
            badge_value = item["value"]
            if item_id not in p["owned_badges"]:
                p["owned_badges"].append(item_id)
            if badge_value not in p["profile_badges"]:
                p["profile_badges"].append(badge_value)

        save_data()

        await interaction.response.send_message(
            f"✅ You bought **{item['name']}** for **{price}** 🔹.\n"
            f"New token balance: **{p['wacky_tokens']}**.",
            ephemeral=False
        )

    # ---------------- /title_set <title> ----------------
    @client.tree.command(name="title_set", description="Set one of your owned titles as your active title.")
    async def title_set_cmd(interaction: Interaction, title: str):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first.",
                ephemeral=False
            )

        p = ensure_cosmetics(uid)

        if title not in p["owned_titles"]:
            return await interaction.response.send_message(
                f"You don't own the title `{title}`.\n"
                f"Use `/tokens_shop` to buy titles.",
                ephemeral=False
            )

        p["active_title"] = title
        save_data()

        await interaction.response.send_message(
            f"✅ Your active title is now **{title}**.",
            ephemeral=False
        )
