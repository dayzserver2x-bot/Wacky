import json
import os
from typing import Optional

import discord
from discord.ext import commands
from discord import app_commands, Interaction

TICKETS_CONFIG_FILE = "tickets_config.json"


# ---------- CONFIG PERSISTENCE ----------

def load_tickets_config() -> dict[int, dict]:
    if not os.path.exists(TICKETS_CONFIG_FILE):
        return {}
    try:
        with open(TICKETS_CONFIG_FILE, "r", encoding="utf-8") as f:
            raw = json.load(f)
        # JSON keys are strings; convert back to int
        return {int(gid): cfg for gid, cfg in raw.items()}
    except json.JSONDecodeError:
        print("Warning: tickets_config.json invalid, starting fresh.")
        return {}


def save_tickets_config():
    with open(TICKETS_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({str(gid): cfg for gid, cfg in tickets_config.items()}, f, indent=4)


tickets_config: dict[int, dict] = load_tickets_config()
# open_tickets is just in-memory: {user_id: channel_id}
open_tickets: dict[int, int] = {}


class OpenTicketView(discord.ui.View):
    """The button users click to create a ticket."""

    def __init__(self, cog: "TicketCog"):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Open Ticket",
        style=discord.ButtonStyle.primary,
        emoji="📨",
    )
    async def open_ticket(self, interaction: Interaction, button: discord.ui.Button):
        await self.cog.handle_open_ticket(interaction)


class TicketControlView(discord.ui.View):
    """Controls inside a ticket channel (e.g. Close button)."""

    def __init__(self, cog: "TicketCog"):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Close",
        style=discord.ButtonStyle.danger,
        emoji="🔒",
    )
    async def close_button(self, interaction: Interaction, button: discord.ui.Button):
        # Delegate to the same close logic used by /ticketclose
        await self.cog._close_ticket_channel(interaction)


class TicketCog(commands.Cog):
    """Simple support ticket system."""

    def __init__(self, bot: discord.Client):
        self.bot = bot

    # ---------- INTERNAL HELPERS ----------

    def get_guild_config(self, guild: discord.Guild) -> Optional[dict]:
        return tickets_config.get(guild.id)

    async def handle_open_ticket(self, interaction: Interaction):
        guild = interaction.guild
        user = interaction.user

        if guild is None:
            await interaction.response.send_message(
                "Tickets only work inside a server.",
                ephemeral=True,
            )
            return

        config = self.get_guild_config(guild)
        if not config or not config.get("category_id"):
            await interaction.response.send_message(
                "Ticket system is not configured yet. "
                "An admin needs to run **/ticketsetup** first.",
                ephemeral=True,
            )
            return

        category = guild.get_channel(config["category_id"])
        if not isinstance(category, discord.CategoryChannel):
            await interaction.response.send_message(
                "The configured ticket category no longer exists. "
                "Please ask an admin to run **/ticketsetup** again.",
                ephemeral=True,
            )
            return

        # If the user already has an open ticket, re-use it
        existing_id = open_tickets.get(user.id)
        if existing_id:
            existing_channel = guild.get_channel(existing_id)
            if isinstance(existing_channel, discord.TextChannel):
                await interaction.response.send_message(
                    f"You already have an open ticket: {existing_channel.mention}",
                    ephemeral=True,
                )
                return
            else:
                # Channel vanished, clear the mapping
                open_tickets.pop(user.id, None)

        staff_role = None
        staff_role_id = config.get("staff_role_id")
        if staff_role_id:
            staff_role = guild.get_role(staff_role_id)

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(
                read_messages=False,
                send_messages=False,
                view_channel=False,
            ),
            guild.me: discord.PermissionOverwrite(
                read_messages=True,
                send_messages=True,
                manage_channels=True,
                manage_messages=True,
                view_channel=True,
            ),
            user: discord.PermissionOverwrite(
                read_messages=True,
                send_messages=True,
                attach_files=True,
                embed_links=True,
                view_channel=True,
            ),
        }

        if staff_role is not None:
            overwrites[staff_role] = discord.PermissionOverwrite(
                read_messages=True,
                send_messages=True,
                manage_messages=True,
                view_channel=True,
            )

        safe_name = f"{user.name}".replace(" ", "-")
        channel_name = f"ticket-{safe_name}-{user.id}"

        ticket_channel = await guild.create_text_channel(
            name=channel_name[:90],
            category=category,
            overwrites=overwrites,
            reason=f"Support ticket opened by {user}",
        )

        open_tickets[user.id] = ticket_channel.id

        # --- Make it look like Ticket Tool style ---
        # Message content: ping user + "Welcome"
        content = f"{user.mention} Welcome"

        # Embed with short instructions and a small card feel
        embed = discord.Embed(
            description=(
                "Support will be with you shortly.\n"
                "To close this ticket, press the **🔒 Close** button below."
            ),
            color=discord.Color.green(),
        )
        embed.set_footer(text="Wacky Factory – Ticketing without clutter")

        view = TicketControlView(self)

        await ticket_channel.send(content=content, embed=embed, view=view)
        await interaction.response.send_message(
            f"Created your ticket: {ticket_channel.mention}",
            ephemeral=True,
        )

    async def _close_ticket_channel(self, interaction: Interaction):
        guild = interaction.guild
        channel = interaction.channel

        if guild is None or not isinstance(channel, discord.TextChannel):
            await interaction.response.send_message(
                "This command can only be used inside a ticket text channel.",
                ephemeral=True,
            )
            return

        config = self.get_guild_config(guild)
        if not config or not config.get("category_id"):
            await interaction.response.send_message(
                "Ticket system is not configured on this server.",
                ephemeral=True,
            )
            return

        # Basic check: channel is in the ticket category
        if not channel.category or channel.category.id != config["category_id"]:
            await interaction.response.send_message(
                "This channel is not recognized as a ticket channel.",
                ephemeral=True,
            )
            return

        # Simple permission check: ticket opener OR staff with Manage Channels
        staff_role_id = config.get("staff_role_id")
        staff_role = guild.get_role(staff_role_id) if staff_role_id else None

        opener_id = None
        for uid, cid in list(open_tickets.items()):
            if cid == channel.id:
                opener_id = uid
                break

        is_opener = opener_id is not None and interaction.user.id == opener_id
        is_staff = (
            staff_role is not None
            and staff_role in getattr(interaction.user, "roles", [])
        )
        has_manage_channels = interaction.user.guild_permissions.manage_channels

        if not (is_opener or is_staff or has_manage_channels):
            await interaction.response.send_message(
                "You don't have permission to close this ticket.",
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            "Closing and deleting this ticket channel...",
            ephemeral=True,
        )

        if opener_id in open_tickets and open_tickets[opener_id] == channel.id:
            open_tickets.pop(opener_id, None)

        await channel.delete(reason=f"Ticket closed by {interaction.user}")

    # ---------- SLASH COMMANDS ----------

    @app_commands.command(
        name="ticketsetup",
        description="Configure the ticket category and staff role for this server.",
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ticketsetup(
        self,
        interaction: Interaction,
        category: discord.CategoryChannel,
        staff_role: Optional[discord.Role] = None,
    ):
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message(
                "This command can only be used inside a server.",
                ephemeral=True,
            )
            return

        tickets_config[guild.id] = {
            "category_id": category.id,
            "staff_role_id": staff_role.id if staff_role else None,
        }
        save_tickets_config()

        msg = (
            f"Ticket system configured.\n"
            f"- Category: {category.mention}\n"
            f"- Staff role: {staff_role.mention if staff_role else 'Not set'}"
        )
        await interaction.response.send_message(msg, ephemeral=True)

    @app_commands.command(
        name="ticketpanel",
        description="Send the ticket creation panel in this channel.",
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ticketpanel(self, interaction: Interaction):
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message(
                "This command can only be used inside a server.",
                ephemeral=True,
            )
            return

        config = self.get_guild_config(guild)
        if not config or not config.get("category_id"):
            await interaction.response.send_message(
                "Ticket system is not configured yet. Run **/ticketsetup** first.",
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            title="🎫 Support Tickets",
            description=(
                "Need help? Click the button below to open a ticket.\n"
                "A private channel will be created where you can talk to staff."
            ),
            color=discord.Color.blurple(),
        )

        view = OpenTicketView(self)
        await interaction.channel.send(embed=embed, view=view)
        await interaction.response.send_message(
            "Ticket panel sent.",
            ephemeral=True,
        )

    @app_commands.command(
        name="ticketclose",
        description="Close this ticket channel.",
    )
    async def ticketclose(self, interaction: Interaction):
        # Slash-command alternative to the 🔒 button
        await self._close_ticket_channel(interaction)


def setup(client, players, save_players, ensure_player):
    """
    Wire the ticket system into the existing client.
    players/save_players/ensure_player are unused, kept for signature compatibility.
    """
    tickets = TicketCog(client)

    # Register slash commands on this client's CommandTree
    client.tree.add_command(tickets.ticketsetup)
    client.tree.add_command(tickets.ticketpanel)
    client.tree.add_command(tickets.ticketclose)
