import json
import os
from typing import Dict, Any

import discord
from discord import app_commands, Interaction

BUILDINGS_FILE = "data/buildings.json"


def load_buildings_def() -> Dict[str, Dict[str, Any]]:
    """Load building definitions from JSON, creating an empty default if missing/corrupt."""
    default: Dict[str, Dict[str, Any]] = {}

    # Ensure directory exists
    directory = os.path.dirname(BUILDINGS_FILE)
    if directory:
        os.makedirs(directory, exist_ok=True)

    if not os.path.exists(BUILDINGS_FILE):
        # Create file with default
        with open(BUILDINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(default, f, indent=4)
        return default

    try:
        with open(BUILDINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            return default
    except json.JSONDecodeError:
        # Backup corrupt file and reset
        try:
            os.replace(BUILDINGS_FILE, BUILDINGS_FILE + ".corrupt")
        except OSError:
            pass
        with open(BUILDINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(default, f, indent=4)
        return default


def setup(client: discord.Client, players: Dict[str, Dict[str, Any]], save_data, ensure_player):
    """
    Integrates the building system with the main Wacky Factory bot.

    - Uses the shared `players` dict (from players.json).
    - Stores per-player buildings under p["buildings"].
    - Spends normal factory money (`p["money"]`) to construct buildings.
    - Exposes a `/build` command group with:
        /build view
        /build list
        /build construct
    """
    buildings_def = load_buildings_def()

    def ensure_schema(uid: str) -> Dict[str, Any]:
        """Make sure this player has the keys we need."""
        p = players.setdefault(uid, {})
        p.setdefault("money", 0)
        p.setdefault("buildings", {})
        return p

    build_group = app_commands.Group(
        name="build",
        description="Manage special buildings for your factory.",
    )

    # -------------------------
    # /build view
    # -------------------------
    @build_group.command(name="view", description="View buildings you have constructed.")
    async def build_view(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            await interaction.response.send_message(
                "❌ You need to start your factory first. Use `/start`.",
                ephemeral=False,
            )
            return

        p = ensure_schema(uid)
        bdata: Dict[str, Dict[str, Any]] = p.get("buildings", {})

        if not bdata:
            await interaction.response.send_message(
                "🏗️ You haven't constructed any special buildings yet.",
                ephemeral=False,
            )
            return

        embed = discord.Embed(
            title=f"{interaction.user.display_name}'s Buildings",
            color=discord.Color.gold(),
        )

        for bid, state in bdata.items():
            bdef = buildings_def.get(bid, {})
            name = bdef.get("name", bid)
            emoji = bdef.get("emoji", "🏗️")
            desc = bdef.get("description", "No description.")
            built = state.get("built", False)
            level = state.get("level", 1)

            status = "✅ Built" if built else "❌ Not built"
            embed.add_field(
                name=f"{emoji} {name} (Lv {level})",
                value=f"{status}\n{desc}",
                inline=False,
            )

        await interaction.response.send_message(embed=embed, ephemeral=False)

    # -------------------------
    # /build list
    # -------------------------
    @build_group.command(name="list", description="See all available buildings you can construct.")
    async def build_list(interaction: Interaction):
        if not buildings_def:
            await interaction.response.send_message(
                "ℹ️ There are no building definitions configured yet.",
                ephemeral=False,
            )
            return

        uid = str(interaction.user.id)
        if not ensure_player(uid):
            await interaction.response.send_message(
                "❌ You need to start your factory first. Use `/start`.",
                ephemeral=False,
            )
            return

        p = ensure_schema(uid)
        owned = p.get("buildings", {})

        embed = discord.Embed(
            title="Available Buildings",
            color=discord.Color.blurple(),
        )

        for bid, bdef in buildings_def.items():
            name = bdef.get("name", bid)
            emoji = bdef.get("emoji", "🏗️")
            desc = bdef.get("description", "No description.")
            cost = int(bdef.get("market_cost", 0))
            state = owned.get(bid, {})
            status = "✅ Built" if state.get("built") else "🔒 Not built"

            embed.add_field(
                name=f"{emoji} {name} (`{bid}`)",
                value=(
                    f"{desc}\n"
                    f"Cost: **${cost:,}**\n"
                    f"Status: {status}"
                ),
                inline=False,
            )

        await interaction.response.send_message(embed=embed, ephemeral=False)

    # Precompute choices for /build construct
    building_choices = [
        app_commands.Choice(name=bdef.get("name", bid), value=bid)
        for bid, bdef in buildings_def.items()
    ]

    # -------------------------
    # /build construct
    # -------------------------
    @build_group.command(name="construct", description="Spend money to construct a building.")
    @app_commands.choices(building_id=building_choices)
    async def build_construct(
        interaction: Interaction,
        building_id: app_commands.Choice[str],
    ):
        if not buildings_def:
            await interaction.response.send_message(
                "ℹ️ There are no building definitions configured yet.",
                ephemeral=False,
            )
            return

        uid = str(interaction.user.id)
        if not ensure_player(uid):
            await interaction.response.send_message(
                "❌ You need to start your factory first. Use `/start`.",
                ephemeral=False,
            )
            return

        bid = building_id.value
        bdef = buildings_def.get(bid)
        if not bdef:
            await interaction.response.send_message(
                "❌ That building no longer exists in the config.",
                ephemeral=False,
            )
            return

        p = ensure_schema(uid)
        buildings = p.setdefault("buildings", {})
        state = buildings.get(
            bid,
            {"built": False, "level": 0},
        )

        if state.get("built"):
            await interaction.response.send_message(
                "❌ You already constructed that building.",
                ephemeral=False,
            )
            return

        cost = int(bdef.get("market_cost", 0))
        money = int(p.get("money", 0))

        if money < cost:
            await interaction.response.send_message(
                f"❌ You need **${cost:,}** to construct **{bdef.get('name', bid)}**, "
                f"but you only have **${money:,}**.",
                ephemeral=False,
            )
            return

        # Deduct and build
        p["money"] = money - cost
        state["built"] = True
        if state.get("level", 0) <= 0:
            state["level"] = 1
        buildings[bid] = state

        save_data()

        await interaction.response.send_message(
            f"{bdef.get('emoji', '🏗️')} You constructed the **{bdef.get('name', bid)}** "
            f"for **${cost:,}**!",
            ephemeral=False,
        )

    # Register the group with the client's command tree
    client.tree.add_command(build_group)
