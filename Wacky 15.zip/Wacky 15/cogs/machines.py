# cogs/machines.py

import discord
from discord.ext import tasks
from discord import Interaction
from discord.ui import View, Select
from cogs.machine_data import MACHINE_DATA, MACHINES

# -------------- Balance knobs (Balanced preset) --------------
def max_durability_for_tier(tier: int) -> int:
    return 60 + 10 * max(1, int(tier))

def money_repair_cost_for_tier(tier: int) -> int:
    return 600 * max(1, int(tier))

REPAIR_PARTS_BY_TIER = {
    1: {"Scrap Bits": 8},
    2: {"Steel Sheet": 3, "Coal": 4},
    3: {"Circuit Board": 2, "Servo Motor": 1},
    4: {"Gizmo": 1, "Plastic Polymer": 4},
    5: {"Nanosteel Plate": 1, "Lubricant Fluid": 6},
    6: {"Hull Plating": 1, "Navigation Core": 1},
}

# -------------- Existing helpers --------------
def calc_cycle_time(machine_name, lvl):
    if machine_name not in MACHINE_DATA:
        return 999
    return max(8, int(MACHINE_DATA[machine_name]["base_time"] * (0.92 ** (lvl - 1))))

def calc_output(machine_name, lvl):
    if machine_name not in MACHINE_DATA:
        return {}
    base = MACHINE_DATA[machine_name]["output"]
    scaled = {}
    for item, amt in base.items():
        scaled[item] = int(amt * (1 + (lvl - 1) * 0.15))
    return scaled

# -------------- Durability --------------
def ensure_durability_fields(machine_name: str, m: dict):
    tier = MACHINE_DATA.get(machine_name, {}).get("tier", 1)
    if "max_durability" not in m:
        m["max_durability"] = max_durability_for_tier(tier)
    if "durability" not in m:
        m["durability"] = m["max_durability"]

def repair_recipe_for_tier(tier: int) -> dict:
    return REPAIR_PARTS_BY_TIER.get(int(tier), {"Scrap Bits": 10})

def has_parts(inv: dict, recipe: dict) -> bool:
    return all(inv.get(k, 0) >= v for k, v in recipe.items())

def consume_parts(inv: dict, recipe: dict):
    for k, v in recipe.items():
        inv[k] -= v
        if inv[k] <= 0:
            inv.pop(k, None)

def can_player_craft_parts(player: dict, machine_tier: int) -> bool:
    return int(player.get("tier", 1)) >= int(machine_tier)

# -------------- Globals --------------
players_ref = None
save_data_ref = None
client_ref = None

# ============================================================
# MACHINE TICK
# ============================================================

@tasks.loop(seconds=15)
async def machine_tick():
    if players_ref is None or save_data_ref is None:
        return

    for uid, p in players_ref.items():
        p.setdefault("workers", {"money": 0, "machine": 0, "craft": 0, "prestige": 0, "storage": 0})
        inv = p.setdefault("inventory", {})
        p.setdefault("alerts", [])
        p.setdefault("machines", {})
        p.setdefault("blueprints", {})

        storage_cap = 200 + p["workers"]["storage"] * 200

        for name, m in p["machines"].items():
            if name not in MACHINE_DATA:
                continue
            ensure_durability_fields(name, m)

            if m.get("level", 0) <= 0:
                continue
            if not p["blueprints"].get(name, True):
                continue

            automation = m.get("automation")
            overdrive = automation == "Overdrive Mode"

            # stop if broken
            if m["durability"] <= 0:
                m["running"] = False
                continue

            # autostart if automation
            if not m["running"]:
                if automation == "Basic Automation" and inv.get("Coal", 0) >= MACHINE_DATA[name]["fuel_per_cycle"]:
                    m["running"] = True
                else:
                    continue

            # re-check inventory size per machine
            inv_count = sum(inv.values())
            if inv_count >= storage_cap:
                m["running"] = False
                # 🔔 storage full alert
                alert = "📦 Storage is full! Machines have paused until you increase storage or clear inventory."
                if alert not in p["alerts"]:
                    p["alerts"].append(alert)
                    channel_id = p.get("factory_channel")
                    if channel_id and client_ref:
                        ch = client_ref.get_channel(channel_id)
                        if ch:
                            await ch.send(f"<@{uid}> {alert}")
                continue

            # fuel
            fuel_need = MACHINE_DATA[name]["fuel_per_cycle"]
            if overdrive:
                fuel_need *= 2

            if fuel_need > 0:
                if inv.get("Coal", 0) < fuel_need:
                    m["running"] = False
                    alert = f"⛽ **{name}** stopped — Out of coal!"
                    if alert not in p["alerts"]:
                        p["alerts"].append(alert)
                        channel_id = p.get("factory_channel")
                        if channel_id and client_ref:
                            ch = client_ref.get_channel(channel_id)
                            if ch:
                                await ch.send(f"<@{uid}> {alert}")
                    continue

                inv["Coal"] -= fuel_need
                if inv["Coal"] <= 0:
                    inv.pop("Coal", None)

            # tick
            m["progress"] += 15
            if m["progress"] >= calc_cycle_time(name, m["level"]):
                m["progress"] = 0

                # add outputs, but don't exceed storage_cap
                for item, base_amt in MACHINE_DATA[name]["output"].items():
                    amt = int(base_amt * 1.5) if overdrive else base_amt

                    inv_count = sum(inv.values())
                    space = storage_cap - inv_count
                    if space <= 0:
                        m["running"] = False
                        # we already hit full; no need to spam alerts again here
                        break

                    to_add = min(amt, space)
                    if to_add <= 0:
                        continue

                    inv[item] = inv.get(item, 0) + to_add

                # durability loss
                m["durability"] = max(0, m["durability"] - 1)

                # break alert
                if m["durability"] <= 0:
                    m["running"] = False
                    alert = f"🛠️ **{name}** broke down — needs repair!"
                    if alert not in p["alerts"]:
                        p["alerts"].append(alert)
                        channel_id = p.get("factory_channel")
                        if channel_id and client_ref:
                            ch = client_ref.get_channel(channel_id)
                            if ch:
                                await ch.send(f"<@{uid}> {alert}")

        save_data_ref()


# ============================================================
# UI PANELS
# ============================================================


class MachineSelect(Select):
    def __init__(self, machines):
        options = []

        # sanitize machines
        safe = {}
        for name, m in machines.items():
            if isinstance(m, dict):
                safe[name] = m
        machines = safe

        for name, m in machines.items():
            level = m.get("level", 0)
            if level >= 1:
                options.append(
                    discord.SelectOption(
                        label=f"🔒 {name}",
                        description=f"Owned • Level {level}",
                        value=f"owned_{name}",
                        emoji="🚫",
                    )
                )
            else:
                options.append(
                    discord.SelectOption(
                        label=name,
                        description="Available to purchase",
                        value=name,
                    )
                )

        if len(options) == 0:
            options = [
                discord.SelectOption(
                    label="No machines available",
                    description="You do not own or have access to any machines yet.",
                    value="none",
                )
            ]

        super().__init__(
            placeholder="Select a machine",
            options=options,
            min_values=1,
            max_values=1,
        )


class MachinePanel(View):
    def __init__(self, uid, players, save_data, return_factory=None):
        super().__init__(timeout=180)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.return_factory = return_factory

        # Clean invalid machine entries BEFORE counting
        raw = players[uid].get("machines", {})
        cleaned = {
            name: m
            for name, m in raw.items()
            if isinstance(m, dict) and "level" in m
        }

        # Limit to 25 options (Discord hard limit)
        limited = dict(list(cleaned.items())[:25])

        # Always provide at least 1 valid option
        if not limited:
            limited = {"No Machines": {"level": 0}}

        # Create select safely
        self.add_item(MachineSelect(limited))

    @discord.ui.button(label="⬅️ Back", style=discord.ButtonStyle.danger)
    async def back_btn(self, interaction: Interaction, _):
        """Return to the main FactoryView panel."""
        from cogs.ui import fmt_embed

        p = self.players[self.uid]

        # If we have a FactoryView to return to, show it
        if self.return_factory is not None:
            await interaction.response.edit_message(
                embed=fmt_embed(interaction.user, p),
                view=self.return_factory,
            )
        else:
            # Fallback: just delete the panel if no factory view
            await interaction.response.edit_message(
                content="Closed machines panel.", embed=None, view=None
            )

    # -----------------------------------------------------------
    # get_embed — Black & Gold multi-machine dashboard
    # -----------------------------------------------------------
    def get_embed(self, user):
        p = self.players[self.uid]
        inv = p.get("inventory", {})
        fuel = inv.get("Coal", 0)

        # -----------------------------------
        # ULTRA PREMIUM PROGRESS BAR (Yellow–Gold blocks)
        # -----------------------------------
        def emoji_bar(cur, maxv, size=10, mode="cycle"):
            if maxv <= 0:
                return "—"

            pct = max(0, min(1, cur / maxv))
            filled = int(pct * size)

            if mode == "durability":
                if pct <= 0.25:
                    color = "🟥"
                elif pct <= 0.5:
                    color = "🟧"
                elif pct <= 0.75:
                    color = "🟨"
                else:
                    color = "🟨"
            else:
                color = "🟨"

            return color * filled + "⬛" * (size - filled)

        embed = discord.Embed(
            title="🏭 **Prestige Machine Deck**",
            description=(
                "✦━━━━━━━━━━━━ **SYSTEM STATUS** ━━━━━━━━━━━━✦\n"
                f"💰 **Money:** ${p.get('money', 0):,}\n"
                f"⛽ **Coal Fuel:** {fuel}x\n"
            ),
            color=discord.Color.from_rgb(5, 5, 5),
        )

        shown = False
        machine_count = 0

        for name, m in p["machines"].items():
            if name not in MACHINE_DATA:
                continue
            if m.get("level", 0) <= 0:
                continue

            ensure_durability_fields(name, m)
            shown = True
            machine_count += 1

            level = m["level"]
            cycle_len = calc_cycle_time(name, level)

            cycle_bar = emoji_bar(m.get("progress", 0), cycle_len, mode="cycle")
            dur_now = m["durability"]
            dur_max = m["max_durability"]
            dur_bar = emoji_bar(dur_now, dur_max, mode="durability")

            if dur_now <= 0:
                status_icon = "💥"
                status_label = "Broken"
            elif m["running"]:
                status_icon = "🟢"
                status_label = "Running"
            else:
                status_icon = "⛔"
                status_label = "Stopped"

            mode = m.get("automation") or "Manual"
            mode_icon = (
                "⚙️"
                if mode == "Basic Automation"
                else ("🔥" if mode == "Overdrive Mode" else "🖐️")
            )

            out = MACHINE_DATA[name]["output"]
            out_lines = "\n".join(f"• **{item} ×{out[item]}**" for item in out)

            embed.add_field(
                name=f"{status_icon} **{name} — Lv {level}**",
                value=(
                    "✦━━━━━━━━ **CYCLE** ━━━━━━━━✦\n"
                    f"{cycle_bar}\n"
                    f"*Progress* `{m.get('progress', 0)}/{cycle_len}s`\n\n"
                    "✦━━━━━━━ **DURABILITY** ━━━━━━━✦\n"
                    f"{dur_bar}\n"
                    f"*Health* `{dur_now}/{dur_max}`\n\n"
                    "✦━━━━━━━━ **DETAILS** ━━━━━━━━✦\n"
                    f"**Status:** {status_icon} **{status_label}**\n"
                    f"**Automation:** {mode_icon} {mode}\n"
                    f"**Cycle Time:** `{cycle_len}s`\n"
                    f"**Output:**\n{out_lines}"
                ),
                inline=False,
            )

            if machine_count >= 15:
                embed.add_field(
                    name="…and more",
                    value="Too many machines to show in one panel.",
                    inline=False,
                )
                break

        if not shown:
            embed.add_field(
                name="No Machines Found",
                value="You haven't purchased any machines yet.",
                inline=False,
            )

        if p["alerts"]:
            embed.add_field(
                name="⚠ Alerts",
                value="\n".join(p["alerts"][:10]),
                inline=False,
            )
            p["alerts"].clear()

        return embed

    # -----------------------------------------------------------
    # open_machine — Gold prestige single machine view
    # -----------------------------------------------------------
    async def open_machine(self, interaction: Interaction, machine_name):
        p = self.players[self.uid]
        m = p["machines"][machine_name]
        data = MACHINE_DATA.get(machine_name)

        ensure_durability_fields(machine_name, m)

        level = m["level"]
        tier = data.get("tier", 1)
        upgrade_cost = int(300 * tier * (1.25 ** (level - 1)))

        current_cycle = calc_cycle_time(machine_name, level)
        next_cycle = calc_cycle_time(machine_name, level + 1)

        curr_output = calc_output(machine_name, level)
        next_output = calc_output(machine_name, level + 1)
        output_str = "\n".join(
            f"• {item}: **×{curr_output[item]}** → **×{next_output[item]}**"
            for item in curr_output
        )

        mode = m.get("automation") or "—"
        mode_emoji = (
            "⚙️"
            if mode == "Basic Automation"
            else ("🔥" if mode == "Overdrive Mode" else "—")
        )

        dur_now = m["durability"]
        dur_max = m["max_durability"]
        dur_pct = dur_now / dur_max * 100 if dur_max > 0 else 0

        progress_now = m.get("progress", 0)

        def emoji_bar(cur, maxv, size=12, mode="cycle"):
            if maxv <= 0:
                return "—"
            pct = max(0, min(1, cur / maxv))
            filled = int(pct * size)

            if mode == "durability":
                if pct <= 0.25:
                    color = "🟥"
                elif pct <= 0.5:
                    color = "🟧"
                elif pct <= 0.75:
                    color = "🟨"
                else:
                    color = "🟨"
            else:
                color = "🟨"

            return color * filled + "⬛" * (size - filled)

        progress_bar = emoji_bar(progress_now, current_cycle, mode="cycle")
        dur_bar = emoji_bar(dur_now, dur_max, mode="durability")

        broken_note = (
            "\n**Status:** 💥 Broken — repair required" if dur_now <= 0 else ""
        )

        recipe = repair_recipe_for_tier(tier)
        need_lines = "\n".join(f"• {k} × {v}" for k, v in recipe.items())
        money_cost = money_repair_cost_for_tier(tier)

        can_craft = can_player_craft_parts(p, tier)
        repair_lines = (
            need_lines if can_craft else "Your tier is too low to craft the parts."
        )

        repair_block = (
            f"**Repair (parts):**\n{repair_lines}\n"
            f"**Repair (money):** ${money_cost:,}"
        )

        if dur_now <= 0:
            status_icon = "💥"
            status_label = "Broken"
        elif m["running"]:
            status_icon = "🟢"
            status_label = "Running"
        else:
            status_icon = "⛔"
            status_label = "Stopped"

        desc = (
            "✦━━━━━━━━━━ **MACHINE OVERVIEW** ━━━━━━━━━━✦\n"
            f"{status_icon} **Status:** {status_label}\n"
            f"🏷 **Level:** {level}  •  ⚙️ **Tier:** {tier}\n"
            f"{mode_emoji} **Automation:** {mode}\n"
            f"⛽ **Fuel per Cycle:** {data['fuel_per_cycle']} Coal\n\n"
            "✦━━━━━━━━━━━━ **CYCLE** ━━━━━━━━━━━━✦\n"
            f"{progress_bar}\n"
            f"*Progress* `{progress_now}/{current_cycle}s`\n\n"
            "✦━━━━━━━━ **DURABILITY** ━━━━━━━━✦\n"
            f"{dur_bar}\n"
            f"*Health* `{dur_now}/{dur_max}` • **{dur_pct:.0f}%**"
            f"{broken_note}\n\n"
            "✦━━━━━━━━ **UPGRADE & OUTPUT** ━━━━━━━━✦\n"
            f"⏱ **Cycle Time:** `{current_cycle}s` → `{next_cycle}s`\n"
            f"💰 **Upgrade Cost:** ${upgrade_cost:,}\n"
            f"📦 **Output per Cycle:**\n{output_str}\n\n"
            "✦━━━━━━━━━━ **REPAIR OPTIONS** ━━━━━━━━━━✦\n"
            f"{repair_block}"
        )

        color = (
            discord.Color.from_str("#D4AF37")
            if (m["running"] and dur_now > 0)
            else discord.Color.from_str("#FF5555")
            if dur_now <= 0
            else discord.Color.from_str("#C0C0C0")
        )

        embed = discord.Embed(
            title=f"🏆 {machine_name} — Prestige Controls",
            description=desc,
            color=color,
        )

        panel = MachineControlPanel(
            self.uid, self.players, self.save_data, machine_name, self.return_factory
        )
        await interaction.response.send_message(embed=embed, view=panel)


class MachineControlPanel(View):
    def __init__(self, uid, players, save_data, machine, return_factory=None):
        super().__init__(timeout=90)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.machine = machine
        self.return_factory = return_factory
        from cogs.automation import AutomateButton

        self.add_item(AutomateButton(machine))

    @discord.ui.button(label="Start", style=discord.ButtonStyle.success)
    async def toggle_btn(self, interaction: Interaction, _):
        p = self.players[self.uid]
        m = p["machines"][self.machine]
        if int(m.get("durability", 0)) <= 0:
            return await interaction.response.send_message(
                "💥 This machine is broken. Repair it first.", ephemeral=True
            )
        m["running"] = not m["running"]
        self.save_data()
        await self.refresh(interaction)

    @discord.ui.button(label="Upgrade", style=discord.ButtonStyle.secondary)
    async def upgrade_btn(self, interaction: Interaction, _):
        p = self.players[self.uid]
        m = p["machines"][self.machine]
        data = MACHINE_DATA.get(self.machine)
        if not data:
            return await interaction.response.send_message(
                "❌ This machine no longer exists.", ephemeral=True
            )
        level = m["level"]
        tier = data.get("tier", 1)
        cost = int(300 * tier * (1.25 ** (level - 1)))

        if p.get("money", 0) < cost:
            return await interaction.response.send_message(
                f"💸 You need **${cost:,}** to upgrade this machine!", ephemeral=True
            )

        p["money"] -= cost
        m["level"] += 1

        ensure_durability_fields(self.machine, m)
        m["max_durability"] = max(
            m["max_durability"], max_durability_for_tier(tier)
        )
        m["durability"] = min(m["max_durability"], m["durability"] + 5)

        self.save_data()
        await self.refresh(interaction)

    @discord.ui.button(label="🛠️ Repair (Parts)", style=discord.ButtonStyle.primary)
    async def repair_parts_btn(self, interaction: Interaction, _):
        p = self.players[self.uid]
        m = p["machines"][self.machine]
        data = MACHINE_DATA.get(self.machine)
        if not data:
            return await interaction.response.send_message(
                "❌ This machine no longer exists.", ephemeral=True
            )

        tier = data.get("tier", 1)
        ensure_durability_fields(self.machine, m)

        if int(m.get("durability", 0)) >= int(m.get("max_durability", 0)):
            return await interaction.response.send_message(
                "✅ Already at full durability.", ephemeral=True
            )

        recipe = repair_recipe_for_tier(tier)
        inv = p.setdefault("inventory", {})

        if not can_player_craft_parts(p, tier):
            return await interaction.response.send_message(
                "🔒 Your factory tier is too low to craft these parts.\n"
                "Use **Pay to Repair** instead.",
                ephemeral=True,
            )

        if not has_parts(inv, recipe):
            need = ", ".join([f"{k}×{v}" for k, v in recipe.items()])
            return await interaction.response.send_message(
                f"❌ Not enough parts to repair.\nNeeded: {need}",
                ephemeral=True,
            )

        consume_parts(inv, recipe)
        m["durability"] = m["max_durability"]
        self.save_data()
        await self.refresh(interaction)

    @discord.ui.button(label="💴 Pay to Repair", style=discord.ButtonStyle.success)
    async def repair_money_btn(self, interaction: Interaction, _):
        p = self.players[self.uid]
        m = p["machines"][self.machine]
        data = MACHINE_DATA.get(self.machine)
        if not data:
            return await interaction.response.send_message(
                "❌ This machine no longer exists.", ephemeral=True
            )

        tier = data.get("tier", 1)
        ensure_durability_fields(self.machine, m)

        if int(m.get("durability", 0)) >= int(m.get("max_durability", 0)):
            return await interaction.response.send_message(
                "✅ Already at full durability.", ephemeral=True
            )

        cost = money_repair_cost_for_tier(tier)
        if p.get("money", 0) < cost:
            return await interaction.response.send_message(
                f"💸 You need **${cost:,}** to repair with money.",
                ephemeral=True,
            )

        p["money"] -= cost
        m["durability"] = m["max_durability"]
        self.save_data()
        await self.refresh(interaction)

    @discord.ui.button(label="⬅️ Back", style=discord.ButtonStyle.danger)
    async def back_btn(self, interaction: Interaction, _):
        # Back from single-machine view → machine list panel
        await interaction.response.defer()

        panel = MachinePanel(
            self.uid,
            self.players,
            self.save_data,
            return_factory=self.return_factory,
        )

        await interaction.message.edit(
            embed=panel.get_embed(interaction.user),
            view=panel,
        )

    async def refresh(self, interaction):
        p = self.players[self.uid]
        m = p["machines"][self.machine]
        data = MACHINE_DATA.get(self.machine)
        if not data:
            return await interaction.response.send_message(
                "❌ This machine no longer exists.", ephemeral=True
            )

        ensure_durability_fields(self.machine, m)

        level = m["level"]
        tier = data.get("tier", 1)
        upgrade_cost = int(300 * tier * (1.25 ** (level - 1)))
        current_cycle = calc_cycle_time(self.machine, level)
        next_cycle = calc_cycle_time(self.machine, level + 1)
        curr_output = calc_output(self.machine, level)
        next_output = calc_output(self.machine, level + 1)
        output_str = "\n".join(
            f"• {item}: **×{curr_output[item]}** → **×{next_output[item]}**"
            for item in curr_output
        )
        mode = m.get("automation") or "—"
        mode_emoji = (
            "⚙️"
            if mode == "Basic Automation"
            else ("🔥" if mode == "Overdrive Mode" else "—")
        )

        dur_now = int(m.get("durability", 0))
        dur_max = int(
            m.get("max_durability", max_durability_for_tier(tier))
        )
        dur_pct = (dur_now / dur_max * 100) if dur_max > 0 else 0
        broken_note = (
            "\n**Status:** 💥 Broken — repair required" if dur_now <= 0 else ""
        )

        recipe = repair_recipe_for_tier(tier)
        need_lines = [f"• {k} × {v}" for k, v in recipe.items()]
        money_cost = money_repair_cost_for_tier(tier)
        can_craft = can_player_craft_parts(p, tier)
        repair_lines = (
            "\n".join(need_lines)
            if can_craft
            else "Your tier is too low to craft the parts."
        )
        repair_block = (
            f"**Repair (parts):**\n{repair_lines}\n"
            f"**Repair (money):** ${money_cost:,}"
        )

        def emoji_bar(cur, maxv, size=12, mode="cycle"):
            if maxv <= 0:
                return "—"
            pct = max(0, min(1, cur / maxv))
            filled = int(pct * size)

            if mode == "durability":
                if pct <= 0.25:
                    color = "🟥"
                elif pct <= 0.5:
                    color = "🟧"
                elif pct <= 0.75:
                    color = "🟨"
                else:
                    color = "🟨"
            else:
                color = "🟨"

            return color * filled + "⬛" * (size - filled)

        progress_now = m.get("progress", 0)
        progress_bar = emoji_bar(progress_now, current_cycle, mode="cycle")
        dur_bar = (
            emoji_bar(dur_now, dur_max, mode="durability")
            if dur_max > 0
            else "—"
        )

        if dur_now <= 0:
            status_icon = "💥"
            status_label = "Broken"
        elif m["running"]:
            status_icon = "🟢"
            status_label = "Running"
        else:
            status_icon = "⛔"
            status_label = "Stopped"

        desc = (
            "✦━━━━━━━━━━ **MACHINE OVERVIEW** ━━━━━━━━━━✦\n"
            f"{status_icon} **Status:** {status_label}\n"
            f"🏷 **Level:** {level}  •  ⚙️ **Tier:** {tier}\n"
            f"{mode_emoji} **Automation:** {mode}\n"
            f"⛽ **Fuel per Cycle:** {data['fuel_per_cycle']} Coal\n\n"
            "✦━━━━━━━━━━━━ **CYCLE** ━━━━━━━━━━━━✦\n"
            f"{progress_bar}\n"
            f"*Progress* `{progress_now}/{current_cycle}s`\n\n"
            "✦━━━━━━━━ **DURABILITY** ━━━━━━━━✦\n"
            f"{dur_bar}\n"
            f"*Health* `{dur_now}/{dur_max}` • **{dur_pct:.0f}%**"
            f"{broken_note}\n\n"
            "✦━━━━━━━━ **UPGRADE & OUTPUT** ━━━━━━━━✦\n"
            f"⏱ **Cycle Time:** `{current_cycle}s` → `{next_cycle}s`\n"
            f"💰 **Upgrade Cost:** ${upgrade_cost:,}\n"
            f"📦 **Output per Cycle:**\n{output_str}\n\n"
            "✦━━━━━━━━━━ **REPAIR OPTIONS** ━━━━━━━━━━✦\n"
            f"{repair_block}"
        )

        color = (
            discord.Color.from_str("#D4AF37")
            if (m["running"] and dur_now > 0)
            else discord.Color.from_str("#FF5555")
            if dur_now <= 0
            else discord.Color.from_str("#C0C0C0")
        )

        embed = discord.Embed(
            title=f"🏆 {self.machine} — Prestige Controls",
            description=desc,
            color=color,
        )

        for child in self.children:
            if child.label in ("Start", "Stop"):
                if dur_now <= 0:
                    child.label = "Start"
                    child.style = discord.ButtonStyle.success
                else:
                    if m["running"]:
                        child.label = "Stop"
                        child.style = discord.ButtonStyle.danger
                    else:
                        child.label = "Start"
                        child.style = discord.ButtonStyle.success

        await interaction.response.edit_message(embed=embed, view=self)

# ========== SETUP FUNCTION (kept behavior) ==========

def setup(client, players, save_data, ensure_player):
    global players_ref, save_data_ref, client_ref
    players_ref = players
    save_data_ref = save_data
    client_ref = client

    for p in players.values():
        p.setdefault("inventory", {})
        p.setdefault("blueprints", {})
        p.setdefault("machines", {})
        for name in MACHINES:
            m = p["machines"].setdefault(name, {})
            m.setdefault("level", 0)
            m.setdefault("running", False)
            m.setdefault("progress", 0)
            m.setdefault("automation", None)
            ensure_durability_fields(name, m)

    @client.tree.command(name="machines", description="Open your machine control panel.")
    async def machines_cmd(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")
        players[uid]["factory_channel"] = interaction.channel.id
        from cogs.ui import FactoryView, fmt_embed

        panel = MachinePanel(
            uid,
            players,
            save_data,
            return_factory=FactoryView(
                uid, players, save_data, ensure_player, client
            ),
        )

        await interaction.response.send_message(
            embed=panel.get_embed(interaction.user),
            view=panel,
        )

 