import discord
from discord import Interaction
from discord.ui import View, Select

players_ref = None
save_data_ref = None


# ===========================
# ⚙️ AUTOMATION VIEW & SELECT
# ===========================

class AutomateSelect(Select):
    def __init__(self, uid, machine_name):
        options = [
            discord.SelectOption(label="Basic Automation", description="Runs automatically when fuel is available."),
            discord.SelectOption(label="Overdrive Mode", description="Uses 2× fuel for 1.5× output."),
            discord.SelectOption(label="Disable Automation", description="Turn off automation for this machine."),
        ]
        super().__init__(placeholder="Select automation mode...", options=options)
        self.uid = uid
        self.machine_name = machine_name

    async def callback(self, interaction: Interaction):
        player = players_ref[self.uid]
        machine = player["machines"][self.machine_name]
        choice = self.values[0]

        # ✅ Apply the choice
        if choice == "Disable Automation":
            machine["automation"] = None
        else:
            machine["automation"] = choice

        save_data_ref()

        await interaction.response.edit_message(
            content=f"✅ **{self.machine_name}** automation set to **{choice}**.",
            view=None
        )


class AutomateView(View):
    def __init__(self, uid, machine_name):
        super().__init__(timeout=60)
        self.add_item(AutomateSelect(uid, machine_name))


# ===========================
# ⚙️ AUTOMATE BUTTON
# ===========================

class AutomateButton(discord.ui.Button):
    def __init__(self, machine_name):
        super().__init__(label="⚙️ Automate", style=discord.ButtonStyle.primary)
        self.machine_name = machine_name

    async def callback(self, interaction: Interaction):
        uid = str(interaction.user.id)

        if uid not in players_ref:
            return await interaction.response.send_message("Run **/start** first.", ephemeral=False)

        player = players_ref[uid]

        from cogs.machine_data import MACHINE_DATA
        fuel_cost = MACHINE_DATA[self.machine_name]["fuel_per_cycle"]

        # 🚫 Skip machines that don't use fuel
        if fuel_cost <= 0:
            return await interaction.response.send_message(
                "⚠️ This machine doesn’t use fuel, so automation isn’t needed!",
                ephemeral=False
            )

        view = AutomateView(uid, self.machine_name)
        await interaction.response.send_message(
            content=f"Select automation mode for **{self.machine_name}**:",
            view=view,
            ephemeral=False
        )


# ===========================
# 🔧 SETUP
# ===========================

def setup(client, players, save_data, ensure_player):
    global players_ref, save_data_ref
    players_ref = players
    save_data_ref = save_data
