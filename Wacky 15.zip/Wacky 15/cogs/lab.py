# cogs/lab.py
# Integrated Research Lab for Wacky Factory
# Uses shared players dict instead of data/players.json

from __future__ import annotations

import discord
from discord import app_commands
from typing import Dict, Any

# References injected by main.setup()
players_ref: Dict[str, Dict[str, Any]] | None = None
save_data_ref = None
ensure_player_ref = None

# ---------------------------------------------------------------------------
# Research definitions
# ---------------------------------------------------------------------------

RESEARCH_TOPICS: Dict[str, Dict[str, Any]] = {
    "basic_efficiency": {
        "name": "Basic Efficiency",
        "description": "Machines consume 5% less fuel per cycle.",
        "cost": 5,
        "effects": [
            "Slightly reduces per-tick fuel use in machines.",
        ],
    },
    "faster_machines": {
        "name": "Faster Machines",
        "description": "Your machines work 10% faster.",
        "cost": 50,
        "effects": [
            "Increases machine_tick throughput.",
        ],
    },
    "better_shipping": {
        "name": "Optimized Shipping",
        "description": "Improves Shipping Center payouts slightly.",
        "cost": 30,
        "effects": [
            "Buffs shipping payouts.",
        ],
    },
    "worker_training": {
        "name": "Worker Training Program",
        "description": "Workers gain a small productivity bonus.",
        "cost": 40,
        "effects": [
            "Used by workers / orders systems.",
        ],
    },
    "lab_express": {
        "name": "Lab Express Setup",
        "description": "Unlocks quick RP gain from certain tasks.",
        "cost": 20,
        "effects": [
            "Lets you earn RP from Shipping Center orders.",
        ],
    },
}


def _get_player(uid: int) -> Dict[str, Any]:
    """Helper to get / init a player's lab-related data.

    Raises:
        RuntimeError: If the Lab has not been initialized via setup().
        ValueError: If the player has not started their factory yet.
    """
    if players_ref is None or ensure_player_ref is None:
        raise RuntimeError("Lab not initialized: setup() was not called.")

    # Global ensure_player expects a string user id and returns True/False
    if not ensure_player_ref(str(uid)):
        # Player hasn't started a factory yet
        raise ValueError("Player has not started a factory.")

    p = players_ref[str(uid)]

    # Ensure lab-related fields exist
    p.setdefault("research_points", 0)
    p.setdefault("research", {})  # dict of research_id -> bool/unlocked

    return p


def _save():
    if save_data_ref is not None:
        save_data_ref()


# ---------------------------------------------------------------------------
# Embeds
# ---------------------------------------------------------------------------

def build_lab_overview_embed(user: discord.abc.User, p: Dict[str, Any]) -> discord.Embed:
    rp = p.get("research_points", 0)
    unlocked = p.get("research", {})

    embed = discord.Embed(
        title="🔬 Research Lab",
        description=(
            "Welcome to the Research Lab! Spend **Research Points** to "
            "unlock permanent upgrades for your factory.\n\n"
            "Use `/lab_research` to view all available research topics, "
            "and `/lab_start` to unlock one."
        ),
        color=discord.Color.blurple(),
    )
    embed.set_author(name=user.display_name, icon_url=getattr(user.display_avatar, "url", discord.Embed.Empty))

    # Points overview
    embed.add_field(
        name="Research Points",
        value=f"💡 You currently have **{rp}** research points.",
        inline=False,
    )

    # Unlocked research list
    if unlocked:
        lines = []
        for key, topic in RESEARCH_TOPICS.items():
            if unlocked.get(key):
                lines.append(f"✅ **{topic['name']}**")
        if lines:
            embed.add_field(
                name="Unlocked Research",
                value="\n".join(lines),
                inline=False,
            )
    else:
        embed.add_field(
            name="Unlocked Research",
            value="You haven't unlocked any research yet.",
            inline=False,
        )

    return embed


def build_research_list_embed(user: discord.abc.User, p: Dict[str, Any]) -> discord.Embed:
    unlocked = p.get("research", {})
    rp = p.get("research_points", 0)

    embed = discord.Embed(
        title="📚 Available Research Topics",
        color=discord.Color.green(),
    )
    embed.set_author(name=user.display_name, icon_url=getattr(user.display_avatar, "url", discord.Embed.Empty))

    lines = []
    for key, topic in RESEARCH_TOPICS.items():
        owned = unlocked.get(key, False)
        status = "✅ Unlocked" if owned else "🔒 Locked"
        cost = topic.get("cost", 0)
        lines.append(
            f"**{topic['name']}** (`{key}`)\n"
            f"> {topic['description']}\n"
            f"> Cost: **{cost} RP** · {status}\n"
        )

    embed.description = "\n".join(lines)
    embed.set_footer(text=f"You currently have {rp} Research Points.")
    return embed


# ---------------------------------------------------------------------------
# Setup entry point called from main.py
# ---------------------------------------------------------------------------

def setup(client: discord.Client, players, save_data, ensure_player):
    """
    Called from main.py to plug the Lab into the shared game state.

    Example in main.py:
        from cogs import lab
        lab.setup(client, players, save_data, ensure_player)
    """
    global players_ref, save_data_ref, ensure_player_ref

    players_ref = players
    save_data_ref = save_data
    ensure_player_ref = ensure_player

    tree = client.tree

    # /lab – overview
    @tree.command(name="lab", description="Open your Research Lab overview.")
    async def lab_overview(interaction: discord.Interaction):
        uid = interaction.user.id
        try:
            p = _get_player(uid)
        except ValueError:
            await interaction.response.send_message(
                "❌ You need to start your factory before using the Research Lab.\nUse `/start` first!",
                ephemeral=True,
            )
            return

        embed = build_lab_overview_embed(interaction.user, p)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # /lab_research – list topics
    @tree.command(name="lab_research", description="View all available research topics.")
    async def lab_research(interaction: discord.Interaction):
        uid = interaction.user.id
        try:
            p = _get_player(uid)
        except ValueError:
            await interaction.response.send_message(
                "❌ You need to start your factory before browsing research.\nUse `/start` first!",
                ephemeral=True,
            )
            return

        embed = build_research_list_embed(interaction.user, p)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # /lab_start – unlock a research topic
    # Use choices so users don't have to type ids manually.
    choices = [
        app_commands.Choice(name=topic["name"], value=research_id)
        for research_id, topic in RESEARCH_TOPICS.items()
    ]

    @tree.command(name="lab_start", description="Spend Research Points to unlock a research topic.")
    @app_commands.choices(research_id=choices)
    async def lab_start(
        interaction: discord.Interaction,
        research_id: app_commands.Choice[str],
    ):
        uid = interaction.user.id
        try:
            p = _get_player(uid)
        except ValueError:
            await interaction.response.send_message(
                "❌ You need to start your factory before starting research.\nUse `/start` first!",
                ephemeral=True,
            )
            return
        key = research_id.value

        topic = RESEARCH_TOPICS.get(key)
        if topic is None:
            await interaction.response.send_message(
                "❌ That research topic does not exist.", ephemeral=True
            )
            return

        unlocked = p.setdefault("research", {})
        if unlocked.get(key):
            await interaction.response.send_message(
                f"✅ You already unlocked **{topic['name']}**.",
                ephemeral=True,
            )
            return

        rp = p.get("research_points", 0)
        cost = topic["cost"]

        if rp < cost:
            await interaction.response.send_message(
                f"❌ You need **{cost}** Research Points to unlock **{topic['name']}** "
                f"but you only have **{rp}**.",
                ephemeral=True,
            )
            return

        # Spend points & unlock
        p["research_points"] = rp - cost
        unlocked[key] = True
        _save()

        await interaction.response.send_message(
            f"🔬 **Research complete!**\n"
            f"You unlocked **{topic['name']}** for **{cost}** Research Points.\n"
            f"You now have **{p['research_points']}** RP remaining.",
            ephemeral=True,
        )

    # (Optional) admin/debug command to grant RP
    # You can comment this out if you don't want it live.

    @tree.command(name="lab_give_rp", description="[Admin] Give yourself research points.")
    @app_commands.default_permissions(administrator=True)
    async def lab_give_rp(
        interaction: discord.Interaction,
        amount: int,
    ):
        if amount <= 0:
            await interaction.response.send_message(
                "Amount must be positive.", ephemeral=True
            )
            return

        uid = interaction.user.id
        try:
            p = _get_player(uid)
        except ValueError:
            await interaction.response.send_message(
                "❌ You need to start your factory before using the Research Lab.\nUse `/start` first!",
                ephemeral=True,
            )
            return

        p["research_points"] = p.get("research_points", 0) + amount
        _save()

        await interaction.response.send_message(
            f"✅ Gave you **{amount}** Research Points.\n"
            f"You now have **{p['research_points']}** RP.",
            ephemeral=True,
        )
