import discord
from discord import app_commands, Interaction
from discord.ui import View, Button

def setup(client, players, save_data, ensure_player):

    def sort_players(metric_func):
        rows = []
        for uid, p in players.items():
            if "factory_name" in p:
                rows.append((uid, p["factory_name"], metric_func(p)))
        rows.sort(key=lambda x: x[2], reverse=True)
        return rows

    async def make_embed(client, data, metric, page):
        start = page * 10
        chunk = data[start:start+10]
        embed = discord.Embed(
            title=f"🏆 Leaderboard — {metric.title()} (Page {page+1})",
            color=discord.Color.gold()
        )
        if not chunk:
            embed.description = "No data."
            return embed
        lines = []
        # try to show top profile icon on this page
        try:
            top_user = await client.fetch_user(int(chunk[0][0]))
            embed.set_thumbnail(url=top_user.display_avatar.url)
        except Exception:
            pass
        for idx, (uid, factory, value) in enumerate(chunk, start=start+1):
            try:
                user = await client.fetch_user(int(uid))
                name = user.display_name
            except Exception:
                name = f"User {uid}"
            lines.append(f"**{idx}.** {name} — *{factory}* — **{value}**")
        embed.description = "\n".join(lines)
        embed.set_footer(text="Showing Discord display names · Icons limited to the page leader")
        return embed

    class PagedView(View):
        def __init__(self, metric, data, page):
            super().__init__(timeout=120)
            self.metric = metric
            self.data = data
            self.page = page
            self.add_item(Button(label="⬅ Prev", style=discord.ButtonStyle.grey, custom_id="prev"))
            self.add_item(Button(label="Next ➡", style=discord.ButtonStyle.grey, custom_id="next"))

        async def interaction_check(self, interaction: Interaction):
            return True

        @discord.ui.button(emoji="⬅", style=discord.ButtonStyle.grey)
        async def prev_page(self, interaction: Interaction, button: Button):
            if self.page > 0:
                self.page -= 1
            embed = await make_embed(client, self.data, self.metric, self.page)
            await interaction.response.edit_message(embed=embed, view=self)

        @discord.ui.button(emoji="➡", style=discord.ButtonStyle.grey)
        async def next_page(self, interaction: Interaction, button: Button):
            max_page = (len(self.data)-1)//10
            if self.page < max_page:
                self.page += 1
            embed = await make_embed(client, self.data, self.metric, self.page)
            await interaction.response.edit_message(embed=embed, view=self)

    @client.tree.command(name="leaderboard", description="Paged leaderboard with display names and icons.")
    @app_commands.describe(metric="money, tier, prestige")
    async def leaderboard(interaction: Interaction, metric: str = "money"):
        metric = metric.lower()
        metrics = {
            "money": lambda p: p.get("money", 0),
            "tier": lambda p: p.get("tier", 1),
            "prestige": lambda p: p.get("prestige", 0),
        }
        if metric not in metrics:
            return await interaction.response.send_message("Metric must be: money, tier, prestige.")
        data = sort_players(metrics[metric])
        if not data:
            return await interaction.response.send_message("No factories found.")
        embed = await make_embed(client, data, metric, 0)
        view = PagedView(metric, data, 0)
        await interaction.response.send_message(embed=embed, view=view)
