import discord
from discord import app_commands, Interaction, ui

from cogs.crafting import RECIPES, have_items, remove_items, add_item

# ==========================
# Crafting Skill System
# ==========================

def get_crafting_skill(player_data: dict) -> dict:
    """Ensure crafting block exists and return it."""
    craft = player_data.setdefault("crafting", {})
    craft.setdefault("level", 1)
    craft.setdefault("xp", 0)
    return craft


def add_crafting_xp(player_data: dict, amount: int):
    """Add XP, handle level ups, and return (leveled_up: bool, new_level: int)."""
    craft = get_crafting_skill(player_data)
    craft["xp"] += max(0, int(amount))

    leveled_up = False
    while True:
        needed = int(100 * (craft["level"] ** 1.5))
        if craft["xp"] < needed:
            break
        craft["xp"] -= needed
        craft["level"] += 1
        leveled_up = True

    return leveled_up, craft["level"]


# ==========================
# Batch Crafting Efficiency
# ==========================

def calculate_efficiency(quantity: int, level: int) -> float:
    """
    1% per quantity + 0.5% per skill level, capped at 25%.
    This is applied as a DISCOUNT on the money cost.
    """
    efficiency = (quantity * 0.01) + (level * 0.005)
    return min(0.25, efficiency)


def calculate_batch_cost(base_cost: int, quantity: int, level: int):
    efficiency = calculate_efficiency(quantity, level)
    effective_cost = round(base_cost * quantity * (1 - efficiency))
    return effective_cost, efficiency


# ==========================
# Crafting Ranks System
# ==========================

def get_crafting_rank(level: int) -> str:
    if level >= 25:
        return "🌟 Legendary Fabricator"
    elif level >= 15:
        return "🔥 Master Crafter"
    elif level >= 10:
        return "⚙️ Engineer"
    elif level >= 5:
        return "🛠 Apprentice"
    else:
        return "🔧 Novice Crafter"


# ==========================
# UI Components
# ==========================

class BulkQuantityButton(ui.Button):
    def __init__(self, item: str, quantity: int, players: dict, uid: str, save_data):
        super().__init__(label=f"Craft x{quantity}", style=discord.ButtonStyle.green)
        self.item = item
        self.quantity = quantity
        self.players = players
        self.uid = uid
        self.save_data = save_data

    async def callback(self, interaction: Interaction):
        # Optional: prevent other users from using someone else's menu
        if str(interaction.user.id) != self.uid:
            return await interaction.response.send_message(
                "This crafting menu isn't yours.", ephemeral=True
            )

        p = self.players.get(self.uid)
        if not p:
            return await interaction.response.send_message(
                "Profile not found. Run **/start** first.", ephemeral=True
            )

        data = RECIPES.get(self.item)
        if not data:
            return await interaction.response.send_message(
                "This recipe no longer exists.", ephemeral=True
            )

        inv = p.setdefault("inventory", {})

        # Skill + rank
        craft_data = get_crafting_skill(p)
        level = craft_data["level"]

        base_cost = data.get("money", 0)
        quantity = max(1, int(self.quantity))

        total_cost, efficiency = calculate_batch_cost(base_cost, quantity, level)

        # Money check (uses the discounted cost)
        if p.get("money", 0) < total_cost:
            return await interaction.response.send_message(
                f"Not enough money. Need **${total_cost}**.",
                ephemeral=True
            )

        # Materials / item check (no discount on materials, just on money)
        if not have_items(inv, data["inputs"], quantity):
            need = ", ".join([f"{k}×{v * quantity}" for k, v in data["inputs"].items()])
            return await interaction.response.send_message(
                f"Missing materials: {need}.",
                ephemeral=True
            )

        # Pay cost + consume materials + give outputs
        p["money"] -= total_cost
        remove_items(inv, data["inputs"], quantity)
        add_item(inv, self.item, quantity)

        # XP gain scales with recipe value and quantity
        xp_per = max(5, data.get("money", 0) // 2)
        xp_gain = xp_per * quantity
        leveled_up, new_level = add_crafting_xp(p, xp_gain)

        # Persist
        self.save_data()

        # Rank + visuals
        rank = get_crafting_rank(new_level if leveled_up else craft_data["level"])

        embed = discord.Embed(
            title=f"Crafted! — {rank}",
            description=f"Crafted **{quantity}× {self.item}**",
            color=0x55FF55
        )
        embed.add_field(
            name="💰 Money Spent",
            value=f"${total_cost} (base ${base_cost} × {quantity})",
            inline=False
        )
        embed.add_field(
            name="📉 Bulk Discount",
            value=f"Saved **{int(efficiency * 100)}%** on money cost",
            inline=False
        )
        embed.add_field(
            name="✨ XP Gained",
            value=f"+{xp_gain} crafting XP",
            inline=False
        )
        embed.add_field(
            name="🔢 Crafting Level",
            value=str(new_level if leveled_up else craft_data["level"]),
            inline=True
        )

        if leveled_up:
            embed.add_field(
                name="🎉 Level Up!",
                value=f"You reached **Level {new_level}**!",
                inline=False
            )

        await interaction.response.send_message(embed=embed, ephemeral=True)


class BulkQuantityView(ui.View):
    def __init__(self, item: str, players: dict, uid: str, save_data):
        super().__init__(timeout=60)
        self.item = item
        self.players = players
        self.uid = uid
        self.save_data = save_data

        for q in (1, 5, 10, 25, 50):
            self.add_item(BulkQuantityButton(item, q, players, uid, save_data))


class BulkRecipeSelect(ui.Select):
    def __init__(self, players: dict, uid: str, save_data):
        self.players = players
        self.uid = uid
        self.save_data = save_data

        # Build up to 25 options (Discord limit)
        options = []
        for name, data in list(RECIPES.items())[:25]:
            cost = data.get("money", 0)
            inputs = ", ".join([f"{k}×{v}" for k, v in data["inputs"].items()])
            desc = f"${cost} • {inputs}"
            if len(desc) > 95:
                desc = desc[:92] + "…"
            options.append(discord.SelectOption(label=name, description=desc, value=name))

        if not options:
            options = [discord.SelectOption(label="No recipes available", value="__none__")]

        super().__init__(
            placeholder="Choose a recipe to bulk craft",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: Interaction):
        if str(interaction.user.id) != self.uid:
            return await interaction.response.send_message(
                "This crafting menu isn't yours.",
                ephemeral=True
            )

        item = self.values[0]
        if item == "__none__":
            return await interaction.response.send_message(
                "No recipes available.",
                ephemeral=True
            )

        data = RECIPES.get(item)
        if not data:
            return await interaction.response.send_message(
                "This recipe no longer exists.",
                ephemeral=True
            )

        base_cost = data.get("money", 0)

        view = BulkQuantityView(item, self.players, self.uid, self.save_data)
        embed = discord.Embed(
            title=f"Select Quantity — {item}",
            description=f"Cost per craft: **${base_cost}**\n"
                        f"Inputs: " +
                        ", ".join([f"{k}×{v}" for k, v in data['inputs'].items()]),
            color=0x00AAFF
        )
        await interaction.response.edit_message(embed=embed, view=view)


class BulkCraftMenu(ui.View):
    def __init__(self, players: dict, uid: str, save_data):
        super().__init__(timeout=60)
        self.players = players
        self.uid = uid
        self.save_data = save_data

        self.add_item(BulkRecipeSelect(players, uid, save_data))


# ==========================
# Command registration
# ==========================

def setup(client, players, save_data, ensure_player):
    """
    Extension-style setup, matching your other cogs:
    called from main.py as crafting_extended_setup(client, players, save_data, ensure_player)
    """

    @client.tree.command(
        name="craftbulk",
        description="Bulk craft items with XP, levels, and rank bonuses."
    )
    async def craftbulk(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first.",
                ephemeral=True
            )

        p = players[uid]
        craft_data = get_crafting_skill(p)
        rank = get_crafting_rank(craft_data["level"])

        embed = discord.Embed(
            title=f"Bulk Crafting — {rank}",
            description=(
                "Pick a recipe, then choose how many to craft.\n"
                "You gain **crafting XP** and get a **bulk discount on money cost** "
                "based on your crafting level and quantity."
            ),
            color=discord.Color.blurple()
        )

        view = BulkCraftMenu(players, uid, save_data)
        await interaction.response.send_message(embed=embed, view=view)
