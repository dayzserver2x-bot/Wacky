from discord import app_commands, Interaction

ITEMS = {
    "bolts": {"cost": 4, "sell": 2},
    "worn gear": {"cost": 6, "sell": 3},
    "low grade ingot": {"cost": 8, "sell": 4},
    "wire mk0": {"cost": 5, "sell": 2},
    "glass lens": {"cost": 8, "sell": 4},
    "primitive circuit": {"cost": 15, "sell": 7},

    # Basic materials
    "Scrap Metal": {"cost": 10, "sell": 7},
    "Coal": {"cost": 25, "sell": 15},
    "Copper Ore": {"cost": 20, "sell": 12},
    "Iron Ore": {"cost": 15, "sell": 10},
    "Glass": {"cost": 40, "sell": 30},
    "Sand": {"cost": 40, "sell": 50},

    # Mid-tier crafted goods
    "Copper Wire": {"cost": 25, "sell": 18},
    "Steel Sheet": {"cost": 60, "sell": 45},
    "Circuit Board": {"cost": 120, "sell": 90},
    "Servo Motor": {"cost": 300, "sell": 230},

    # High-end tech
    "Fusion Core": {"cost": 1500, "sell": 1200},
    "Logic Core": {"cost": 800, "sell": 640},
    "Quantum Chip": {"cost": 2000, "sell": 1600},

    # 🚀 Research Lab products
    "Rocket Fuel": {"cost": 800, "sell": 600},
    "Fuel Catalyst": {"cost": 3200, "sell": 2400},
}

# Case-insensitive lookup and aliases
# Case-insensitive lookup map
ITEM_NAME_MAP = {name.lower(): name for name in ITEMS.keys()}

# Optional shorthand aliases
ALIASES = {
    "scrap": "Scrap Metal",
    "ore": "Iron Ore",
    "iron": "Iron Ingot",
    "coal": "Coal",
    "copper ore": "Copper Ore",
    "copper": "Copper Ingot",
    "steel": "Steel Ingot",
    "steel plate": "Steel Plate",
    "plate": "Steel Plate",

    # New lab items
    "rocketfuel": "Rocket Fuel",
    "rocket fuel": "Rocket Fuel",
    "fuel catalyst": "Fuel Catalyst",
    "catalyst": "Fuel Catalyst",
}

def resolve_item_name(user_input: str):
    """Resolve item names in a case-insensitive, alias-safe way."""
    if not user_input:
        return None
    key = user_input.strip().lower()
    # alias support
    if key in ALIASES:
        key = ALIASES[key].lower()
    return ITEM_NAME_MAP.get(key)


def setup(client, players, save_data, ensure_player):

    @client.tree.command(name="shop", description="Open the materials shop.")
    async def shop(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")

        lines = [
            f"- **{name}** — ${data['cost']} (sell ${data['sell']})"
            for name, data in ITEMS.items()
        ]
        await interaction.response.send_message("**Shop Items**:\n" + "\n".join(lines))

    @client.tree.command(name="buyitem", description="Buy an item from the shop.")
    async def buyitem(interaction: Interaction, item: str, amount: int = 1):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")

        resolved = resolve_item_name(item)
        if not resolved:
            return await interaction.response.send_message("Item not found.")
        item_name = resolved
        item_data = ITEMS[item_name]

        amount = max(1, amount)
        total = item_data["cost"] * amount

        p = players[uid]
        if p.get("money", 0) < total:
            return await interaction.response.send_message(
                f"Not enough money. Need **${total}**."
            )

        p["money"] -= total
        inv = p.setdefault("inventory", {})
        inv[item_name] = inv.get(item_name, 0) + amount
        save_data()
        await interaction.response.send_message(
            f"🛒 Bought **{amount}× {item_name}**."
        )

    @client.tree.command(name="sellitem", description="Sell items from your inventory for cash.")
    async def sellitem(interaction: Interaction, item: str, amount: int = 1):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")

        resolved = resolve_item_name(item)
        if not resolved:
            return await interaction.response.send_message("Item not found.")
        item_name = resolved
        item_data = ITEMS[item_name]

        p = players[uid]
        inv = p.setdefault("inventory", {})
        amount = max(1, amount)
        have = inv.get(item_name, 0)
        if have < amount:
            return await interaction.response.send_message(
                f"You only have **{have}× {item_name}**."
            )

        inv[item_name] = have - amount
        if inv[item_name] <= 0:
            inv.pop(item_name, None)

        gain = item_data["sell"] * amount
        p["money"] = p.get("money", 0) + gain
        save_data()
        await interaction.response.send_message(
            f"💵 Sold **{amount}× {item_name}** for **${gain}**."
        )
