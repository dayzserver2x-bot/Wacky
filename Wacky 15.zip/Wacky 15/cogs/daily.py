# cogs/daily.py
import time
import discord
from discord import app_commands, Interaction

BASE_CAPACITY = 200
ONE_DAY = 24 * 60 * 60

# How much coal max per daily (you can tweak or tie to tier/workers later)
DAILY_COAL_BASE = 5

# Streak milestones -> Wacky Tokens
DAILY_TOKEN_MILESTONES = {
    3: 1,
    7: 2,
    14: 3,
    21: 3,
    30: 5,
}

def tokens_for_streak(streak: int) -> int:
    if streak in DAILY_TOKEN_MILESTONES:
        return DAILY_TOKEN_MILESTONES[streak]
    # After 30, give 1 token every 10 days
    if streak > 30 and streak % 10 == 0:
        return 1
    return 0

# references injected in setup
players_ref = None
save_data_ref = None
ensure_player_ref = None

def _ensure_daily_fields(p: dict) -> dict:
    p.setdefault("daily_streak", 0)
    p.setdefault("last_daily", 0)
    p.setdefault("longest_daily_streak", 0)
    p.setdefault("wacky_tokens", 0)
    p.setdefault("inventory", {})
    p.setdefault("workers", {
        "money": 0,
        "machine": 0,
        "craft": 0,
        "prestige": 0,
        "storage": 0,
    })
    p.setdefault("tier", 1)
    p.setdefault("money", 0)
    return p

def claim_daily_core(uid: str):
    """
    Shared core logic for /daily and the factory Daily 🎁 button.

    Returns a dict:
    {
      "ok": bool,
      "already_claimed": bool,
      "remaining": int | None,
      "player": dict | None,
      "streak": int | None,
      "longest": int | None,
      "money": int | None,
      "coal": int | None,
      "tokens": int | None,
    }
    """
    global players_ref, save_data_ref, ensure_player_ref

    if not ensure_player_ref or not players_ref:
        return {"ok": False, "already_claimed": False, "remaining": None, "player": None}

    if not ensure_player_ref(uid):
        return {"ok": False, "already_claimed": False, "remaining": None, "player": None}

    p = _ensure_daily_fields(players_ref[uid])

    now = int(time.time())
    last_daily = int(p.get("last_daily", 0))

    # already claimed today
    if now - last_daily < ONE_DAY:
        remaining = ONE_DAY - (now - last_daily)
        return {
            "ok": False,
            "already_claimed": True,
            "remaining": remaining,
            "player": p,
            "streak": p.get("daily_streak", 0),
            "longest": p.get("longest_daily_streak", 0),
            "money": None,
            "coal": None,
            "tokens": None,
        }

    # streak logic with 2-day grace
    if last_daily and now - last_daily < (2 * ONE_DAY):
        p["daily_streak"] = p.get("daily_streak", 0) + 1
    else:
        p["daily_streak"] = 1

    p["last_daily"] = now
    p["longest_daily_streak"] = max(
        p.get("longest_daily_streak", 0),
        p["daily_streak"],
    )

    streak = p["daily_streak"]
    longest = p["longest_daily_streak"]

    # Base rewards depend on tier, like your old command
    tier = max(1, p.get("tier", 1))
    base_money = 750 * tier
    base_coal = DAILY_COAL_BASE * tier

    # Streak multiplier: +10% per day
    multiplier = 1 + (streak * 0.10)

    money = int(base_money * multiplier)
    coal = int(base_coal * multiplier)

    p["money"] += money

    # Basic capacity check so we don't overfill too hard
    workers = p.get("workers", {})
    capacity = BASE_CAPACITY + workers.get("storage", 0) * 200
    inv = p.setdefault("inventory", {})
    inv_total = sum(inv.values())
    free_space = max(0, capacity - inv_total)

    coal_to_add = min(coal, free_space) if free_space > 0 else 0
    if coal_to_add > 0:
        inv["Coal"] = inv.get("Coal", 0) + coal_to_add

    # Wacky Tokens from streak milestones
    tokens_gained = tokens_for_streak(streak)
    if tokens_gained > 0:
        p["wacky_tokens"] = p.get("wacky_tokens", 0) + tokens_gained

    save_data_ref()

    return {
        "ok": True,
        "already_claimed": False,
        "remaining": None,
        "player": p,
        "streak": streak,
        "longest": longest,
        "money": money,
        "coal": coal_to_add,
        "tokens": tokens_gained,
    }

def setup(client, players, save_data, ensure_player):
    global players_ref, save_data_ref, ensure_player_ref
    players_ref = players
    save_data_ref = save_data
    ensure_player_ref = ensure_player

    @client.tree.command(name="daily", description="Claim your daily factory reward.")
    async def daily_cmd(interaction: Interaction):
        uid = str(interaction.user.id)

        result = claim_daily_core(uid)

        # already claimed
        if not result["ok"] and result.get("already_claimed"):
            remaining = result["remaining"] or 0
            hours = remaining // 3600
            minutes = (remaining % 3600) // 60
            return await interaction.response.send_message(
                f"⏳ You already claimed your daily.\n"
                f"Try again in **{hours}h {minutes}m**.\n"
                f"Current streak: **{result.get('streak', 0)}** days.",
                ephemeral=False
            )

        if not result["ok"]:
            return await interaction.response.send_message(
                "⚠️ Something went wrong with your daily. Ping the dev.",
                ephemeral=False
            )

        streak = result["streak"]
        longest = result["longest"]
        money = result["money"]
        coal = result["coal"]
        tokens = result["tokens"]
        multiplier = 1 + (streak * 0.10)

        lines = [
            f"🎁 **Daily Reward Claimed!** (Streak: **{streak} days**, Best: {longest})",
            "",
            f"💵 + **${money}**",
            f"⛏️ + **{coal} Coal**",
            f"⭐ Bonus multiplier: **x{multiplier:.2f}**",
        ]
        if tokens and tokens > 0:
            lines.append(f"🔹 + **{tokens} Wacky Token(s)**")
            lines.append("Use `/tokens_shop` to buy cosmetics!")

        await interaction.response.send_message("\n".join(lines), ephemeral=False)
