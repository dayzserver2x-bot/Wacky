from discord.ext import tasks
from discord import app_commands, Interaction

# Infinite tier scaling for command /tierupgrade (optional UI button exists too)
BASE_TIER_COST = 500
TIER_COST_GROWTH = 1.35
TIER_PROD_GROWTH = 1.15
# How much each worker pays per hour
WORKER_PAY_PER_HOUR = 25  # change this number to balance

players = None
save_data = None


def tier_cost(n: int) -> int:
    """Return the money cost to reach tier n."""
    return int(BASE_TIER_COST * (TIER_COST_GROWTH ** (n - 1)))


def setup(client, _players, _save_data, ensure_player):
    """
    Attach the /tierupgrade command and hook up shared state.
    """
    global players, save_data
    players = _players
    save_data = _save_data

    @client.tree.command(
        name="tierupgrade",
        description="Upgrade your factory tier."
    )
    async def tierupgrade(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")

        p = players[uid]
        current_tier = int(p.get("tier", 1))
        cost = tier_cost(current_tier)

        if p.get("money", 0) < cost:
            return await interaction.response.send_message(
                f"You need **${cost}** to reach Tier {current_tier + 1}."
            )

        # Pay and upgrade
        p["money"] = p.get("money", 0) - cost
        p["tier"] = current_tier + 1
        # Increase production slightly each tier
        p["production"] = max(1, int(p.get("production", 1) * TIER_PROD_GROWTH))

        save_data()

        await interaction.response.send_message(
            f"🚀 Tier up! Now **Tier {p['tier']}** — "
            f"production **{p['production']}**. "
            f"Next: **${tier_cost(p['tier'])}**"
        )


@tasks.loop(hours=1)
async def passive_income():
    if players is None or save_data is None:
        return

    for uid, p in players.items():
        w = p.get("workers", 0)
        if isinstance(w, dict):
            money_workers = int(w.get("money", 0))
            machine_workers = int(w.get("machine", 0))
            craft_workers = int(w.get("craft", 0))
            prestige_workers = int(w.get("prestige", 0))
            storage_workers = int(w.get("storage", 0))
        else:
            money_workers = int(w)
            machine_workers = craft_workers = prestige_workers = storage_workers = 0

        prestige_level = int(p.get("prestige", 0))

        # Base prestige: +10% per prestige level
        base_mult = 1.0 + (0.10 * prestige_level)
        # Workers add +1% each
        worker_mult = 1.0 + (0.01 * prestige_workers)
        prestige_mult = base_mult * worker_mult

        # ❌ NO MORE MACHINE INVENTORY GAINS HERE

        # Craft workers: reduce craft costs via helper multiplier, up to 30% discount
        p["craft_discount"] = 1.0 - min(0.30, craft_workers * 0.02)

        # Store the computed prestige multiplier back on the player
        p["prestige_mult"] = float(prestige_mult)

    save_data()



# 🔍 For testing, use seconds=30 so you can see it quickly.
# Once confirmed, change to hours=1.
# 🔍 For testing, use seconds=30 so you can see it quickly.
# Once confirmed, change to hours=1.
@tasks.loop(hours=1)
async def worker_pay_loop():
    """
    Every hour, pay players based on how many workers they own.

    Total pay = total_workers * WORKER_PAY_PER_HOUR
    """
    ...

    """
    Every interval, pay players based on how many workers they own.

    Total pay = total_workers * WORKER_PAY_PER_HOUR
    """
    ...

    """
    Every interval, pay players based on how many workers they own.

    Total pay = total_workers * WORKER_PAY_PER_HOUR
    """
    global players, save_data

    if players is None or save_data is None:
        return

    for uid, p in players.items():
        w = p.get("workers", 0)

        # Handle both legacy int and dict format
        if isinstance(w, dict):
            total_workers = sum(int(v) for v in w.values())
        else:
            total_workers = int(w) if w else 0

        if total_workers <= 0:
            continue  # no workers, no pay

        gain = total_workers * WORKER_PAY_PER_HOUR
        before = p.get("money", 0)
        p["money"] = before + gain

        # Optional: track lifetime worker earnings
        p["worker_income_total"] = p.get("worker_income_total", 0) + gain

        # Debug print so you can SEE it in your console
        print(
            f"[worker_pay_loop] uid={uid} workers={total_workers} "
            f"payout={gain} money: {before} -> {p['money']}"
        )

    save_data()
