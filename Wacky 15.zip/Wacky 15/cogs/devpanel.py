import discord
from discord.ui import View, Button, Select
from discord import Interaction
import io, json, importlib

DEV_ID = 691108551258800128  # your Discord ID


# ==========================
# PLAYER SELECT DROPDOWN
# ==========================

class TargetSelect(Select):
    def __init__(self, view):
        self.view_ref = view
        super().__init__(placeholder="Select player to modify…", options=[])

    async def populate_options(self):
        """Fetch all player usernames (cached or from API)."""
        options = []
        for uid in self.view_ref.players.keys():
            try:
                user = self.view_ref.client.get_user(int(uid))
                if not user:
                    user = await self.view_ref.client.fetch_user(int(uid))
                label = user.name if user else f"Unknown ({uid})"
            except Exception:
                label = f"Unknown ({uid})"
            options.append(discord.SelectOption(label=label, value=uid))

        self.options = sorted(options, key=lambda o: o.label.lower())

    async def callback(self, interaction: Interaction):
        """When selecting a player, update target and embed."""
        self.view_ref.target = self.values[0]

        try:
            user = self.view_ref.client.get_user(int(self.view_ref.target)) or await self.view_ref.client.fetch_user(int(self.view_ref.target))
            display_name = user.name
        except Exception:
            display_name = f"Unknown ({self.view_ref.target})"

        await interaction.response.edit_message(
            content=f"✅ Now editing **{display_name}**",
            embed=self.view_ref.get_embed(),
            view=self.view_ref
        )


# ==========================
# COG RELOAD SELECT MENU
# ==========================

class CogReloadSelect(Select):
    def __init__(self, client):
        self.client = client
        options = [
            discord.SelectOption(label=name, value=name)
            for name in client.cogs.keys()
        ] or [discord.SelectOption(label="No cogs loaded", value="none", default=True)]
        super().__init__(placeholder="Select a cog to reload…", options=options)

    async def callback(self, interaction: Interaction):
        cog_name = self.values[0]
        if cog_name == "none":
            return await interaction.response.send_message("⚠️ No cogs loaded.", ephemeral=False)

        try:
            module_name = f"cogs.{cog_name.lower()}"
            importlib.reload(importlib.import_module(module_name))
            await interaction.response.send_message(
                f"🔄 Successfully reloaded `{cog_name}` cog.", ephemeral=False
            )
        except Exception as e:
            await interaction.response.send_message(
                f"❌ Failed to reload `{cog_name}`:\n```\n{e}\n```", ephemeral=False
            )


# ==========================
# MAIN DEVELOPER PANEL
# ==========================

class DevPanel(View):
    def __init__(self, uid, players, save_data, client):
        super().__init__(timeout=300)
        self.uid = uid
        self.target = uid
        self.players = players
        self.save_data = save_data
        self.client = client

        # Add dropdown directly when created
        self.add_item(TargetSelect(self))

    async def refresh_dropdown(self):
        """Repopulate dropdown with current player list."""
        for item in self.children:
            if isinstance(item, TargetSelect):
                await item.populate_options()

    def get_embed(self):
        p = self.players.get(self.target, {})
        debug_status = p.get("debug_auto_coal", False)
        tier = p.get("tier", 1)
        money = p.get("money", 0)
        machines = len(p.get("machines", {}))

        embed = discord.Embed(
            title="🛠️ Developer Control Panel",
            description=(
                f"**Editing:** <@{self.target}>\n"
                f"💵 Money: **${money:,}**\n"
                f"🏭 Machines: **{machines}**\n"
                f"📈 Tier: **{tier}**\n"
                f"⛽ Auto Coal Debug: **{'ON ✅' if debug_status else 'OFF ❌'}**"
            ),
            color=discord.Color.red()
        )
        embed.set_footer(text="Developer Access Only")
        return embed

    # --------------------------
    # 💰 ECONOMY CONTROLS
    # --------------------------

    @discord.ui.button(label="Give $10,000", style=discord.ButtonStyle.success, row=0)
    async def give_money(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        p["money"] = p.get("money", 0) + 10000
        self.save_data()
        await interaction.response.edit_message(
            content=f"✅ Gave **$10,000** to <@{self.target}>.",
            embed=self.get_embed(),
            view=self
        )

    @discord.ui.button(label="Give 50 Coal", style=discord.ButtonStyle.primary, row=0)
    async def give_coal(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        inv = p.setdefault("inventory", {})
        inv["Coal"] = inv.get("Coal", 0) + 50
        self.save_data()
        await interaction.response.edit_message(
            content=f"✅ Gave **50 Coal** to <@{self.target}>.",
            embed=self.get_embed(),
            view=self
        )

    @discord.ui.button(label="Set Tier 5", style=discord.ButtonStyle.secondary, row=0)
    async def set_tier(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        p["tier"] = 5
        self.save_data()
        await interaction.response.edit_message(
            content=f"📈 Set <@{self.target}> to **Tier 5**.",
            embed=self.get_embed(),
            view=self
        )

    # --------------------------
    # ⚙️ MACHINE / AUTOMATION
    # --------------------------

    @discord.ui.button(label="Unlock All Machines", style=discord.ButtonStyle.success, row=1)
    async def unlock_machines(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        for name, m in p.get("machines", {}).items():
            m["level"] = max(1, m.get("level", 0))
        self.save_data()
        await interaction.response.edit_message(
            content=f"🏭 All machines unlocked for <@{self.target}>.",
            embed=self.get_embed(),
            view=self
        )

    @discord.ui.button(label="Give Full Automation", style=discord.ButtonStyle.primary, row=1)
    async def full_automation(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        for name, m in p.get("machines", {}).items():
            m["automation"] = "Overdrive Mode"
        self.save_data()
        await interaction.response.edit_message(
            content=f"🤖 All machines set to **Overdrive Mode 🔥** for <@{self.target}>.",
            embed=self.get_embed(),
            view=self
        )

    @discord.ui.button(label="Toggle Auto Coal Debug", style=discord.ButtonStyle.secondary, row=1)
    async def toggle_autocoal(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        p["debug_auto_coal"] = not p.get("debug_auto_coal", False)
        state = "ON ✅" if p["debug_auto_coal"] else "OFF ❌"
        self.save_data()
        await interaction.response.edit_message(
            content=f"🔧 Auto Coal Debug now **{state}** for <@{self.target}>.",
            embed=self.get_embed(),
            view=self
        )

    # --------------------------
    # 🚢 SHIPPING / PLAYER DATA
    # --------------------------

    @discord.ui.button(label="Reset Shipping Orders", style=discord.ButtonStyle.secondary, row=2)
    async def reset_shipping(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        p["shipping_orders"] = []
        self.save_data()
        await interaction.response.edit_message(
            content=f"🚢 Shipping orders reset for <@{self.target}>.",
            embed=self.get_embed(),
            view=self
        )

    @discord.ui.button(label="Full Factory Wipe", style=discord.ButtonStyle.danger, row=2)
    async def full_wipe(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        self.players[self.target] = {}
        self.save_data()
        await interaction.response.edit_message(
            content=f"💣 <@{self.target}> factory fully wiped. Must run `/start` again.",
            embed=None,
            view=None
        )

    # --------------------------
    # 🧠 DEBUG & DIAGNOSTICS
    # --------------------------

    @discord.ui.button(label="Integrity Check", style=discord.ButtonStyle.blurple, row=3)
    async def integrity_check(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        report = []

        if "machines" not in p:
            report.append("❌ Missing `machines` key.")
        else:
            for name, m in p["machines"].items():
                for field in ("level", "running", "progress"):
                    if field not in m:
                        report.append(f"⚠️ {name} missing `{field}` key.")

        for key in ["inventory", "workers", "blueprints"]:
            if key not in p:
                report.append(f"❌ Missing `{key}` key.")

        summary = "\n".join(report) if report else "✅ All systems consistent and valid!"
        await interaction.response.send_message(
            embed=discord.Embed(
                title=f"🔍 Factory Integrity Check — <@{self.target}>",
                description=summary,
                color=discord.Color.blurple()
            ),
            ephemeral=False
        )

    @discord.ui.button(label="Player Debug Summary", style=discord.ButtonStyle.gray, row=3)
    async def player_summary(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        p = self.players[self.target]
        inv = p.get("inventory", {})
        coal = inv.get("Coal", 0)
        money = p.get("money", 0)
        machines = p.get("machines", {})
        running = sum(1 for m in machines.values() if m.get("running"))
        auto = sum(1 for m in machines.values() if m.get("automation"))

        user = await self.client.fetch_user(int(self.target))
        target_name = user.name if user else f"<@{self.target}>"

        desc = (
            f"💵 Money: **${money:,}**\n"
            f"⛽ Coal: **{coal}**\n"
            f"🏭 Machines: {len(machines)} total | {running} running\n"
            f"🤖 Automated: {auto}\n"
            f"📦 Inventory Items: {len(inv)}"
        )

        await interaction.response.send_message(
            embed=discord.Embed(
                title=f"🧾 Debug Summary — {target_name}",
                description=desc,
                color=discord.Color.gold()
            ),
            ephemeral=False
        )

    @discord.ui.button(label="Reload Cog", style=discord.ButtonStyle.primary, row=3)
    async def reload_cog(self, interaction: Interaction, _):
        await self.refresh_dropdown()
        view = View(timeout=30)
        view.add_item(CogReloadSelect(self.client))
        await interaction.response.edit_message(
            content="🔄 Select a **cog** to reload:",
            embed=None,
            view=view
        )


# ==========================
# COMMAND SETUP
# ==========================

def setup(client, players, save_data, ensure_player):
    @client.tree.command(name="devpanel", description="Open developer tools.")
    async def devpanel(interaction: Interaction):
        if interaction.user.id != DEV_ID:
            return await interaction.response.send_message("Access Denied.", ephemeral=False)

        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run /start first.", ephemeral=False)

        panel = DevPanel(uid, players, save_data, client)

        # ✅ Populate dropdown before sending
        await panel.refresh_dropdown()

        await interaction.response.send_message(
            content="🧩 **Developer Panel Loaded!**\nUse the dropdown below to select a player to edit.",
            embed=panel.get_embed(),
            view=panel,
            ephemeral=False
        )
