from discord import app_commands, Interaction

MIN_PRESTIGE_TIER = 15

def prestige_gain(tier):
    return max(1, int((tier - MIN_PRESTIGE_TIER + 1) ** 0.85))

def setup(client, players, save_data, ensure_player):

    @client.tree.command(name="prestigeinfo", description="See how prestige works.")
    async def prestigeinfo(interaction: Interaction):
        await interaction.response.send_message(
            "Prestige resets your money/workers/production to base, but grants **Prestige Points**. "
            "Each point increases all income by **+10%** permanently. Unlocks late-game scaling."
        )

    @client.tree.command(name="prestige", description="Prestige to reset and gain permanent bonuses.")
    async def prestige(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")
        p = players[uid]
        if p["tier"] < MIN_PRESTIGE_TIER:
            return await interaction.response.send_message(f"Reach at least **Tier {MIN_PRESTIGE_TIER}** to prestige.")
        gain = prestige_gain(p["tier"])
        p["prestige"] = p.get("prestige", 0) + gain
        p["prestige_mult"] = 1.0 + p["prestige"] * 0.10
        p["tier"] = 1
        p["money"] = 0
        p["production"] = 1
        p["workers"] = 0
        p["owned_upgrades"] = []
        p["inventory"] = {}
        save_data()
        await interaction.response.send_message(
            f"🌟 Prestige! You gained **{gain}** point(s). Total prestige: **{p['prestige']}** (x{p['prestige_mult']:.2f})."
        )
