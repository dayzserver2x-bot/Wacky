# cogs/maintenance.py

import discord
from discord import Interaction
from discord.ui import View, Select, Button

from cogs.machine_data import MACHINE_DATA


# ---------- HEALTH HELPERS ----------

def get_durability(machine_dict):
    """Safe read of durability fields from player machine data."""
    dur = machine_dict.get("durability")
    max_dur = machine_dict.get("max_durability")

    # If your existing data has no durability yet, treat as 100%
    if dur is None or max_dur is None or max_dur <= 0:
        return 100, 100, 100.0

    perc = (dur / max_dur) * 100
    return dur, max_dur, perc


def get_health_state(machine_dict):
    """
    Convert durability percentage into a simple health state label + color.
    This only *reads* from your data – it doesn't modify anything.
    """
    _, _, perc = get_durability(machine_dict)

    if perc >= 80:
        return "Healthy ✅", discord.Color.green()
    elif perc >= 50:
        return "Worn ⚠️", discord.Color.gold()
    elif perc >= 25:
        return "Critical ⚠️", discord.Color.orange()
    else:
        return "Broken ⛔", discord.Color.red()


def estimate_repair_cost(name, machine_dict):
    """
    Try to infer repair costs from your machine/player data if present,
    otherwise fall back to a simple money-only estimate based on tier.
    This is READ-ONLY: it doesn't charge the player.
    """
    # If you already store costs on the machine instance, prefer that.
    money_cost = machine_dict.get("repair_cost")
    items_cost = machine_dict.get("repair_items") or machine_dict.get("repair_with_items")

    # If either is recorded, just echo that out.
    if money_cost is not None or items_cost:
        return money_cost, items_cost

    # Fallback: derive from MACHINE_DATA tier if nothing is specified
    data = MACHINE_DATA.get(name, {})
    tier = data.get("tier", 1)
    # Soft, balanced-ish default: higher-tier machines cost more.
    money_cost = 250 * tier

    # No item list if we don't know – UI will say "Money only (estimate)".
    return money_cost, None


# ---------- UI VIEWS ----------

class MachineHealthSelect(Select):
    def __init__(self, uid, players):
        self.uid = uid
        self.players = players

        p = players.get(uid, {})
        machines = p.get("machines", {})

        options = []
        for name, m in machines.items():
            # Skip machines with level 0 or missing
            if not isinstance(m, dict) or m.get("level", 0) <= 0:
                continue

            state_label, _ = get_health_state(m)
            dur, max_dur, perc = get_durability(m)
            label = name
            desc = f"{state_label} • {dur}/{max_dur} HP ({perc:.0f}%)"
            options.append(discord.SelectOption(label=label, value=name, description=desc))

        if not options:
            options = [
                discord.SelectOption(
                    label="No machines owned",
                    value="none",
                    description="Buy machines from the machine shop first."
                )
            ]

        super().__init__(
            placeholder="Select a machine to inspect...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: Interaction):
        name = self.values[0]
        if name == "none":
            return await interaction.response.send_message(
                "You don't own any machines yet. Visit the Machine Shop to buy some!",
                ephemeral=True
            )

        view: "MaintenanceView" = self.view
        await view.show_machine_detail(interaction, name)


class MaintenanceView(View):
    def __init__(self, uid, players, return_factory=None):
        super().__init__(timeout=120)
        self.uid = uid
        self.players = players
        self.return_factory = return_factory

        self.add_item(MachineHealthSelect(uid, players))

        # Back to factory, if provided
        if return_factory is not None:
            self.add_item(
                Button(
                    label="⬅️ Back to Factory",
                    style=discord.ButtonStyle.secondary,
                    custom_id="maintenance_back_factory"
                )
            )

    async def interaction_check(self, interaction: Interaction) -> bool:
        # Only the owner can interact with this view
        return str(interaction.user.id) == self.uid

    async def on_timeout(self):
        # We don't auto-edit anything on timeout – Discord will simply disable components.
        return

    async def show_machine_detail(self, interaction: Interaction, name: str):
        p = self.players.get(self.uid, {})
        machines = p.get("machines", {})
        m = machines.get(name)
        if not isinstance(m, dict):
            return await interaction.response.send_message("❌ That machine could not be found.", ephemeral=True)

        dur, max_dur, perc = get_durability(m)
        state_label, color = get_health_state(m)
        broken = m.get("broken", False)

        money_cost, items_cost = estimate_repair_cost(name, m)

        # Build repair-cost text
        if items_cost:
            parts_lines = [f"• {item} × {amt}" for item, amt in items_cost.items()]
            parts_text = "\n".join(parts_lines)
            repair_text = (
                f"**Money:** ${money_cost:,}\n"
                f"**Parts Needed:**\n{parts_text}"
            )
        else:
            repair_text = f"**Money (estimate):** ${money_cost:,}\n_No specific parts required in data._"

        embed = discord.Embed(
            title=f"🛠️ {name} — Maintenance Report",
            color=color,
            description=(
                f"**Condition:** {state_label}\n"
                f"**Durability:** {dur}/{max_dur} HP ({perc:.0f}%)\n"
                f"**Status:** {'Broken ⛔ – cannot run until repaired' if broken else 'Operational ✅ (may break if not maintained)'}"
            )
        )

        embed.add_field(
            name="Estimated Repair Requirements",
            value=repair_text,
            inline=False
        )

        embed.set_footer(text="Use the Repair button on the machine control panel to actually repair it.")

        # Create a small one-off view:
        detail_view = View(timeout=60)
        # (Optional) Just a close button
        detail_view.add_item(
            Button(label="Close", style=discord.ButtonStyle.secondary, custom_id="maintenance_close")
        )

        await interaction.response.send_message(embed=embed, view=detail_view, ephemeral=True)


# ---------- SETUP (COG ENTRYPOINT) ----------

def setup(client, players, save_data, ensure_player):
    """
    Hook this into your existing bot like your other cogs:

        from cogs.maintenance import setup as maintenance_setup
        maintenance_setup(client, players, save_data, ensure_player)

    This file does NOT modify anything, it only reads from the shared `players` dict.
    """

    @client.tree.command(name="maintenance", description="Check the health of your machines.")
    async def maintenance_cmd(interaction: Interaction):
        uid = str(interaction.user.id)

        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first to create your factory.",
                ephemeral=True
            )

        # Import factory view for the "Back to Factory" button, but don't change it
        from cogs.ui import FactoryView, fmt_embed

        # Build the maintenance overview embed
        p = players.get(uid, {})
        machines = p.get("machines", {})

        if not machines or all((not isinstance(m, dict) or m.get("level", 0) <= 0) for m in machines.values()):
            embed = discord.Embed(
                title="🛠️ Maintenance Report",
                description="You don't own any machines yet.\nBuy some from the **Machine Shop 🏪** first!",
                color=discord.Color.blurple()
            )
            return await interaction.response.send_message(embed=embed, ephemeral=True)

        # High-level summary
        healthy = worn = critical = broken = 0
        for m in machines.values():
            if not isinstance(m, dict) or m.get("level", 0) <= 0:
                continue
            state_label, _ = get_health_state(m)
            if "Healthy" in state_label:
                healthy += 1
            elif "Worn" in state_label and "Critical" not in state_label:
                worn += 1
            elif "Critical" in state_label:
                critical += 1
            elif "Broken" in state_label:
                broken += 1

        summary_lines = [
            f"✅ Healthy: **{healthy}**",
            f"⚠️ Worn: **{worn}**",
            f"⚠️ Critical: **{critical}**",
            f"⛔ Broken: **{broken}**",
        ]

        embed = discord.Embed(
            title="🛠️ Factory Maintenance Overview",
            description="\n".join(summary_lines),
            color=discord.Color.teal()
        )
        embed.set_footer(text="Select a machine from the dropdown for detailed repair info.")

        # Return to factory view instance
        factory_view = FactoryView(uid, players, save_data, ensure_player, client)

        view = MaintenanceView(uid, players, return_factory=factory_view)
        await interaction.response.send_message(embed=embed, view=view)
