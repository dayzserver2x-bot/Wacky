import discord
from discord.ui import View, Button, Select
from discord import Interaction
import random
import time

from cogs.items import ITEMS

SC_COST = 25000
MAX_VISIBLE_ORDERS = 3
ORDER_EXPIRY_SEC = 60 * 60


def setup(client, players, save_data, ensure_player):
    """
    Shipping Center module that plugs into the existing dict-backed game.
    Adds /shippingcenter which:
      - lets a user buy a Shipping Center (one-time)
      - shows a board of orders (up to 3 visible)
      - allows Accept -> Ship flow to trade inventory for rewards
    """

    def ensure_schema(uid: str):
        p = players.setdefault(uid, {})
        p.setdefault("shipping_center_owned", False)
        p.setdefault("shipping_center_unlocked", False)  # ✅ ensure flag exists
        p.setdefault("shipping_orders", [])
        p.setdefault("accepted_order", None)
        p.setdefault("workers", p.get("workers", {}))

    def _now():
        return int(time.time())

    def _reward_for(item: str, qty: int, uid: str) -> int:
        """Base reward derived from sell value, boosted by shipper workers."""
        sell = ITEMS.get(item, {}).get("sell", 5)
        base = int(sell * qty * random.uniform(1.0, 1.6))
        shipper_lv = players[uid].get("workers", {}).get("shipper", 0)
        boost = 1.0 + 0.05 * shipper_lv
        return int(base * boost)

    def _eligible_items(uid: str):
        inv = players[uid].get("inventory", {})
        names = list(inv.keys()) or list(ITEMS.keys())
        return names

    def _gen_orders(uid: str, n: int):
        out = []
        names = _eligible_items(uid)
        for _ in range(n):
            item = random.choice(names)
            qty = random.randint(5, 25)
            reward = _reward_for(item, qty, uid)
            out.append({
                "id": f"{uid}-{_now()}-{random.randint(1000,9999)}",
                "item": item,
                "qty": qty,
                "reward": reward,
                "expires": _now() + ORDER_EXPIRY_SEC,
                "status": "OPEN"
            })
        return out

    def _clean_and_fill(uid: str):
        p = players[uid]
        current = [o for o in p["shipping_orders"] if o["status"] == "OPEN" and o["expires"] > _now()]
        need = max(0, MAX_VISIBLE_ORDERS - len(current))
        if need:
            current.extend(_gen_orders(uid, need))
        p["shipping_orders"] = current
        save_data()
        return current

    def _build_locked_embed(uid: str):
        return discord.Embed(
            title="📦 Shipping Center",
            description=(f"Buy a Shipping Center to unlock contracts and deliver goods for rewards.\n\n"
                         f"**Cost:** ${SC_COST}"),
            color=discord.Color.blurple()
        )

    def _build_orders_embed(uid: str):
        p = players[uid]
        embed = discord.Embed(title="📦 Shipping Center — Orders", color=discord.Color.blurple())
        acc = p.get("accepted_order")
        if acc:
            embed.add_field(
                name="Accepted Order",
                value=f"**{acc['item']}** × **{acc['qty']}** — Reward **${acc['reward']}**\n"
                      f"Expires <t:{acc['expires']}:R>",
                inline=False
            )
        for i, o in enumerate(p["shipping_orders"], 1):
            embed.add_field(
                name=f"Order {i}",
                value=f"**{o['item']}** × **{o['qty']}** — **${o['reward']}**\nExpires <t:{o['expires']}:R>",
                inline=False
            )
        if not p["shipping_orders"]:
            embed.add_field(name="No orders", value="Press **Refresh** to roll new offers.", inline=False)
        return embed

    class SCView(View):
        def __init__(self, uid: str, locked: bool):
            super().__init__(timeout=120)
            self.uid = uid
            self.locked = locked
            if locked:
                self.add_item(BuyButton())
            else:
                self.add_item(AcceptButton())
                self.add_item(ShipButton())
                self.add_item(RefreshButton())

        async def interaction_check(self, interaction: Interaction) -> bool:
            return str(interaction.user.id) == self.uid

    class BuyButton(Button):
        def __init__(self):
            super().__init__(label="Buy Center 🛒", style=discord.ButtonStyle.success)

        async def callback(self, interaction: Interaction):
            # ✅ import inside to avoid circular import
            from cogs.ui import FactoryView, fmt_embed

            uid = str(interaction.user.id)
            ensure_player(uid)
            ensure_schema(uid)
            p = players[uid]

            if p["shipping_center_owned"]:
                return await interaction.response.send_message("You already own a Shipping Center.", ephemeral=False)
            if p.get("money", 0) < SC_COST:
                return await interaction.response.send_message(f"You need **${SC_COST}**.", ephemeral=False)

            # ✅ Purchase and mark unlocked
            p["money"] -= SC_COST
            p["shipping_center_owned"] = True
            p["shipping_center_unlocked"] = True  # Make sure factory sees it unlocked
            save_data()

            # ✅ Fully refresh the factory view using updated data
            factory_view = FactoryView(uid, players, save_data, ensure_player)
            await interaction.response.edit_message(
                embed=fmt_embed(interaction.user, p),
                view=factory_view
            )
            await interaction.followup.send(
                "✅ Purchased Shipping Center! It’s now in your factory menu.",
                ephemeral=False
            )

    class AcceptButton(Button):
        def __init__(self):
            super().__init__(label="Accept Order ✍️", style=discord.ButtonStyle.primary)

        async def callback(self, interaction: Interaction):
            uid = str(interaction.user.id)
            ensure_player(uid)
            ensure_schema(uid)
            p = players[uid]

            if p.get("accepted_order"):
                return await interaction.response.send_message("You already have an accepted order.", ephemeral=False)

            _clean_and_fill(uid)
            if not p["shipping_orders"]:
                return await interaction.response.send_message("No orders available. Try Refresh.", ephemeral=False)

            # ✅ Show dropdown so the user can pick one
            embed = discord.Embed(
                title="📦 Choose an Order to Accept",
                description="Select which shipping order you want to take.",
                color=discord.Color.blurple()
            )

            view = OrderSelectView(uid, players, save_data)
            await interaction.response.send_message(embed=embed, view=view, ephemeral=False)
    class OrderSelectView(View):
        def __init__(self, uid, players, save_data):
            super().__init__(timeout=60)
            self.uid = uid
            self.players = players
            self.save_data = save_data

            # Add dropdown
            self.add_item(OrderSelect(uid, players, save_data))

    class OrderSelect(Select):
        def __init__(self, uid, players, save_data):
            self.uid = uid
            self.players = players
            self.save_data = save_data

            p = players[uid]
            options = []
            for idx, o in enumerate(p["shipping_orders"], 1):
                label = f"Order {idx}: {o['item']} × {o['qty']}"
                desc = f"Reward ${o['reward']} • Expires in {int((o['expires'] - time.time()) // 60)}m"
                options.append(discord.SelectOption(label=label, description=desc, value=str(idx - 1)))

            super().__init__(placeholder="Pick an order to accept...", options=options, min_values=1, max_values=1)

        async def callback(self, interaction: Interaction):
            uid = self.uid
            p = self.players[uid]
            index = int(self.values[0])

            if index < 0 or index >= len(p["shipping_orders"]):
                return await interaction.response.send_message("Invalid selection.", ephemeral=True)

            sel = p["shipping_orders"].pop(index)
            sel["status"] = "ACCEPTED"
            p["accepted_order"] = sel
            self.save_data()

            await interaction.response.edit_message(
                content=f"✅ Accepted **{sel['item']} × {sel['qty']}** for **${sel['reward']}**.",
                embed=None,
                view=None
            )


    class ShipButton(Button):
        def __init__(self):
            super().__init__(label="Ship Items 📤", style=discord.ButtonStyle.secondary)

        async def callback(self, interaction: Interaction):
            uid = str(interaction.user.id)
            ensure_player(uid)
            ensure_schema(uid)
            p = players[uid]
            acc = p.get("accepted_order")
            if not acc:
                return await interaction.response.send_message("You have no accepted order.", ephemeral=False)
            if acc["expires"] <= _now():
                p["accepted_order"] = None
                save_data()
                return await interaction.response.send_message("That order expired.", ephemeral=False)

            inv = p.setdefault("inventory", {})
            have = inv.get(acc["item"], 0)
            if have < acc["qty"]:
                return await interaction.response.send_message(
                    f"You need **{acc['qty']}× {acc['item']}**, but you only have **{have}**.",
                    ephemeral=False
                )
            inv[acc["item"]] = have - acc["qty"]
            if inv[acc["item"]] <= 0:
                inv.pop(acc["item"], None)
            p["money"] = p.get("money", 0) + acc["reward"]
            p["accepted_order"] = None
            save_data()
            await interaction.response.send_message(f"📦 Shipped! You earned **${acc['reward']}**.", ephemeral=False)

    class RefreshButton(Button):
        def __init__(self):
            super().__init__(label="Refresh 🔄", style=discord.ButtonStyle.secondary)

        async def callback(self, interaction: Interaction):
            uid = str(interaction.user.id)
            ensure_player(uid)
            ensure_schema(uid)
            _clean_and_fill(uid)
            embed = _build_orders_embed(uid)
            await interaction.response.edit_message(embed=embed, view=SCView(uid, locked=False))

    @client.tree.command(name="shippingcenter", description="Open your Shipping Center.")
    async def shippingcenter(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first.", ephemeral=True
            )
        ensure_schema(uid)
        p = players[uid]

        if not p["shipping_center_owned"]:
            return await interaction.response.send_message(
                embed=_build_locked_embed(uid),
                view=SCView(uid, locked=True)
            )
        _clean_and_fill(uid)
        embed = _build_orders_embed(uid)
        await interaction.response.send_message(
            embed=embed,
            view=SCView(uid, locked=False)
        )

    # ✅ Export helpers for Factory menu integration (must be inside setup)
    globals()["build_locked_embed"] = _build_locked_embed
    globals()["build_orders_embed"] = _build_orders_embed
    globals()["SCBoardView"] = SCView
