# cogs/recipes.py
import discord
from discord import Interaction, ui

# =========================
# 📜 RECIPE DATA
# =========================
RECIPES = {
    # === Tier 0 Recipes ===
    "bolts": {
        "money": 3,
        "inputs": {"Scrap Metal": 2},
        "outputs": {"bolts": 1},
    },
    "worn gear": {
        "money": 3,
        "inputs": {"Scrap Metal": 3},
        "outputs": {"worn_gear": 1},
    },
    "low grade ingot": {
        "money": 3,
        "inputs": {"Iron Ore": 2},
        "outputs": {"low_grade_ingot": 1},
    },
    "wire mk0": {
        "money": 3,
        "inputs": {"Copper Ore": 2},
        "outputs": {"wire_mk0": 1},
    },
    "glass lens": {
        "money": 4,
        "inputs": {"Glass": 1, "Scrap Metal": 1},
        "outputs": {"glass_lens": 1},
    },
    "primitive circuit": {
        "money": 5,
        "inputs": {"wire mk0": 2, "Scrap Metal": 1},
        "outputs": {"primitive_circuit": 1},
    },

    # (leave everything after this exactly as it already is)


    # =========================
    # 🧱 EARLY MATERIAL REFINING (Tier 1)
    # =========================
    "Charcoal": {"money": 25, "inputs": {"Wood": 3}},
    "Planks": {"money": 30, "inputs": {"Wood": 2}},
    "Glass": {"money": 40, "inputs": {"Sand": 3}},
    "Concrete Mix": {"money": 55, "inputs": {"Crushed Stone": 3, "Water": 1}},
    "Scrap Metal": {"money": 35, "inputs": {"Scrap Bits": 3}},
    "Molten Ingot": {"money": 50, "inputs": {"Molten Scrap": 2, "Coal": 1}},
    "Copper Wire": {"money": 60, "inputs": {"Copper Ore": 3, "Charcoal": 1}},
    "Silicon Chunk": {"money": 65, "inputs": {"Sand": 4, "Coal": 1}},
    "Crude Oil Barrel": {"money": 75, "inputs": {"Coal": 15, "Water": 25}},
    "Resin": {"money": 90, "inputs": {"Crude Oil Barrel": 1, "Wood": 2}},

    # =========================
    # 🧱 BASE & PROCESSING (Tier 1–2)
    # =========================
    # (Note: Duplicate keys like "Scrap Metal" and "Copper Wire" override
    # earlier definitions in Python dicts. Kept as provided.)
    "Scrap Metal":    {"money": 15,  "inputs": {"Coal": 1}},
    "Copper Wire":    {"money": 25,  "inputs": {"Scrap Metal": 2}},
    "Steel Sheet":    {"money": 40,  "inputs": {"Scrap Metal": 4}},
    "Iron Plate":     {"money": 45,  "inputs": {"Scrap Metal": 5}},
    "Refined Copper": {"money": 65,  "inputs": {"Copper Wire": 4}},
    "Circuit Board":  {"money": 120, "inputs": {"Refined Copper": 3, "Steel Sheet": 2}},

    # 🔩 Machine Material Support
    "Carbon Alloy":   {"money": 85,  "inputs": {"Coal": 3, "Iron Plate": 1}},
    "Silicon Ingot":  {"money": 110, "inputs": {"Coal": 2, "Refined Copper": 1}},
    "Plastic Polymer":{"money": 140, "inputs": {"Coal": 4, "Scrap Metal": 2}},
    "Insulated Wire": {"money": 160, "inputs": {"Copper Wire": 3, "Plastic Polymer": 1}},
    "Lubricant Fluid":{"money": 210, "inputs": {"Coal": 3, "Refined Copper": 1}},
    "Refined Oil":    {"money": 250, "inputs": {"Coal": 4, "Lubricant Fluid": 1}},
    "Nanoplastic":    {"money": 520, "inputs": {"Plastic Polymer": 2, "Refined Oil": 1}},

    # =========================
    # ⚙️ COMPONENTS (Tier 3–4)
    # =========================
    "Servo Motor":    {"money": 270,  "inputs": {"Steel Sheet": 4, "Copper Wire": 3}},
    "Gear Assembly":  {"money": 325,  "inputs": {"Iron Plate": 3, "Steel Sheet": 3}},
    "Logic Core":     {"money": 480,  "inputs": {"Circuit Board": 3, "Copper Wire": 5}},
    "AI Module":      {"money": 1250, "inputs": {"Logic Core": 3, "Circuit Board": 5, "Refined Copper": 5}},

    # 🧩 Expanded Components
    "Motor Housing":  {"money": 420,  "inputs": {"Steel Sheet": 3, "Carbon Alloy": 2}},
    "Cooling Unit":   {"money": 520,  "inputs": {"Lubricant Fluid": 2, "Steel Sheet": 2, "Refined Copper": 1}},
    "Copper Coil":    {"money": 600,  "inputs": {"Insulated Wire": 2, "Refined Copper": 2}},
    "Precision Gear": {"money": 750,  "inputs": {"Gear Assembly": 1, "Iron Plate": 2, "Lubricant Fluid": 1}},
    "Control Chip":   {"money": 850,  "inputs": {"Circuit Board": 2, "Silicon Ingot": 2}},
    "Hydraulic Pump": {"money": 1100, "inputs": {"Motor Housing": 1, "Lubricant Fluid": 2, "Steel Sheet": 3}},
    "Sensor Module":  {"money": 1250, "inputs": {"Control Chip": 1, "Copper Coil": 2, "Refined Copper": 1}},
    "Power Regulator":{"money": 1400, "inputs": {"Control Chip": 2, "Power Cell": 1, "Silicon Ingot": 2}},
    "Hydraulic Frame":{"money": 1800, "inputs": {"Hydraulic Pump": 1, "Reinforced Steel": 2, "Lubricant Fluid": 2}},

    # =========================
    # 🏗️ MACHINE FRAMES (Tier 4–5)
    # =========================
    "Industrial Frame": {"money": 2200, "inputs": {"Steel Sheet": 8, "Gear Assembly": 4}},
    "Power Cell":       {"money": 2600, "inputs": {"Logic Core": 3, "Circuit Board": 4}},

    # =========================
    # 🤖 EXISTING ITEMS (Tier 4–5)
    # =========================
    "Gizmo":         {"money": 160,   "inputs": {"Scrap Metal": 3, "Copper Wire": 2}},
    "Servo Pack":    {"money": 420,   "inputs": {"Steel Sheet": 3, "Servo Motor": 2}},
    "Control Unit":  {"money": 850,   "inputs": {"Circuit Board": 3, "Copper Wire": 4}},
    "Drone":         {"money": 3100,  "inputs": {"Servo Pack": 3, "Control Unit": 2, "Steel Sheet": 4}},
    "Assembler":     {"money": 7500,  "inputs": {"Gizmo": 6, "Servo Pack": 3, "Circuit Board": 4}},
    "Quantum Chip":  {"money": 15000, "inputs": {"Control Unit": 4, "Circuit Board": 6, "Copper Wire": 12}},

    # Craftable Machine
    "Assembler Machine": {"money": 8500, "inputs": {"Industrial Frame": 2, "Servo Motor": 3, "Control Unit": 2}},


# -------------------------
# 🧪 RESEARCH LAB UNLOCK
# -------------------------
"Research Lab": {
    "money": 0,
    "inputs": {"Scrap Metal": 50, "Copper Wire": 30},
    "outputs": {"Research Lab": 1}
},
    # =========================
    # 🧠 RESEARCH FACILITY (Tier 5)
    # =========================
    "Research Data": {
        "money": 1200,
        "inputs": {"Circuit Board": 2, "Refined Copper": 2, "Plastic Polymer": 1}
    },
    "Research Center": {
        "money": 9500,
        "inputs": {"Industrial Frame": 2, "Control Unit": 3, "Research Data": 3, "Refined Copper": 6}
    },

    # =========================
    # 🚢 SHIPBUILDING (Tier 6)
    # =========================
    "Reinforced Steel": {"money": 6500,  "inputs": {"Steel Sheet": 8, "Coal": 6}},
    "Hull Plating":     {"money": 8500,  "inputs": {"Reinforced Steel": 4, "Steel Sheet": 6, "Coal": 4}},
    "Ship Frame":       {"money": 12000, "inputs": {"Industrial Frame": 2, "Hull Plating": 3, "Reinforced Steel": 3}},
    "Cargo Engine":     {"money": 15000, "inputs": {"Power Cell": 3, "Servo Motor": 4, "Steel Sheet": 6, "Gear Assembly": 2}},
    "Navigation Core":  {"money": 19000, "inputs": {"AI Module": 2, "Logic Core": 3, "Circuit Board": 6, "Refined Copper": 6}},
    "Cargo Ship":       {"money": 42000, "inputs": {"Ship Frame": 3, "Cargo Engine": 2, "Navigation Core": 1, "Hull Plating": 4, "Reinforced Steel": 5}},
}

# =========================
# 🧠 CORE LOGIC
# =========================

def have_items(inv, reqs, amount):
    for item, need in reqs.items():
        if inv.get(item, 0) < need * amount:
            return False
    return True

def remove_items(inv, reqs, amount):
    for item, need in reqs.items():
        inv[item] = inv.get(item, 0) - need * amount
        if inv[item] <= 0:
            inv.pop(item, None)

def add_item(inv, name, amount):
    inv[name] = inv.get(name, 0) + amount


class ConfirmCraft(ui.View):
    def __init__(self, item, players, uid, save_data, ensure_player):
        super().__init__(timeout=60)
        self.item = item
        self.players = players
        self.uid = uid          # this is already a string user id
        self.save_data = save_data
        self.ensure_player = ensure_player

    @ui.button(label="Craft", style=discord.ButtonStyle.green)
    async def craft_button(self, interaction: Interaction, button: ui.Button):
        """Open a modal to ask how many to craft."""
        modal = CraftAmountModal(self)
        await interaction.response.send_modal(modal)

    @ui.button(label="Cancel", style=discord.ButtonStyle.red)
    async def cancel_button(self, interaction: Interaction, button: ui.Button):
        await interaction.response.send_message("Crafting canceled.", ephemeral=True)
        self.stop()


class CraftAmountModal(ui.Modal, title="Craft items"):
    """Modal that asks the player how many items they want to craft."""

    def __init__(self, parent: ConfirmCraft):
        super().__init__(title=f"Craft {parent.item}")
        self.parent = parent

        self.qty = ui.TextInput(
            label="How many do you want to craft?",
            placeholder="Enter a number (1–100)",
            default="1",
            required=True,
            min_length=1,
            max_length=4,
        )
        self.add_item(self.qty)

    async def on_submit(self, interaction: Interaction):
        # --- parse + validate amount ---
        try:
            amount = int(str(self.qty.value).strip())
            if amount <= 0:
                raise ValueError
            # hard cap to prevent crazy amounts / lag
            if amount > 100:
                amount = 100
        except ValueError:
            return await interaction.response.send_message(
                "❌ Please enter a **valid positive number**.",
                ephemeral=True,
            )

        uid = self.parent.uid
        if not self.parent.ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first.", ephemeral=True
            )

        p = self.parent.players[uid]
        inv = p.setdefault("inventory", {})
        data = RECIPES[self.parent.item]

        # --- money check ---
        total_money = data["money"] * amount
        if p.get("money", 0) < total_money:
            return await interaction.response.send_message(
                f"❌ Not enough money. You need **${total_money:,}**.",
                ephemeral=True,
            )

        # --- materials check ---
        if not have_items(inv, data["inputs"], amount):
            need = ", ".join(
                [f"{k}×{v * amount}" for k, v in data["inputs"].items()]
            )
            return await interaction.response.send_message(
                f"Missing materials: {need}.",
                ephemeral=True,
            )

        # --- actually craft ---
        p["money"] -= total_money
        remove_items(inv, data["inputs"], amount)
        add_item(inv, self.parent.item, amount)
        self.parent.save_data()

        await interaction.response.send_message(
            f"✅ Crafted **{amount}× {self.parent.item}**!",
            ephemeral=False,
        )


# =========================
# 🧭 NAV + DROPDOWN
# =========================

def _page_window(total, page, size=25):
    """Return (start, end, total_pages) for given page/size with bounds."""
    total_pages = (max(1, total) - 1) // size + 1
    page = max(0, min(page, total_pages - 1))
    start = page * size
    end = start + size
    return start, end, total_pages

class ItemSelect(ui.Select):
    def __init__(self, players, uid, save_data, ensure_player, page=0):
        self.players = players
        self.uid = uid
        self.save_data = save_data
        self.ensure_player = ensure_player
        self.page = page

        all_items = list(RECIPES.items())
        start, end, total_pages = _page_window(len(all_items), page, 25)
        current_items = all_items[start:end]

        # Build options (1..25)
        options = []
        for item, data in current_items:
            from .items import ITEMS
            reqs = ", ".join([f"{ITEMS.get(mat, {}).get('name', mat)}×{amt}" for mat, amt in data["inputs"].items()])
            desc = f"Costs ${data['money']} • Requires: {reqs}"
            # Discord description <= 100 chars
            if len(desc) > 100:
                desc = desc[:97] + "…"
            options.append(discord.SelectOption(label=item, description=desc, value=item))

        # Safety: ensure at least 1 option (in case of empty recipes)
        if not options:
            options = [discord.SelectOption(label="No recipes available", value="__none__")]

        super().__init__(
            placeholder=f"Select a recipe (Page {page+1}/{total_pages})",
            min_values=1, max_values=1, options=options
        )

    async def callback(self, interaction: Interaction):
        item = self.values[0]
        if item == "__none__":
            return await interaction.response.send_message("No recipes to craft right now.", ephemeral=True)

        view = ConfirmCraft(item, self.players, self.uid, self.save_data, self.ensure_player)
        await interaction.response.send_message(
            f"Selected **{item}**. Press Craft to choose how many to make.",
            view=view
        )



class PrevPageButton(ui.Button):
    def __init__(self):
        super().__init__(label="⬅ Prev", style=discord.ButtonStyle.secondary)

    async def callback(self, interaction: Interaction):
        parent: "CraftMenu" = self.view
        new_page = max(0, parent.page - 1)
        await interaction.response.edit_message(
            content="Pick something to craft:",
            view=CraftMenu(parent.players, parent.uid, parent.save_data, parent.ensure_player, page=new_page)
        )


class NextPageButton(ui.Button):
    def __init__(self):
        super().__init__(label="Next ➡", style=discord.ButtonStyle.secondary)

    async def callback(self, interaction: Interaction):
        parent: "CraftMenu" = self.view
        new_page = min(parent.total_pages - 1, parent.page + 1)
        await interaction.response.edit_message(
            content="Pick something to craft:",
            view=CraftMenu(parent.players, parent.uid, parent.save_data, parent.ensure_player, page=new_page)
        )


class BackToFactoryButton(ui.Button):
    def __init__(self):
        super().__init__(label="🏭 Back to Factory", style=discord.ButtonStyle.primary)

    async def callback(self, interaction: Interaction):
        # Import inside to avoid circular import at module load time
        from cogs.ui import FactoryView, fmt_embed

        parent: "CraftMenu" = self.view
        uid = parent.uid
        p = parent.players.get(uid, {})
        # ✅ Send a NEW message (not editing the craft menu)
        await interaction.response.send_message(
            embed=fmt_embed(interaction.user, p),
            view=FactoryView(uid, parent.players, parent.save_data, parent.ensure_player)
        )


class CraftMenu(ui.View):
    def __init__(self, players, uid, save_data, ensure_player, page=0):
        super().__init__(timeout=60)
        self.players = players
        self.uid = uid
        self.save_data = save_data
        self.ensure_player = ensure_player
        self.page = page

        total = len(RECIPES)
        _, _, self.total_pages = _page_window(total, page, 25)

        # Dropdown for current page
        self.add_item(ItemSelect(players, uid, save_data, ensure_player, page))

        # ✅ Navigation buttons only if needed
        if self.total_pages > 1 and page > 0:
            self.add_item(PrevPageButton())
        if self.total_pages > 1 and page < self.total_pages - 1:
            self.add_item(NextPageButton())

        # ✅ Always-visible "Back to Factory" that sends a NEW message
        self.add_item(BackToFactoryButton())


# =========================
# 🔧 COMMAND REGISTRATION
# =========================

def setup(client, players, save_data, ensure_player):
    @client.tree.command(name="recipes", description="List crafting recipes.")
    async def recipes(interaction: Interaction):
        lines = []
        for out, data in RECIPES.items():
            need = ", ".join([f"{k}×{v}" for k, v in data["inputs"].items()])
            lines.append(f"**{out}** — ${data['money']} & {need}")
        await interaction.response.send_message("**Crafting Recipes**:\n" + "\n".join(lines))

    @client.tree.command(name="craft", description="Craft an item using materials in your inventory.")
    async def craft(interaction: Interaction, item: str, amount: int = 1):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")
        item = item.strip()
        if item not in RECIPES:
            return await interaction.response.send_message("Unknown recipe. Use **/recipes** to see options.")
        p = players[uid]
        inv = p.setdefault("inventory", {})
        amt = max(1, amount)
        data = RECIPES[item]
        total_money = data["money"] * amt
        if p.get("money", 0) < total_money:
            return await interaction.response.send_message(f"Need **${total_money}** to craft {amt}× {item}.")
        if not have_items(inv, data["inputs"], amt):
            need = ", ".join([f"{k}×{v*amt}" for k, v in data["inputs"].items()])
            return await interaction.response.send_message(f"Missing materials: {need}.")
        # Pay money and materials
        p["money"] -= total_money
        remove_items(inv, data["inputs"], amt)
        add_item(inv, item, amt)

        # 🔰 Starter Crafting Bonus check
        bonus_text = ""
        if not p.get("starter_crafting_bonus_claimed"):
            scrap = inv.get("Scrap Metal", 0)
            wire = inv.get("Copper Wire", 0)
            if scrap >= 10 and wire >= 5:
                p["starter_crafting_bonus_claimed"] = True
                bonus_money = 2000
                p["money"] = p.get("money", 0) + bonus_money
                workers = p.setdefault("workers", {})
                workers["craft"] = workers.get("craft", 0) + 1
                bonus_text = (
                    "\n\n🎉 **Starter Crafting Bonus unlocked!**\n"
                    f"You earned **${{bonus_money:,}}** and **+1 Craft Worker** "
                    "for reaching 10 Scrap Metal & 5 Copper Wire."
                )

        save_data()
        await interaction.response.send_message(
            f"🧩 Crafted **{amt}× {item}** successfully!{bonus_text}"
        )

    @client.tree.command(name="craftmenu", description="Open crafting selection menu.")
    async def craftmenu(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")
        await interaction.response.send_message(
            "Pick something to craft:",
            view=CraftMenu(players, uid, save_data, ensure_player)
        )
