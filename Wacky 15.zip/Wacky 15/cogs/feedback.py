# cogs/feedback.py
import discord
from discord import app_commands
from discord.ext import commands
import json
import os

CONFIG_FILE = "feedback_config.json"
REPORTS_FILE = "dev_reports.json"


# -------------------------------
# Helpers
# -------------------------------
def load_json(path, default):
    """Load JSON safely, falling back to a default if the file is missing or corrupt."""
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump(default, f, indent=4)
        return default

    try:
        with open(path, "r") as f:
            return json.load(f)
    except json.JSONDecodeError:
        # Attempt to back up the corrupt file
        try:
            os.replace(path, path + ".corrupt")
        except OSError:
            # If backup fails, just overwrite with default
            pass

        with open(path, "w") as f:
            json.dump(default, f, indent=4)
        return default


def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=4)


# -------------------------------
# Cog
# -------------------------------
class Feedback(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config = load_json(CONFIG_FILE, {"feedback_channel": None, "suggestions_channel": None})
        self.reports = load_json(REPORTS_FILE, {})

    # ------------------------------------------
    # SET FEEDBACK CHANNEL
    # ------------------------------------------
    @app_commands.command(name="setfeedback", description="Set this channel to receive bug reports.")
    @app_commands.default_permissions(administrator=True)
    async def setfeedback(self, interaction: discord.Interaction, channel: discord.TextChannel):
        self.config["feedback_channel"] = channel.id
        save_json(CONFIG_FILE, self.config)
        await interaction.response.send_message(
            f"✅ Feedback channel set to {channel.mention}.",
            ephemeral=True,
        )

    # ------------------------------------------
    # SET SUGGESTIONS CHANNEL
    # ------------------------------------------
    @app_commands.command(name="setsuggestions", description="Set this channel to receive suggestions.")
    @app_commands.default_permissions(administrator=True)
    async def setsuggestions(self, interaction: discord.Interaction, channel: discord.TextChannel):
        self.config["suggestions_channel"] = channel.id
        save_json(CONFIG_FILE, self.config)
        await interaction.response.send_message(
            f"✅ Suggestions channel set to {channel.mention}.",
            ephemeral=True,
        )

    # ------------------------------------------
    # FEEDBACK PANEL
    # ------------------------------------------
    class FeedbackView(discord.ui.View):
        def __init__(self, outer):
            super().__init__(timeout=180)
            self.outer = outer

        @discord.ui.button(label="Bug Report", style=discord.ButtonStyle.danger, emoji="🐞")
        async def bug_button(self, interaction: discord.Interaction, button: discord.ui.Button):
            await self.outer.open_bug_modal(interaction)

        @discord.ui.button(label="Suggestion", style=discord.ButtonStyle.primary, emoji="💡")
        async def suggestion_button(self, interaction: discord.Interaction, button: discord.ui.Button):
            await self.outer.open_suggestion_modal(interaction)

    class BugReportModal(discord.ui.Modal, title="🐞 Bug Report"):
        def __init__(self, outer):
            super().__init__()
            self.outer = outer

            self.description = discord.ui.TextInput(
                label="Describe the bug",
                style=discord.TextStyle.paragraph,
                required=True,
                max_length=1000,
            )
            self.steps = discord.ui.TextInput(
                label="Steps to reproduce (optional)",
                style=discord.TextStyle.paragraph,
                required=False,
                max_length=1000,
            )

            self.add_item(self.description)
            self.add_item(self.steps)

        async def on_submit(self, interaction):
            cfg = self.outer.config
            channel_id = cfg.get("feedback_channel")
            if not channel_id:
                return await interaction.response.send_message("❌ Feedback channel not set.", ephemeral=True)

            channel = interaction.client.get_channel(channel_id)

            embed = discord.Embed(
                title="🐞 New Bug Report",
                color=discord.Color.red()
            )
            embed.add_field(name="Reporter", value=interaction.user.mention, inline=False)
            embed.add_field(name="Description", value=self.description.value, inline=False)
            embed.add_field(name="Steps", value=self.steps.value or "None", inline=False)

            sent = await channel.send(embed=embed)

            # AUTO-CLASSIFICATION
            devcog = interaction.client.get_cog("DevResponse")
            if devcog:
                await devcog.auto_classify(sent)

            await interaction.response.send_message("✅ Bug report submitted!", ephemeral=True)

    class SuggestionModal(discord.ui.Modal, title="💡 Suggestion"):
        def __init__(self, outer):
            super().__init__()
            self.outer = outer

            self.idea = discord.ui.TextInput(
                label="Your suggestion",
                style=discord.TextStyle.paragraph,
                required=True,
                max_length=1000,
            )

            self.add_item(self.idea)

        async def on_submit(self, interaction):
            cfg = self.outer.config
            channel_id = cfg.get("suggestions_channel")
            if not channel_id:
                return await interaction.response.send_message("❌ Suggestions channel not set.", ephemeral=True)

            channel = interaction.client.get_channel(channel_id)

            embed = discord.Embed(
                title="💡 New Suggestion",
                color=discord.Color.green()
            )
            embed.add_field(name="From", value=interaction.user.mention, inline=False)
            embed.add_field(name="Suggestion", value=self.idea.value, inline=False)

            sent = await channel.send(embed=embed)

            # AUTO-CLASSIFICATION
            devcog = interaction.client.get_cog("DevResponse")
            if devcog:
                await devcog.auto_classify(sent)

            await interaction.response.send_message("✅ Suggestion submitted!", ephemeral=True)

    # ------------------------------------------
    # OPEN MODALS
    # ------------------------------------------
    async def open_bug_modal(self, interaction: discord.Interaction):
        await interaction.response.send_modal(self.BugReportModal(self))

    async def open_suggestion_modal(self, interaction: discord.Interaction):
        await interaction.response.send_modal(self.SuggestionModal(self))

    # ------------------------------------------
    # FEEDBACK PANEL COMMAND
    # ------------------------------------------
    @app_commands.command(name="feedbackpanel", description="Show the feedback & suggestions panel.")
    async def feedbackpanel(self, interaction: discord.Interaction):
        view = self.FeedbackView(self)
        await interaction.response.send_message(
            "📝 **Click a button below to submit feedback or suggestions!**",
            view=view,
            ephemeral=False
        )


# -------------------------------
# SETUP - register Feedback system
# -------------------------------
def setup(client):
    feedback_cog = Feedback(client)
    client.tree.add_command(feedback_cog.setfeedback)
    client.tree.add_command(feedback_cog.setsuggestions)
    client.tree.add_command(feedback_cog.feedbackpanel)
