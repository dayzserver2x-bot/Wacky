# cogs/sell_ui.py

import discord
from discord import Interaction
from discord.ui import View, Button, Modal, TextInput

from cogs.items import ITEMS  # price table


# ===============================================================
#  CUSTOM QUANTITY MODAL
# ===============================================================
class CustomSellModal(Modal):
    """Modal to ask the user for a custom quantity to sell."""

    def __init__(self, uid, players, save_data, item):
        super().__init__(title=f"Sell {item}")

        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.item = item

        self.qty = TextInput(
            label="Enter amount to sell",
            placeholder="e.g. 37",
            required=True
        )
        self.add_item(self.qty)

    async def on_submit(self, interaction: Interaction):
        p = self.players[self.uid]
        inv = p.setdefault("inventory", {})
        have = inv.get(self.item, 0)

        # validate
        try:
            amount = int(str(self.qty.value))
            if amount <= 0:
                raise ValueError
        except Exception:
            return await interaction.response.send_message(
                "❌ Please enter a **valid positive number**.",
                ephemeral=True
            )

        if have < amount:
            return await interaction.response.send_message(
                f"❌ You only have **{have}× {self.item}**.",
                ephemeral=True
            )

        # perform sale
        inv[self.item] -= amount
        if inv[self.item] <= 0:
            inv.pop(self.item, None)

        gain = ITEMS[self.item]["sell"] * amount
        p["money"] = p.get("money", 0) + gain
        self.save_data()

        await interaction.response.send_message(
            f"💵 Sold **{amount:,}× {self.item}** for **${gain:,}**.",
            ephemeral=True
        )


# ---------------------------------------------------------------
def build_sell_embed(uid, players, item):
    """Helper to create the quantity-selection embed for an item."""
    p = players[uid]
    inv = p.setdefault("inventory", {})
    have = inv.get(item, 0)
    price = ITEMS[item]["sell"]

    desc = (
        f"You own **{have}× {item}**.\n"
        f"Sell price: **${price:,} each**.\n\n"
        "Select how many you want to sell:"
    )

    return discord.Embed(
        title=f"💰 Sell {item}",
        description=desc,
        color=discord.Color.green(),
    )


# ===============================================================
#  VIEW: QUANTITY BUTTONS
# ===============================================================
class SellAmountView(View):
    """Shows buttons like Sell 1 / 10 / 25 / 50 / 100 / Max / Custom."""

    def __init__(self, uid, players, save_data, item, return_factory=None):
        super().__init__(timeout=120)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.item = item
        self.return_factory = return_factory

        self._build_buttons()

    # Create the buttons dynamically so they can reflect inventory.
    def _build_buttons(self):
        p = self.players[self.uid]
        inv = p.setdefault("inventory", {})
        have = inv.get(self.item, 0)

        # Helper to create a sell button
        def add_sell_button(label: str, qty: int):
            btn = Button(
                label=label,
                style=discord.ButtonStyle.secondary,
                disabled=have < qty,
            )

            async def on_click(interaction: Interaction, amount: int = qty):
                await self._handle_sale(interaction, amount)

            btn.callback = on_click
            self.add_item(btn)

        for q in (1, 10, 25, 50, 100):
            add_sell_button(f"Sell {q}", q)

        # Sell Max
        max_label = f"Sell Max ({have})" if have > 0 else "Sell Max (0)"
        btn_max = Button(
            label=max_label,
            style=discord.ButtonStyle.success,
            disabled=have <= 0,
        )

        async def on_max(interaction: Interaction):
            await self._handle_sale(interaction, have)

        btn_max.callback = on_max
        self.add_item(btn_max)

        # Custom amount
        btn_custom = Button(
            label="Custom Amount",
            style=discord.ButtonStyle.primary,
        )

        async def on_custom(interaction: Interaction):
            modal = CustomSellModal(self.uid, self.players, self.save_data, self.item)
            await interaction.response.send_modal(modal)

        btn_custom.callback = on_custom
        self.add_item(btn_custom)

        # Back to factory
        btn_back = Button(
            label="⬅️ Back to Factory",
            style=discord.ButtonStyle.danger,
        )

        async def on_back(interaction: Interaction):
            # Go back to the main FactoryView, if provided
            if self.return_factory is not None:
                # Import here to avoid circular import at module level
                from cogs.ui import fmt_embed
                p = self.players[self.uid]
                embed = fmt_embed(interaction.user, p)
                await interaction.response.edit_message(
                    embed=embed,
                    view=self.return_factory,
                )
            else:
                # Just clear the sell view
                await interaction.response.edit_message(view=None)

        btn_back.callback = on_back
        self.add_item(btn_back)

    async def _handle_sale(self, interaction: Interaction, qty: int):
        p = self.players[self.uid]
        inv = p.setdefault("inventory", {})
        have = inv.get(self.item, 0)

        if qty <= 0 or have <= 0 or have < qty:
            return await interaction.response.send_message(
                f"❌ Not enough **{self.item}**.",
                ephemeral=True,
            )

        inv[self.item] -= qty
        if inv[self.item] <= 0:
            inv.pop(self.item, None)

        gain = ITEMS[self.item]["sell"] * qty
        p["money"] = p.get("money", 0) + gain
        self.save_data()

        await interaction.response.send_message(
            f"💵 Sold **{qty:,}× {self.item}** for **${gain:,}**.",
            ephemeral=True,
        )


# ===============================================================
#  VIEW: CHOOSE WHICH ITEM TO SELL
# ===============================================================
class SellItemSelect(discord.ui.Select):
    def __init__(self, uid, players, save_data, return_factory=None):
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.return_factory = return_factory

        p = players[uid]
        inv = p.setdefault("inventory", {})

        options = []
        for name, amount in inv.items():
            data = ITEMS.get(name)
            if not data:
                continue
            price = data.get("sell", 0)
            if price <= 0 or amount <= 0:
                continue

            label = f"{name} (x{amount})"
            description = f"Sell price: ${price:,} each"
            options.append(discord.SelectOption(label=label, value=name, description=description))

        if not options:
            options = [
                discord.SelectOption(
                    label="No sellable items",
                    value="__none__",
                    description="You have nothing to sell right now.",
                )
            ]

        super().__init__(
            placeholder="Choose something from your inventory to sell",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: Interaction):
        value = self.values[0]
        if value == "__none__":
            return await interaction.response.send_message(
                "❌ You don't have any sellable items.",
                ephemeral=True,
            )

        item = value
        embed = build_sell_embed(self.uid, self.players, item)
        view = SellAmountView(self.uid, self.players, self.save_data, item, self.return_factory)

        await interaction.response.edit_message(embed=embed, view=view)


class SellItemMenu(View):
    """First screen: choose *which* item to sell."""

    def __init__(self, uid, players, save_data, return_factory=None):
        super().__init__(timeout=180)
        self.uid = uid
        self.players = players
        self.save_data = save_data
        self.return_factory = return_factory

        self.add_item(SellItemSelect(uid, players, save_data, return_factory))

        # Back button to factory
        if return_factory is not None:
            btn_back = Button(
                label="⬅️ Back to Factory",
                style=discord.ButtonStyle.danger,
            )

            async def on_back(interaction: Interaction):
                from cogs.ui import fmt_embed
                p = self.players[self.uid]
                embed = fmt_embed(interaction.user, p)
                await interaction.response.edit_message(
                    embed=embed,
                    view=self.return_factory,
                )

            btn_back.callback = on_back
            self.add_item(btn_back)


# ===============================================================
#  ENTRY POINT USED BY ui.py
# ===============================================================
async def open_sell_menu(
    interaction: Interaction,
    uid,
    players,
    save_data,
    return_factory=None,
    item=None,
):
    """Return (embed, view) for the sell flow.

    - If *item* is None (normal case from FactoryView), we show the
      "choose item" dropdown.
    - If *item* is provided, we jump straight to quantity selection.
    """
    if item is None:
        embed = discord.Embed(
            title="💰 Sell Items",
            description="Choose something from your inventory to sell:",
            color=discord.Color.gold(),
        )
        view = SellItemMenu(uid, players, save_data, return_factory)
        return embed, view

    # Directly open quantity selection for a known item
    embed = build_sell_embed(uid, players, item)
    view = SellAmountView(uid, players, save_data, item, return_factory)
    return embed, view
