import discord
from discord import app_commands
from discord.ext import commands
from discord.ui import View, Button

# -----------------------------
# HELP CATEGORIES
# -----------------------------

HELP_DATA = {
    "basics": {
        "title": "📘 Wacky Factory — Basics",
        "desc": (
            "**Welcome to Wacky Factory!**\n\n"
            "Build machines, mine resources, craft components, and complete shipping orders.\n\n"
            "**Core Commands:**\n"
            "• `/start` — Begin your journey\n"
            "• `/factory` — Factory overview & actions\n"
            "• `/machines` — Manage machines\n"
            "• `/shippingcenter` — Deliver orders\n"
            "• `/inventory` — View items\n"
            "• `/work` — Earn money manually\n"
        )
    },

    "machines": {
        "title": "⚙️ Machines",
        "desc": (
            "**Machines produce materials over time.**\n\n"
            "**Machine Stats:**\n"
            "• ⏱️ *Cycle Time* — How long each production takes\n"
            "• 📦 *Output* — Amount produced each cycle\n"
            "• 🔥 *Fuel Use* — Coal required every cycle\n\n"
            "**Machine Types:**\n"
            "• Coal Drill — Mines Coal\n"
            "• Iron Miner — Mines Iron Ore\n"
            "• Smelter — Converts ore → bars\n"
            "• Advanced machines unlock as you tier up\n\n"
            "**Tip:** Upgrade machines for massive boosts!"
        )
    },

    "fuel": {
        "title": "🔥 Fuel & Coal System",
        "desc": (
            "**Machines require Coal to run.**\n"
            "If Coal hits **0**, machines **stop automatically**.\n\n"
            "**Ways to get Coal:**\n"
            "• Coal Drill machine\n"
            "• `/work`\n"
            "• Shipping Rewards\n"
            "• Crafting conversions\n\n"
            "**Overdrive Mode:**\n"
            "Uses double coal but boosts output by **+50%**."
        )
    },

    "shipping": {
        "title": "🚚 Shipping Center",
        "desc": (
            "**Earn money by completing orders.**\n\n"
            "**How it works:**\n"
            "1. Open `/shippingcenter`\n"
            "2. Choose an order\n"
            "3. Gather required materials\n"
            "4. Press Ship to deliver\n\n"
            "**Cargo Ship System:**\n"
            "• Huge payouts\n"
            "• Long cooldown\n"
            "• Requires high-tier crafted materials\n\n"
            "**Tip:** Ship lower-tier orders while preparing big ones.**"
        )
    },

    "crafting": {
        "title": "🧪 Crafting",
        "desc": (
            "**Crafting combines materials to create advanced parts.**\n\n"
            "**Examples:**\n"
            "• 3 Iron + 2 Coal → 1 Steel\n"
            "• 2 Steel + 1 Gear → 1 Engine\n\n"
            "**Uses:**\n"
            "• Unlock machines\n"
            "• Complete shipping orders\n"
            "• Build high-tier upgrades\n\n"
            "**Tip:** Craft in bulk to save time.**"
        )
    },

    "workers": {
        "title": "👷 Workers",
        "desc": (
            "**Workers boost different parts of your factory.**\n\n"
            "**Types of Workers:**\n"
            "• Money — More from `/work`\n"
            "• Machine — Faster production\n"
            "• Craft — Reduced crafting costs\n"
            "• Prestige — Boosts all future production\n"
            "• Storage — Increases capacity\n\n"
            "**Strategy:**\n"
            "Upgrade workers based on your bottleneck!"
        )
    },

    "tiers": {
        "title": "🏭 Factory Tiers",
        "desc": (
            "Factory tiers unlock new machines, recipes, and upgrades.\n\n"
            "**Tiering up gives:**\n"
            "• New machine types\n"
            "• Bigger storage\n"
            "• Better workers\n"
            "• More automation options\n\n"
            "**How to Tier Up:**\n"
            "Use `/factory` → **Tier Up** when you meet requirements."
        )
    },

    "prestige": {
        "title": "🌟 Prestige System",
        "desc": (
            "**Prestige resets your progress for a PERMANENT production multiplier.**\n\n"
            "**When to Prestige:**\n"
            "• When progress slows down\n"
            "• When machines cap out\n\n"
            "**Rewards:**\n"
            "• Permanent multiplier to ALL production\n"
            "• Faster machine cycles\n"
            "• Bigger profits forever\n\n"
            "**Prestige smart — not early.**"
        )
    },

    "tips": {
        "title": "💡 Tips & Tricks",
        "desc": (
            "• Always keep coal above 0\n"
            "• Automate high fuel machines first\n"
            "• Craft upgrades before shipping big orders\n"
            "• Prestige when growth slows\n"
            "• Check `/factory` often — machines tick even offline!"
        )
    },

    "commands": {
        "title": "📜 Wacky Factory — All Commands",
        "desc": (
            "**Main Commands**\n"
            "• `/start` — Begin your factory\n"
            "• `/factory` — Open factory overview\n"
            "• `/help` — Open this help menu\n"
            "• `/status` — Check bot/system status\n\n"
            "**Progression & Tiers**\n"
            "• `/tierupgrade` — Upgrade your factory tier\n"
            "• `/prestige` — Prestige for permanent multipliers (if available)\n\n"
            "**Economy & Work**\n"
            "• `/work` — Earn money manually\n"
            "• `/inventory` — View your items\n"
            "• `/daily` — Claim daily rewards\n\n"
            "**Machines & Production**\n"
            "• `/machines` — Manage machines\n"
            "• `/shippingcenter` — Shipping & orders\n"
            "• `/craft` — Craft items\n"
            "• `/recipes` — View crafting recipes (if enabled)\n\n"
            "**Guides & Tutorial**\n"
            "• `/tutorial` — Open the multi-step tutorial\n"
            "• `/starter_guide` or similar help commands (if enabled)\n\n"
            "_Note: Some developer/admin commands are hidden from this list._"
        )
    }
}


# -----------------------------
# HELP PANEL VIEW
# -----------------------------

class HelpPanel(View):
    def __init__(self):
        super().__init__(timeout=300)

    def build_embed(self, key: str):
        data = HELP_DATA[key]
        embed = discord.Embed(
            title=data["title"],
            description=data["desc"],
            color=discord.Color.blurple()
        )
        embed.set_footer(text="Wacky Factory Help Menu")
        return embed

    # -----------------------------
    # CATEGORY BUTTONS
    # -----------------------------

    @discord.ui.button(label="📘 Basics", style=discord.ButtonStyle.primary)
    async def basics(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("basics"), view=self)

    @discord.ui.button(label="⚙️ Machines", style=discord.ButtonStyle.secondary)
    async def machines(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("machines"), view=self)

    @discord.ui.button(label="🔥 Fuel", style=discord.ButtonStyle.secondary)
    async def fuel(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("fuel"), view=self)

    @discord.ui.button(label="🚚 Shipping", style=discord.ButtonStyle.secondary)
    async def shipping(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("shipping"), view=self)

    @discord.ui.button(label="🧪 Crafting", style=discord.ButtonStyle.secondary)
    async def crafting(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("crafting"), view=self)

    @discord.ui.button(label="👷 Workers", style=discord.ButtonStyle.secondary)
    async def workers(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("workers"), view=self)

    @discord.ui.button(label="🏭 Tiers", style=discord.ButtonStyle.secondary)
    async def tiers(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("tiers"), view=self)

    @discord.ui.button(label="🌟 Prestige", style=discord.ButtonStyle.secondary)
    async def prestige(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("prestige"), view=self)

    @discord.ui.button(label="💡 Tips", style=discord.ButtonStyle.success)
    async def tips(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("tips"), view=self)

    @discord.ui.button(label="📜 All Commands", style=discord.ButtonStyle.secondary)
    async def all_commands(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=self.build_embed("commands"), view=self)

    @discord.ui.button(label="❌ Close", style=discord.ButtonStyle.danger)
    async def close(self, interaction: discord.Interaction, button: Button):
        await interaction.message.delete()


# -----------------------------
# SETUP FUNCTION FOR COG
# -----------------------------

def setup(client):
    @client.tree.command(name="help", description="Open the Wacky Factory Help Menu")
    async def help_cmd(interaction: discord.Interaction):
        view = HelpPanel()
        embed = view.build_embed("basics")
        await interaction.response.send_message(embed=embed, view=view, ephemeral=False)
