# cogs/market.py

import discord
from discord import app_commands, Interaction
import json
import os
import time

MARKET_FILE = "market.json"

# ---------------- MARKET STORAGE ----------------

def load_market():
    if os.path.exists(MARKET_FILE):
        try:
            with open(MARKET_FILE, "r") as f:
                data = json.load(f)
                # basic sanity
                data.setdefault("next_id", 1)
                data.setdefault("listings", [])
                return data
        except Exception:
            pass
    return {"next_id": 1, "listings": []}


def save_market():
    with open(MARKET_FILE, "w") as f:
        json.dump(market, f, indent=4)


market = load_market()


def find_listing(listing_id: int):
    for l in market["listings"]:
        if l.get("id") == listing_id:
            return l
    return None


def fmt_price(p: int) -> str:
    return f"${p:,}"


# ---------------- SETUP ----------------

def setup(client, players, save_data, ensure_player):

    # Helpers to make sure player schema is safe
    def ensure_schema(uid: str):
        p = players.setdefault(uid, {})
        p.setdefault("money", 0)
        p.setdefault("inventory", {})
        return p

    # ------------- /market (browse) -------------

    @client.tree.command(name="market", description="View the player market listings.")
    async def market_cmd(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first to create your factory.",
                ephemeral=True
            )

        player = players.get(uid, {})
        money = player.get("money", 0)

        if not market["listings"]:
            embed = discord.Embed(
                title="🏪 Galactic Trade Market",
                description=(
                    "The stalls are quiet… there are **no active listings** right now.\n\n"
                    "Use **`/market_sell`** to list items and kickstart the economy!"
                ),
                color=discord.Color.dark_gray()
            )
            embed.add_field(name="Your Balance", value=f"💵 ${money:,}", inline=False)
            embed.set_footer(text="Tip: farm resources, then sell to other factories.")
            return await interaction.response.send_message(embed=embed, ephemeral=False)

        # Sort newest first (or oldest first if you prefer)
        listings = sorted(market["listings"], key=lambda x: x.get("id", 0))[:10]

        embed = discord.Embed(
            title="🏪 Galactic Trade Market",
            description=(
                "Buy and sell items with other factory owners.\n"
                "• `/market_buy <listing_id>` — buy a listing\n"
                "• `/market_sell` — create a listing\n"
                "• `/market_my` — view your listings\n"
            ),
            color=discord.Color.gold()
        )

        embed.add_field(name="Your Balance", value=f"💵 ${money:,}", inline=False)
        embed.add_field(
            name="Listings Shown",
            value=f"{len(listings)} active offers (max 10 shown)",
            inline=False
        )

        for l in listings:
            seller = l.get("seller")
            seller_mention = f"<@{seller}>" if seller else "Unknown"
            price_per = l.get("price_per", 0)
            qty = l.get("quantity", 0)
            total_price = price_per * qty
            created_ts = l.get("created", 0)
            created_str = f"<t:{created_ts}:R>" if created_ts else "N/A"

            embed.add_field(
                name=f"[ID #{l['id']}] 📦 {l['item']} ×{qty}",
                value=(
                    f"👤 Seller: {seller_mention}\n"
                    f"💰 Price: `${price_per:,}` each (**${total_price:,}** total)\n"
                    f"🕒 Listed: {created_str}"
                ),
                inline=False
            )

        embed.set_footer(text="Use /market_buy <id> to purchase an offer.")
        await interaction.response.send_message(embed=embed, ephemeral=False)

    # ------------- /market_sell -------------

    @client.tree.command(
        name="market_sell",
        description="List an item from your inventory for sale on the player market."
    )
    async def market_sell_cmd(
        interaction: Interaction,
        item: str,
        quantity: app_commands.Range[int, 1, 100000],
        price_per: app_commands.Range[int, 1, 10_000_000]
    ):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first.",
                ephemeral=False
            )

        p = ensure_schema(uid)
        inv = p.setdefault("inventory", {})

        # Normalize key: items are stored exactly as names in inventory
        if item not in inv or inv[item] < quantity:
            return await interaction.response.send_message(
                f"❌ You don't have **{quantity}× {item}** in your inventory.",
                ephemeral=False
            )

        # Remove from inventory and create listing
        inv[item] -= quantity
        if inv[item] <= 0:
            inv.pop(item, None)

        listing_id = market["next_id"]
        market["next_id"] += 1

        listing = {
            "id": listing_id,
            "seller": int(uid),
            "item": item,
            "quantity": quantity,
            "price_per": price_per,
            "created": int(time.time()),
        }
        market["listings"].append(listing)

        # Persist both
        save_market()
        save_data()

        await interaction.response.send_message(
            f"✅ Listed **{quantity}× {item}** on the market.\n"
            f"Listing ID: **#{listing_id}**\n"
            f"Price: **{fmt_price(price_per)}** each "
            f"(**{fmt_price(price_per * quantity)}** total).",
            ephemeral=False
        )

    # ------------- /market_buy -------------

    @client.tree.command(
        name="market_buy",
        description="Buy a listing from the player market."
    )
    async def market_buy_cmd(
        interaction: Interaction,
        listing_id: app_commands.Range[int, 1, 1_000_000_000]
    ):
        buyer_id = str(interaction.user.id)
        if not ensure_player(buyer_id):
            return await interaction.response.send_message(
                "Run **/start** first.",
                ephemeral=False
            )

        listing = find_listing(listing_id)
        if not listing:
            return await interaction.response.send_message(
                f"❌ Listing **#{listing_id}** does not exist.",
                ephemeral=False
            )

        seller_id = str(listing["seller"])
        if buyer_id == seller_id:
            return await interaction.response.send_message(
                "❌ You can't buy your **own** listing.",
                ephemeral=False
            )

        buyer = ensure_schema(buyer_id)
        seller = ensure_schema(seller_id)

        total_price = listing["price_per"] * listing["quantity"]
        if buyer.get("money", 0) < total_price:
            return await interaction.response.send_message(
                f"💸 You need **{fmt_price(total_price)}** but only have "
                f"**{fmt_price(buyer.get('money', 0))}**.",
                ephemeral=False
            )

        # Transfer money & items
        buyer["money"] -= total_price
        seller["money"] += total_price

        inv = buyer.setdefault("inventory", {})
        inv[listing["item"]] = inv.get(listing["item"], 0) + listing["quantity"]

        # Remove listing
        try:
            market["listings"].remove(listing)
        except ValueError:
            pass

        save_market()
        save_data()

        await interaction.response.send_message(
            f"✅ You bought **{listing['quantity']}× {listing['item']}** "
            f"from <@{seller_id}> for **{fmt_price(total_price)}**.",
            ephemeral=False
        )

        # Optional: DM seller? (skip for now, would require fetch_user.)

    # ------------- /market_cancel -------------

    @client.tree.command(
        name="market_cancel",
        description="Cancel one of your own market listings and get the items back."
    )
    async def market_cancel_cmd(
        interaction: Interaction,
        listing_id: app_commands.Range[int, 1, 1_000_000_000]
    ):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first.",
                ephemeral=False
            )

        listing = find_listing(listing_id)
        if not listing:
            return await interaction.response.send_message(
                f"❌ Listing **#{listing_id}** does not exist.",
                ephemeral=False
            )

        if str(listing["seller"]) != uid:
            return await interaction.response.send_message(
                "❌ You can only cancel **your own** listings.",
                ephemeral=False
            )

        p = ensure_schema(uid)
        inv = p.setdefault("inventory", {})
        inv[listing["item"]] = inv.get(listing["item"], 0) + listing["quantity"]

        # Remove listing
        try:
            market["listings"].remove(listing)
        except ValueError:
            pass

        save_market()
        save_data()

        await interaction.response.send_message(
            f"✅ Listing **#{listing_id}** cancelled. "
            f"Returned **{listing['quantity']}× {listing['item']}** to your inventory.",
            ephemeral=False
        )

    # ------------- /market_my -------------

    @client.tree.command(
        name="market_my",
        description="View your own active market listings."
    )
    async def market_my_cmd(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message(
                "Run **/start** first.",
                ephemeral=False
            )

        my_listings = [
            l for l in market["listings"] if str(l.get("seller")) == uid
        ]

        if not my_listings:
            return await interaction.response.send_message(
                "You have **no active listings** on the market.\n"
                "Use `/market_sell` to create one.",
                ephemeral=False
            )

        embed = discord.Embed(
            title="📜 Your Market Listings",
            description="Use `/market_cancel <listing_id>` to cancel a listing.",
            color=discord.Color.blurple()
        )

        for l in sorted(my_listings, key=lambda x: x.get("id", 0)):
            total_price = l["price_per"] * l["quantity"]
            created_ts = l.get("created", 0)
            created_str = f"<t:{created_ts}:R>" if created_ts else "N/A"
            embed.add_field(
                name=f"ID #{l['id']} • {l['item']} ×{l['quantity']}",
                value=(
                    f"Price: {fmt_price(l['price_per'])} each "
                    f"(**{fmt_price(total_price)}** total)\n"
                    f"Listed: {created_str}"
                ),
                inline=False
            )

        await interaction.response.send_message(embed=embed, ephemeral=False)
