import discord
from discord import app_commands
from discord.ui import View, Button

from cogs.machine_data import MACHINE_OUTPUTS, MACHINE_DATA


# =====================================================
# 📘 BASE PAGES
# =====================================================

TUTORIAL_PAGES = {
    "start": discord.Embed(
        title="📘 Wacky Factory Tutorial — Getting Started",
        color=0x00A8FF,
        description=(
            "Welcome to **Wacky Factory!**\n\n"
            "**1️⃣ Claim Your Factory** — Use `/start` and then `/factory` to open your control panel.\n"
            "**2️⃣ Run Your Tier 0 Machines** — Start your Junk Shredder, Dirt Sifter, and other starter machines to produce "
            "**Scrap Bits**, **Scrap Metal**, and basic ores.\n"
            "**3️⃣ Craft Your First Parts** — Use `/recipes` and `/craft` to turn scrap & ore into **Scrap Metal**, **Copper Wire**, "
            "and other components.\n"
            "**4️⃣ Sell Extra Items** — Use the dropdown on `/factory` to sell what you don't need and buy better machines.\n"
            "**5️⃣ Aim for a Starter Goal** — Build up a small stockpile of Scrap Metal & Copper Wire; they unlock upgrades and "
            "more machines.\n"
            "**6️⃣ Use Rusty’s Help** — Run `/starter_mission` for guided early jobs, and watch the NPC channel for Rusty’s "
            "material requests.\n"
            "**7️⃣ Upgrade Factory Tier** — More slots + power.\n\n"
            "Use the buttons below to learn specific mechanics ➡️"
        )
    ),

    "tier0": discord.Embed(
        title="🔧 Tier 0 — Starter Machines",
        color=0xFFD400,
        description=(
            "**These machines require little or no fuel and form your early economy.**\n\n"
            "• **Junk Shredder** → Scrap Bits\n"
            "• **Primitive Smelter** → Scrap Bits → Scrap Metal\n"
            "• **Hand Crank Miner** → Iron Ore\n"
            "• **Makeshift Copper Picker** → Copper Ore\n"
            "• **Dirt Sifter** → Chance for Scrap Metal\n\n"
            "Upgrade to Tier 1 ASAP for better income!\n\n"
            "🎯 **Early loop:** let your Tier 0 machines run, then use `/craft` to turn their outputs into **Scrap Metal**, "
            "**Copper Wire**, and other parts before selling."
        )
    ),

    "tier1": discord.Embed(
        title="⛏ Tier 1 — Mining & Basics",
        color=0x55FF55,
        description=(
            "**Tier 1 unlocks real production power.**\n\n"
            "Recommended purchases:\n"
            "• **Coal Drill** — fuels everything else\n"
            "• **Copper Miner** — Copper Ore\n"
            "• **Iron Miner** — Iron Ore\n"
            "• **Basic Furnace** — Molten Scrap\n\n"
            "This tier is all about building a stable resource flow."
        )
    ),

    "crafting": discord.Embed(
        title="🛠 Crafting Basics",
        color=0xFF8800,
        description=(
            "**Crafting is essential for progression.**\n\n"
            "• Unlock new recipes by reaching Factory Tier milestones.\n"
            "• Craft components needed for machines.\n"
            "• Higher tiers require complex ingredients.\n\n"
            "**Early focus for new players:**\n"
            "• Turn **Scrap Bits** into **Scrap Metal**.\n"
            "• Turn **Scrap Metal** / **Copper Ore** into **Copper Wire** and other parts.\n"
            "• Use `/recipes` to browse options and `/craft <item> <amount>` to build them.\n\n"
            "Tip: Store excess scrap & ore — you'll need it later!"
        )
    ),

    "factory": discord.Embed(
        title="🏭 Factory Upgrades",
        color=0xFF44AA,
        description=(
            "**Upgrading your factory increases:**\n"
            "• Machine slots\n"
            "• Power generation\n"
            "• Worker capacity\n\n"
            "At higher tiers you'll also unlock **Facilities** from the `/factory` menu:\n"
            "• Research Lab — advanced items like Rocket Fuel and prototypes\n"
            "• Storage Warehouse — storage workers and extra capacity\n"
            "• Logistics Hub / Shipping Center — high-value shipping contracts\n\n"
            "Upgrade when you feel 'clogged' and can't run all machines."
        )
    ),

    "facilities": discord.Embed(
        title="🏗 Facilities — Lab, Warehouse, Logistics",
        color=0xFEE75C,
        description=(
            "**Facilities are late-game buildings that boost and extend your factory.**\n\n"
            "• **Research Lab** — Craft advanced items like Rocket Fuel and experimental prototypes.\n"
            "  Use it to convert rare resources into powerful consumables and unlock special bonuses.\n\n"
            "• **Storage Warehouse** — Hire Storage Workers to increase your global item capacity.\n"
            "  Higher capacity lets you let machines run longer and stockpile resources safely.\n\n"
            "• **Logistics Hub / Shipping Center** — Take on high-value shipping contracts.\n"
            "  Fulfil orders with your crafted goods for big payouts and unique rewards.\n\n"
            "You'll access Facilities from the `/factory` view once you've progressed far enough."
        )
    ),

    "automation": discord.Embed(
        title="🤖 Automation & Workers",
        color=0xAA66FF,
        description=(
            "**Workers automate everything.**\n\n"
            "• Auto-run machines\n"
            "• Auto-sell outputs\n"
            "• Auto-refuel\n"
            "• Auto-move items\n\n"
            "Unlock workers by upgrading Factory Tier!"
        )
    ),
}

# New: Rusty’s starter mission page
TUTORIAL_PAGES["starter"] = discord.Embed(
    title="🧱 Rusty’s Starter Missions",
    color=0x3498DB,
    description=(
        "Foreman **Rusty** gives you a guided start so you’re not lost.\n\n"
        "• Use **`/starter_mission`** to get a personal task from Rusty.\n"
        "• Missions ask for simple items like **Scrap Metal**, **Copper Wire**, or **Circuit Boards**.\n"
        "• The mission message includes a **Turn in materials** button.\n"
        "• When you have everything, press the button to deliver and get paid.\n\n"
        "Each mission:\n"
        "• Checks your inventory for the required materials\n"
        "• Takes them if you have enough\n"
        "• Pays you money and advances you to the next mission\n\n"
        "Finish all starter missions and Rusty will nudge you toward the bigger factory systems."
    )
)

# New: NPC Orders page
TUTORIAL_PAGES["npc_orders"] = discord.Embed(
    title="📣 NPC Orders — Foreman Rusty’s Requests",
    color=0xE67E22,
    description=(
        "In some servers, Rusty posts **shared NPC orders** in a specific channel.\n\n"
        "• Admins set the channel with **`/npcsetchannel`**.\n"
        "• Every so often, Rusty posts a job like:\n"
        "  “I need **75x Scrap Metal** delivered ASAP!”\n"
        "• Click **“I’ve got the materials”** if you think you can fill it.\n"
        "• If you have enough in your inventory, you deliver the goods and get a big payout.\n\n"
        "Notes:\n"
        "• Only the **first** player to successfully deliver gets the reward.\n"
        "• Orders expire after a while if nobody fills them.\n"
        "• Rusty tracks how many jobs you’ve completed — great for proud factory owners.\n\n"
        "Watch that NPC channel — Rusty’s orders are easy early money if you prepare the right materials."
    )
)


# =====================================================
# 📘 MACHINE TABLE (AUTO-GENERATED)
# =====================================================

machine_table_lines = []
for name, data in MACHINE_OUTPUTS.items():
    machine_table_lines.append(f"**{name}** → {data['qty']}× {data['item']}")

TUTORIAL_PAGES["machines"] = discord.Embed(
    title="🏭 Machine Output Table",
    color=0x00FFAA,
    description="\n".join(machine_table_lines)
)


# =====================================================
# 📘 TIER PROGRESSION CHART (AUTO-GENERATED)
# =====================================================

tier_groups = {}

for name, data in MACHINE_DATA.items():
    tier = data["tier"]
    out_item = list(data["output"].keys())[0]
    out_qty = list(data["output"].values())[0]
    tier_groups.setdefault(tier, []).append(
        f"• **{name}** → {out_qty}× {out_item}"
    )

tier_lines = []
for tier in sorted(tier_groups.keys()):
    tier_lines.append(f"**__Tier {tier} Machines__**\n" + "\n".join(tier_groups[tier]))

TUTORIAL_PAGES["tiers"] = discord.Embed(
    title="📊 Machine Tier Progression Chart",
    color=0x57F287,
    description="\n\n".join(tier_lines)
)


# =====================================================
# 📘 RECOMMENDED PROGRESSION PATH
# =====================================================

TUTORIAL_PAGES["progression"] = discord.Embed(
    title="🧭 Recommended Factory Progression",
    color=0x5865F2,
    description=(
        "**Follow this route for the smoothest progression:**\n\n"

        "### ⭐ Tier 0\n"
        "• Craft early components\n"
        "• Save money → Buy Tier 1 miners\n\n"

        "### 🪨 Tier 1\n"
        "• Coal Drill → Copper Miner → Iron Miner\n"
        "• Start refining (Scrap Metal, Molten Scrap)\n\n"

        "### 🧱 Tier 2\n"
        "• Smelter, Refinery, Lumber Mill\n"
        "• Make Steel Sheets, Refined Copper\n"
        "• Build early machine parts\n\n"

        "### ⚙️ Tier 3\n"
        "• Gear Press, Metal Press, Circuit Board chain\n"
        "• Automation begins (Servo Pack)\n\n"

        "### 🤖 Tier 4\n"
        "• High-tech: Quantum Chips, Gizmos, Drones\n\n"

        "### 🧠 Tier 5\n"
        "• AI Cores, Nanosteel, Fusion materials\n\n"

        "### 🏗 Facilities & Late Game\n"
        "• Build the **Research Lab** for Rocket Fuel and prototypes\n"
        "• Use the **Storage Warehouse** to boost capacity with storage workers\n"
        "• Unlock the **Logistics Hub / Shipping Center** for high-value shipping contracts\n\n"

        "This path avoids bottlenecks and keeps production scaling smoothly."
    )
)


# =====================================================
# 📘 TUTORIAL BUTTON VIEW
# =====================================================

def setup(client, players, save_data, ensure_player):

    class TutorialButton(Button):
        def __init__(self, page: str, label: str, style: discord.ButtonStyle, reward: bool = False):
            super().__init__(label=label, style=style, custom_id=f"tut_{page}")
            self.page = page
            self.reward = reward

        async def callback(self, interaction: discord.Interaction):
            # Swap page embed
            embed = TUTORIAL_PAGES.get(self.page, TUTORIAL_PAGES["start"])
            await interaction.response.edit_message(embed=embed, view=TutorialView())

            # Optional reward for finishing tutorial
            if self.reward:
                uid = str(interaction.user.id)
                if not ensure_player(uid):
                    # Don't spam if they haven't started yet
                    return
                p = players.setdefault(uid, {})
                if not p.get("tutorial_reward_claimed"):
                    p["tutorial_reward_claimed"] = True
                    reward_money = 1500
                    p["money"] = p.get("money", 0) + reward_money
                    workers = p.setdefault("workers", {})
                    workers["money"] = workers.get("money", 0) + 1
                    save_data()
                    await interaction.followup.send(
                        f"🎉 **Tutorial complete!** You earned **${reward_money:,}** "
                        "and **+1 Money Worker** for finishing the tutorial.",
                        ephemeral=False
                    )
                else:
                    await interaction.followup.send(
                        "You've already claimed the tutorial reward.",
                        ephemeral=False
                    )

    class TutorialView(View):
        def __init__(self):
            super().__init__(timeout=None)

            self.add_item(TutorialButton("start",       "Start",         discord.ButtonStyle.primary))
            self.add_item(TutorialButton("tier0",       "Tier 0",        discord.ButtonStyle.secondary))
            self.add_item(TutorialButton("tier1",       "Tier 1",        discord.ButtonStyle.secondary))
            self.add_item(TutorialButton("crafting",    "Crafting",      discord.ButtonStyle.secondary))
            self.add_item(TutorialButton("factory",     "Factory",       discord.ButtonStyle.secondary))
            self.add_item(TutorialButton("facilities",  "Facilities",    discord.ButtonStyle.secondary))
            self.add_item(TutorialButton("automation",  "Automation",    discord.ButtonStyle.secondary))
            self.add_item(TutorialButton("starter",     "Starter Jobs",  discord.ButtonStyle.secondary))
            self.add_item(TutorialButton("npc_orders",  "NPC Orders",    discord.ButtonStyle.secondary))
            self.add_item(TutorialButton("machines",    "Machines",      discord.ButtonStyle.success))
            self.add_item(TutorialButton("tiers",       "Tiers",         discord.ButtonStyle.success))
            # Last page is "Progression" and also triggers the reward
            self.add_item(TutorialButton("progression", "Progression",   discord.ButtonStyle.success, reward=True))

    @client.tree.command(
        name="tutorial",
        description="Post the interactive Wacky Factory tutorial (persistent message)"
    )
    async def tutorial(interaction: discord.Interaction):

        await interaction.response.send_message(
            "Tutorial posted!",
            ephemeral=False
        )

        await interaction.channel.send(
            embed=TUTORIAL_PAGES["start"],
            view=TutorialView()
        )
