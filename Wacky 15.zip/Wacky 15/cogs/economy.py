from discord import app_commands, Interaction
import time

FACTORY_EMOJIS = {1: "🛠️", 2: "⚙️", 3: "🔥", 4: "🚀"}
BASE_CAPACITY = 200

def setup(client, players, save_data, ensure_player):

    def ensure_schema(uid: str):
        p = players.setdefault(uid, {})
        p.setdefault("factory_name", None)
        p.setdefault("tier", 1)
        p.setdefault("money", 0)
        p.setdefault("production", 1)
        p.setdefault("prestige", 0)
        p.setdefault("prestige_mult", 1.0)
        p.setdefault("owned_upgrades", [])
        p.setdefault("inventory", {})
        p.setdefault("machines", {})
        p.setdefault("last_work", 0)

          # Daily + tokens
            # Daily + tokens
        p.setdefault("daily_streak", 0)
        p.setdefault("last_daily", 0)
        p.setdefault("longest_daily_streak", 0)
        p.setdefault("wacky_tokens", 0)

        # Cosmetics
        p.setdefault("owned_titles", [])
        p.setdefault("active_title", None)
        p.setdefault("profile_theme", "default")
        p.setdefault("profile_badges", [])



        p.setdefault("location", "Grasslands")
        p.setdefault("tutorial_stage", 0)

        if not isinstance(p.get("workers"), dict):
            old = int(p.get("workers", 0))
            p["workers"] = {
                "money": old,
                "machine": 0,
                "craft": 0,
                "prestige": 0,
                "storage": 0
            }
        else:
            for key in ["money", "machine", "craft", "prestige", "storage"]:
                p["workers"].setdefault(key, 0)

        return p

    # ----------------------------------------------------
    # /start command
    # ----------------------------------------------------
    @client.tree.command(name="start", description="Start your factory and name it.")
    async def start(interaction: Interaction, name: str):
        uid = str(interaction.user.id)

        if ensure_player(uid):
            return await interaction.response.send_message(
                "You already have a factory! Use **/factory** to open it.",
                ephemeral=True
            )

        # Initialize schema and basic fields
        p = ensure_schema(uid)
        p["factory_name"] = name

        # Starter rewards
        p["money"] = 1000
        inv = p.setdefault("inventory", {})
        inv["Coal"] = inv.get("Coal", 0) + 10

        # Starter machine — Tier 0 Junk Shredder
        machines = p.setdefault("machines", {})
        starter_name = "Junk Shredder"
        m = machines.setdefault(starter_name, {})
        m.setdefault("level", 1)
        m.setdefault("running", False)
        m.setdefault("progress", 0)
        m.setdefault("automation", None)

        # Tutorial progression + default location
        p.setdefault("tutorial_stage", 0)
        p.setdefault("location", "Grasslands")

        save_data()

        await interaction.response.send_message(
            f"🏭 **Factory {name} created!**\n\n"
            f"You received:\n"
            f"• 💵 **$1000**\n"
            f"• ⛏️ **10 Coal**\n\n"
            f"Your starting location is **Grasslands**. You can travel to other regions later from the Travel menu.\n\n"
            f"📋 **Starter Mission 1 — First Scrap Haul**\n"
            f"Collect **30 total** scrap pieces (Scrap Bits + Scrap Metal) in your inventory.\n"
            f"Use **/starter_mission** any time to check your progress and claim your reward.",
            ephemeral=True,
        )

    # ----------------------------------------------------
    # /work command
    # ----------------------------------------------------
    @client.tree.command(name="work", description="Produce goods for money (15 min cooldown).")
    async def work(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")
        p = ensure_schema(uid)

        now = int(time.time())
        last = int(p.get("last_work", 0))
        cd = 15 * 60  # 15 min cooldown

        if now - last < cd:
            remaining = cd - (now - last)
            return await interaction.response.send_message(
                f"⏳ You can work again in **{remaining//60}m {remaining%60}s**."
            )

        p["last_work"] = now

        prestige_workers = p["workers"].get("prestige", 0)
        money_workers = p["workers"].get("money", 0)

        prestige_boost = 1.0 + prestige_workers * 0.01
        money_boost = 1.0 + money_workers * 0.20
        production = p.get("production", 1)

        earned = int(
            production
            * p.get("prestige_mult", 1.0)
            * prestige_boost
            * money_boost
        )

        p["money"] += earned

        capacity = BASE_CAPACITY + p["workers"]["storage"] * 200
        inv = p.setdefault("inventory", {})
        inv_count = sum(inv.values())

        import random
        found_text = ""

        if inv_count < capacity and random.random() < 0.25:
            inv["Coal"] = inv.get("Coal", 0) + 1
            found_text = "\nYou also found **1× Coal**!"

        save_data()

        await interaction.response.send_message(
            f"⚡ Your factory **{p['factory_name']}** worked and earned **${earned}**."
            f"{found_text}\n"
            f"Use **/factory** to manage workers and machines."
        )

    # ----------------------------------------------------
    # /balance command
    # ----------------------------------------------------
    @client.tree.command(name="balance", description="View your factory stats.")
    async def balance(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")
        p = ensure_schema(uid)
        icon = FACTORY_EMOJIS.get(min(p['tier'], 4), '🏭')

        inv_count = sum(p.get('inventory', {}).values())
        capacity = BASE_CAPACITY + p["workers"]["storage"] * 200
        w = p["workers"]

        await interaction.response.send_message(f"""
**{p['factory_name']}** {icon}
Tier: **{p['tier']}**  •  Prestige: **{p['prestige']}** (x{p['prestige_mult']:.2f})
Money: **${p['money']}**
Wacky Tokens: **{p.get('wacky_tokens', 0)}** 🔹
Daily Streak: **{p.get('daily_streak', 0)}** days

Production: **{p['production']} /work**

**Workers**
💵 {w['money']}   ⚙️ {w['machine']}   🧪 {w['craft']}   🌟 {w['prestige']}   📦 {w['storage']}

Inventory: **{inv_count}/{capacity}**
(Use **/factory** for the full control panel.)
""")
