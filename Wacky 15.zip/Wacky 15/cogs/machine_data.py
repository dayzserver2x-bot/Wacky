# cogs/machine_data.py

# ===========================================
# 🚀 WACKY FACTORY MACHINE DATA
# Full tiered machine economy, 1–5
# ===========================================

MACHINE_DATA = {
    # ===== TIER 0 – STARTER MACHINES =====
    "Junk Shredder": {
        "tier": 0,
        "base_time": 90,
        "output": {"Scrap Bits": 1},
        "fuel_per_cycle": 0
    },

    "Primitive Smelter": {
        "tier": 0,
        "base_time": 120,
        "output": {"Scrap Metal": 1},
        "fuel_per_cycle": 1
    },

    "Hand Crank Miner": {
        "tier": 0,
        "base_time": 140,
        "output": {"Iron Ore": 1},
        "fuel_per_cycle": 0
    },

    "Makeshift Copper Picker": {
        "tier": 0,
        "base_time": 150,
        "output": {"Copper Ore": 1},
        "fuel_per_cycle": 0
    },

    "Dirt Sifter": {
        "tier": 0,
        "base_time": 100,
        "output": {"Scrap Metal": 1},
        "fuel_per_cycle": 0
    },


    # ===== TIER 1 – RAW RESOURCE MINING & BASIC PROCESSING =====
    "Coal Drill":        {"tier": 1, "base_time": 60,  "output": {"Coal": 3},            "fuel_per_cycle": 0},
    "Copper Miner":      {"tier": 1, "base_time": 65,  "output": {"Copper Ore": 2},      "fuel_per_cycle": 1},
    "Iron Miner":        {"tier": 1, "base_time": 70,  "output": {"Iron Ore": 2},        "fuel_per_cycle": 2},
    "Stone Digger":      {"tier": 1, "base_time": 75,  "output": {"Stone": 3},           "fuel_per_cycle": 2},
    "Wood Harvester":    {"tier": 1, "base_time": 55,  "output": {"Wood": 3},            "fuel_per_cycle": 0},
    "Water Pump":        {"tier": 1, "base_time": 50,  "output": {"Water": 5},           "fuel_per_cycle": 0},
    "Sand Dredger":      {"tier": 1, "base_time": 80,  "output": {"Sand": 4},            "fuel_per_cycle": 0},
    "Recycler":          {"tier": 1, "base_time": 70,  "output": {"Scrap Bits": 2},      "fuel_per_cycle": 3},
    "Coal Extractor":    {"tier": 1, "base_time": 45,  "output": {"Coal": 4},            "fuel_per_cycle": 1},
    "Copper Extractor":  {"tier": 1, "base_time": 50,  "output": {"Copper Ore": 4},      "fuel_per_cycle": 1},
    "Iron Extractor":    {"tier": 1, "base_time": 55,  "output": {"Iron Ore": 4},        "fuel_per_cycle": 1},
    "Quarry":            {"tier": 1, "base_time": 60,  "output": {"Stone": 5},           "fuel_per_cycle": 1},
    "Wood Chipper":      {"tier": 1, "base_time": 60,  "output": {"Wood": 5},            "fuel_per_cycle": 1},
    "Stone Grinder":     {"tier": 1, "base_time": 70,  "output": {"Crushed Stone": 3},   "fuel_per_cycle": 1},
    "Basic Furnace":     {"tier": 1, "base_time": 75,  "output": {"Molten Scrap": 1},    "fuel_per_cycle": 1},
    "Smolder Kiln":      {"tier": 1, "base_time": 90,  "output": {"Charcoal": 2},        "fuel_per_cycle": 1},
    "Basic Crusher":     {"tier": 1, "base_time": 85,  "output": {"Gravel": 4},          "fuel_per_cycle": 1},
    "Clay Collector":    {"tier": 1, "base_time": 95,  "output": {"Clay": 3},            "fuel_per_cycle": 1},

    # ===== TIER 2 – BASIC SMELTING, REFINING & INDUSTRIAL MINING =====
    "Advanced Quarry":      {"tier": 2, "base_time": 50, "output": {"Stone": 7},           "fuel_per_cycle": 1},
    "Lumber Mill":          {"tier": 2, "base_time": 60, "output": {"Wood Plank": 3},      "fuel_per_cycle": 1},
    "Water Purifier":       {"tier": 2, "base_time": 55, "output": {"Pure Water": 3},      "fuel_per_cycle": 1},
    "Sand Washer":          {"tier": 2, "base_time": 65, "output": {"Refined Sand": 3},    "fuel_per_cycle": 1},
    "Clay Processor":       {"tier": 2, "base_time": 75, "output": {"Refined Clay": 2},    "fuel_per_cycle": 1},
    "Basic Furnace":        {"tier": 2, "base_time": 70, "output": {"Molten Scrap": 2},    "fuel_per_cycle": 2},
    "Smelter":              {"tier": 2, "base_time": 60, "output": {"Scrap Metal": 2},     "fuel_per_cycle": 2},
    "Refinery":             {"tier": 2, "base_time": 65, "output": {"Refined Copper": 2},  "fuel_per_cycle": 2},
    "Alloy Mixer":          {"tier": 2, "base_time": 80, "output": {"Alloy Ingot": 1},     "fuel_per_cycle": 2},
    "Crusher":              {"tier": 2, "base_time": 60, "output": {"Gravel": 6},          "fuel_per_cycle": 1},
    "Stone Grinder":        {"tier": 2, "base_time": 65, "output": {"Crushed Stone": 5},   "fuel_per_cycle": 1},
    "Recycler Plus":        {"tier": 2, "base_time": 50, "output": {"Scrap Bits": 4},      "fuel_per_cycle": 1},
    "Charcoal Kiln":        {"tier": 2, "base_time": 80, "output": {"Charcoal": 4},        "fuel_per_cycle": 2},
    "Oil Separator":        {"tier": 2, "base_time": 85, "output": {"Crude Oil": 2},       "fuel_per_cycle": 2},
    "Fuel Processor":       {"tier": 2, "base_time": 90, "output": {"Refined Fuel": 1},    "fuel_per_cycle": 3},

    # ===== TIER 3 – COMPONENT ASSEMBLY & OIL INDUSTRY =====
    "Gear Press":          {"tier": 3, "base_time": 90,  "output": {"Gear": 2},             "fuel_per_cycle": 2},
    "Servo Forge":         {"tier": 3, "base_time": 120, "output": {"Servo Motor": 1},      "fuel_per_cycle": 2},
    "Solder Bench":        {"tier": 3, "base_time": 75,  "output": {"Circuit Board": 1},    "fuel_per_cycle": 2},
    "Metal Press":         {"tier": 3, "base_time": 85,  "output": {"Steel Sheet": 2},      "fuel_per_cycle": 2},
    "Refined Smelter":     {"tier": 3, "base_time": 70,  "output": {"Steel Ingot": 2},      "fuel_per_cycle": 2},
    "Oil Pump":            {"tier": 3, "base_time": 100, "output": {"Crude Oil": 3},        "fuel_per_cycle": 2},
    "Oil Mixer":           {"tier": 3, "base_time": 90,  "output": {"Lubricant Fluid": 2},  "fuel_per_cycle": 2},
    "Polymerizer":         {"tier": 3, "base_time": 95,  "output": {"Plastic Polymer": 3},  "fuel_per_cycle": 3},
    "Refined Fuel Plant":  {"tier": 3, "base_time": 110, "output": {"Refined Fuel": 2},     "fuel_per_cycle": 3},
    "Robotic Foundry":     {"tier": 3, "base_time": 150, "output": {"Servo Pack": 1},       "fuel_per_cycle": 3},
    "Circuit Assembler":   {"tier": 3, "base_time": 130, "output": {"Advanced Circuit": 1}, "fuel_per_cycle": 3},
    "Frame Forge":         {"tier": 3, "base_time": 140, "output": {"Machine Frame": 1},    "fuel_per_cycle": 3},
    "Component Mill":      {"tier": 3, "base_time": 125, "output": {"Machine Part": 2},     "fuel_per_cycle": 2},

    # ===== TIER 4 – HIGH-TECH MANUFACTURING =====
    "Assembler":          {"tier": 4, "base_time": 70,  "output": {"Gizmo": 1},            "fuel_per_cycle": 3},
    "Microfab Lab":       {"tier": 4, "base_time": 300, "output": {"Quantum Chip": 1},      "fuel_per_cycle": 4},
    "Drone Bay":          {"tier": 4, "base_time": 200, "output": {"Drone": 1},             "fuel_per_cycle": 3},
    "Circuit Printer":    {"tier": 4, "base_time": 90,  "output": {"Circuit Board": 2},     "fuel_per_cycle": 2},
    "Polymer Plant":      {"tier": 4, "base_time": 120, "output": {"Plastic Polymer": 3},   "fuel_per_cycle": 2},
    "Quantum Mixer":      {"tier": 4, "base_time": 250, "output": {"Quantum Alloy": 1},     "fuel_per_cycle": 4},

    # ===== TIER 5 – FUTURISTIC & AI FABRICATION =====
    "Fusion Forge":       {"tier": 5, "base_time": 500, "output": {"Plasma Core": 1},       "fuel_per_cycle": 6},
    "Nano Assembler":     {"tier": 5, "base_time": 600, "output": {"Nanosteel Plate": 2},   "fuel_per_cycle": 8},
    "AI Fabricator":      {"tier": 5, "base_time": 750, "output": {"AI Core": 1},           "fuel_per_cycle": 10},
    "Research Center":    {"tier": 5, "base_time": 900, "output": {"Research Data": 1},     "fuel_per_cycle": 4},
    "Advanced Oil Mixer": {"tier": 5, "base_time": 60,  "output": {"Lubricant Fluid": 5},   "fuel_per_cycle": 3},
    "Quantum Reactor":    {"tier": 5, "base_time": 1200,"output": {"Quantum Energy": 1},    "fuel_per_cycle": 12},
}


# ===== AUTO-GENERATED MACHINE DEFINITIONS WITH BALANCED PRICING =====

def compute_prices(data):
    tier = data["tier"]
    base_buy = 100 + (tier * 200)
    base_upgrade = 80 + (tier * 100)
    fuel_factor = 1 + (data["fuel_per_cycle"] * 0.1)
    speed_factor = max(0.8, 1 - (data["base_time"] / 1000))  # faster machines cost more
    buy_price = int(base_buy * fuel_factor / speed_factor)
    upgrade_price = int(base_upgrade * fuel_factor)
    return buy_price, upgrade_price


MACHINES = {
    name: {
        "min_tier": data["tier"],
        "buy": compute_prices(data)[0],
        "upgrade": compute_prices(data)[1],
    }
    for name, data in MACHINE_DATA.items()
}


# Quick helper for UI dropdown preview
MACHINE_OUTPUTS = {
    name: {"qty": list(data["output"].values())[0], "item": list(data["output"].keys())[0]}
    for name, data in MACHINE_DATA.items()
}

