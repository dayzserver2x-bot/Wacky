import random
from datetime import datetime, timedelta
import json
import os

import discord
from discord.ext import commands, tasks
from discord import app_commands, Interaction

NPC_CONFIG_FILE = "npc_config.json"


# ------------- CONFIG PERSISTENCE HELPERS -------------

def load_npc_config() -> dict[int, dict]:
    if not os.path.exists(NPC_CONFIG_FILE):
        return {}
    try:
        with open(NPC_CONFIG_FILE, "r", encoding="utf-8") as f:
            raw = json.load(f)
        # JSON keys are strings; convert back to int
        return {int(gid): cfg for gid, cfg in raw.items()}
    except json.JSONDecodeError:
        print("Warning: npc_config.json invalid, starting fresh.")
        return {}


def save_npc_config():
    with open(NPC_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump({str(gid): cfg for gid, cfg in npc_config.items()}, f, indent=4)


# Simple in-memory config & orders storage
npc_config: dict[int, dict] = load_npc_config()   # {guild_id: {"channel_id": int}}
npc_orders: dict[int, dict] = {}                  # {guild_id: current_order_dict_or_None}
npc_last_order_at: dict[int, datetime] = {}       # {guild_id: datetime}

# ------------------ RUSTY STARTER MISSIONS ------------------
# Simple 3-step mission chain that leans on existing early-game systems.

RUSTY_MISSIONS = {
    1: {
        "name": "First Scrap Haul",
        "goal_text": "Collect **30 total** scrap pieces (Scrap Bits + Scrap Metal) in your inventory.",
        "reward_money": 1500,
        "reward_items": {"Coal": 10},
    },
    2: {
        "name": "Spin Up the Line",
        "goal_text": "Own at least **3 machines** of any type.",
        "reward_money": 3000,
        "reward_items": {},
    },
    3: {
        "name": "Safety Cushion",
        "goal_text": "Reach at least **$10,000** in your wallet at once.",
        "reward_money": 7000,
        "reward_items": {},
    },
}

MAX_RUSTY_MISSION_STEP = max(RUSTY_MISSIONS.keys())


def get_rusty_progress(player: dict, step: int):
    """
    Return (current_value, target_value, progress_label) for the given mission step.
    Uses existing player fields: inventory, machines, money.
    """
    inv = player.get("inventory", {}) or {}
    machines = player.get("machines", {}) or {}
    money = int(player.get("money", 0) or 0)

    if step == 1:
        scrap_bits = int(inv.get("Scrap Bits", 0) or 0)
        scrap_metal = int(inv.get("Scrap Metal", 0) or 0)
        total = scrap_bits + scrap_metal
        target = 30
        label = f"{total}/{target} scrap pieces"
        return total, target, label

    if step == 2:
        owned = 0
        for m in machines.values():
            if isinstance(m, dict) and m.get("level", 0) >= 1:
                owned += 1
        target = 3
        label = f"{owned}/{target} machines owned"
        return owned, target, label

    if step == 3:
        target = 10_000
        label = f"${money:,}/${target:,}"
        return money, target, label

    # default / fallback – treated as already complete
    return 0, 0, "N/A"


class NpcRequestView(discord.ui.View):
    def __init__(self, cog: "NpcOrders", guild_id: int, order_id: str):
        super().__init__(timeout=None)
        self.cog = cog
        self.guild_id = guild_id
        self.order_id = order_id

    def get_order(self):
        return npc_orders.get(self.guild_id)

    @discord.ui.button(
        label="I’ve got the materials",
        style=discord.ButtonStyle.success,
        emoji="📦",
    )
    async def confirm(self, interaction: Interaction, button: discord.ui.Button):
        order = self.get_order()
        if not order or order.get("claimed"):
            return await interaction.response.send_message(
                "That order has already been fulfilled or expired.",
                ephemeral=True,
            )

        if interaction.guild is None or interaction.guild.id != self.guild_id:
            return await interaction.response.send_message(
                "This order doesn’t belong to this server.",
                ephemeral=True,
            )

        # Make sure the player exists
        uid = str(interaction.user.id)
        if not self.cog.ensure_player(uid):
            return await interaction.response.send_message(
                "You need to run **/start** first before you can fulfill orders.",
                ephemeral=True,
            )

        player = self.cog.players[uid]
        inv = player.setdefault("inventory", {})

        needed_item = order["material_name"]
        needed_amount = order["amount"]
        reward_money = order["reward_money"]

        if inv.get(needed_item, 0) < needed_amount:
            return await interaction.response.send_message(
                f"You don’t have enough **{needed_item}** to fulfill this order.",
                ephemeral=True,
            )

        # Remove items & pay player
        inv[needed_item] -= needed_amount
        player["money"] = player.get("money", 0) + reward_money

        # Mark the order as claimed
        order["claimed"] = True
        self.cog.save_players()

        await interaction.response.send_message(
            f"✅ You delivered **{needed_amount}x {needed_item}** and earned **${reward_money:,}**!",
            ephemeral=True,
        )

        # Edit the original message to show it’s been fulfilled
        channel = interaction.guild.get_channel(order["channel_id"])
        if channel:
            try:
                msg = await channel.fetch_message(order["message_id"])
                embed = msg.embeds[0] if msg.embeds else discord.Embed()
                embed.color = discord.Color.green()
                embed.title = "✅ Order Fulfilled"
                embed.set_footer(text=f"Fulfilled by {interaction.user.display_name}")
                await msg.edit(embed=embed, view=None)
            except discord.NotFound:
                pass


class NpcOrders(commands.Cog):
    """NPC that occasionally posts material requests in a specific channel."""

    def __init__(self, bot, players: dict, save_players, ensure_player):
        self.bot = bot
        self.players = players
        self.save_players = save_players
        self.ensure_player = ensure_player

    def cog_unload(self):
        if self.order_spawner.is_running():
            self.order_spawner.cancel()

    # Helper: choose a material (tiered based on your recipes)
    def random_material(self):
        """
        Returns (material_name, material_id).
        material_name MUST match the key you use in p["inventory"] and RECIPES.
        """

        # TIER 1 – early / common materials
        basic = [
            "Scrap Metal",
            "Copper Wire",
            "Steel Sheet",
            "Iron Plate",
            "Charcoal",
            "Glass",
            "Planks",
            "Concrete Mix",
            "Resin",
            "Silicon Chunk",
        ]

        # TIER 2 – processed / mid-game stuff
        mid = [
            "Refined Copper",
            "Reinforced Plate",
            "Machined Gears",
            "Plastic Panel",
            "High-Grade Glass",
        ]

        # TIER 3 – late-game / advanced
        late = [
            "Circuit Board",
            "Servo Motor",
            "Control Chip",
            "Fusion Cell",
        ]

        roll = random.random()
        if roll < 0.6:
            pool = basic
        elif roll < 0.9:
            pool = mid
        else:
            pool = late

        material_name = random.choice(pool)
        material_id = material_name
        return material_name, material_id

    def pick_target_and_reward(self):
        """
        Decide how many units Rusty wants and how much he’ll pay.
        """
        amount = random.randint(25, 120)
        reward_per = random.randint(20, 40)
        reward_money = amount * reward_per
        return amount, reward_money

    async def spawn_order_for_guild(self, guild: discord.Guild, force: bool = False):
        config = npc_config.get(guild.id)
        if not config:
            # No NPC channel set up
            return

        channel = guild.get_channel(config.get("channel_id", 0))
        if not isinstance(channel, discord.TextChannel):
            return

        now = datetime.utcnow()

        # If there's already an active order that hasn't expired, don't spawn another
        existing = npc_orders.get(guild.id)
        if existing and not force:
            if existing.get("claimed") is False and now <= existing["expires_at"]:
                return

        material_name, material_id = self.random_material()
        amount, reward_money = self.pick_target_and_reward()

        expires_at = datetime.utcnow() + timedelta(hours=2)
        order_id = f"{int(datetime.utcnow().timestamp())}-{random.randint(1000, 9999)}"

        embed = discord.Embed(
            title="📣 Foreman Rusty needs materials!",
            description=(
                f"“We’ve got a rush order on the line! I need **{amount}x {material_name}** "
                f"delivered ASAP.”\n\n"
                f"Reward: **${reward_money:,}**\n"
                f"Expires in **2 hours** or when fulfilled."
            ),
            color=discord.Color.orange(),
        )
        embed.set_footer(text="Press the button below if you can supply the goods.")

        view = NpcRequestView(self, guild.id, order_id)
        msg = await channel.send(embed=embed, view=view)

        npc_orders[guild.id] = {
            "id": order_id,
            "material_name": material_name,
            "material_id": material_id,
            "amount": amount,
            "reward_money": reward_money,
            "expires_at": expires_at,
            "claimed": False,
            "channel_id": channel.id,
            "message_id": msg.id,
        }

        # Record when we last posted an order for this guild
        npc_last_order_at[guild.id] = datetime.utcnow()

    @tasks.loop(minutes=30)
    async def order_spawner(self):
        # Every 30 minutes, each guild has a chance to get an NPC request,
        # but we ensure at least one every ~2 hours per guild.
        await self.bot.wait_until_ready()

        now = datetime.utcnow()

        for guild in self.bot.guilds:
            # 1) If an active, unexpired order exists, skip spawning
            existing = npc_orders.get(guild.id)
            if existing and now <= existing["expires_at"]:
                continue

            # 2) If there was an order but it expired, clear it
            if existing and now > existing["expires_at"]:
                npc_orders[guild.id] = None

            # 3) Safety net: if it's been more than 2 hours since the last order,
            # force a new one.
            last = npc_last_order_at.get(guild.id)
            if last and (now - last) > timedelta(hours=2):
                await self.spawn_order_for_guild(guild)
                continue

            # 4) Otherwise, use randomness (30% chance every 30 minutes)
            if random.random() < 0.3:
                await self.spawn_order_for_guild(guild)

    @order_spawner.before_loop
    async def before_order_spawner(self):
        # Wait for the bot to be fully ready before starting the loop
        await self.bot.wait_until_ready()

    # ---------- COMMANDS ----------

    @app_commands.command(
        name="npcsetchannel",
        description="Set the NPC request channel for this server.",
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def npcsetchannel(self, interaction: Interaction, channel: discord.TextChannel):
        npc_config[interaction.guild.id] = {"channel_id": channel.id}
        save_npc_config()  # persist to npc_config.json

        # Start loop when channel is set (bot is already running here)
        if not self.order_spawner.is_running():
            self.order_spawner.start()

        await interaction.response.send_message(
            f"NPC requests will now be posted in {channel.mention}.",
            ephemeral=True,
        )

    @app_commands.command(
        name="npcstatus",
        description="Show NPC request status for this server.",
    )
    async def npcstatus(self, interaction: Interaction):
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message(
                "This command can only be used inside a server.",
                ephemeral=True,
            )
            return

        now = datetime.utcnow()

        # --- NPC channel info ---
        config = npc_config.get(guild.id)
        if config and (chan_id := config.get("channel_id")):
            channel = guild.get_channel(chan_id)
            if channel is not None:
                channel_str = channel.mention
            else:
                channel_str = f"<#{chan_id}> (channel not found)"
        else:
            channel_str = "Not set"

        # --- Loop status ---
        loop_running = self.order_spawner.is_running()
        loop_str = "✅ Running" if loop_running else "⛔ Stopped"

        # --- Current / last order info ---
        lines: list[str] = []

        current_order = npc_orders.get(guild.id)
        if (
            current_order
            and current_order.get("expires_at") is not None
            and now <= current_order["expires_at"]
        ):
            mat_name = current_order.get("material_name", "Unknown material")
            amount = current_order.get("amount", "?")
            reward = current_order.get("reward_money", 0)

            expires_in = current_order["expires_at"] - now
            mins_left = int(expires_in.total_seconds() // 60)

            lines.append(
                f"Active order: **{amount}x {mat_name}** "
                f"for **${reward:,}**"
            )
            lines.append(f"Expires in **~{mins_left} minutes**.")
        else:
            lines.append("No active NPC order.")

        last_time = npc_last_order_at.get(guild.id)
        if last_time:
            delta = now - last_time
            mins_ago = int(delta.total_seconds() // 60)
            lines.append(f"Last order spawned **{mins_ago} minutes ago**.")
        else:
            lines.append("No NPC orders have been spawned yet.")

        embed = discord.Embed(
            title="🤖 NPC Status",
            color=discord.Color.orange(),
        )
        embed.add_field(name="NPC Channel", value=channel_str, inline=False)
        embed.add_field(name="Order Spawner Loop", value=loop_str, inline=False)
        embed.add_field(
            name="Order Info",
            value="\n".join(lines),
            inline=False,
        )

        await interaction.response.send_message(embed=embed, ephemeral=False)

    @app_commands.command(
        name="npcforceorder",
        description="(Admin) Force Foreman Rusty to post a request.",
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def npcforceorder(self, interaction: Interaction):
        if not self.order_spawner.is_running():
            self.order_spawner.start()

        await self.spawn_order_for_guild(interaction.guild, force=True)
        await interaction.response.send_message(
            "Forced an NPC material request.",
            ephemeral=True,
        )

    @app_commands.command(
        name="starter_mission",
        description="Check your current starter mission from Rusty.",
    )
    async def starter_mission(self, interaction: Interaction):
        uid = str(interaction.user.id)

        # Make sure the player exists
        if not self.ensure_player(uid):
            return await interaction.response.send_message(
                "You need to run **/start** first before Rusty can assign you missions.",
                ephemeral=True,
            )

        player = self.players[uid]

        # Create or load mission state
        state = player.setdefault(
            "rusty_mission",
            {"step": 1, "completed": []},
        )

        step = int(state.get("step", 1) or 1)
        completed = list(state.get("completed", []))

        # All missions done?
        if step > MAX_RUSTY_MISSION_STEP:
            embed = discord.Embed(
                title="✅ Rusty's Starter Missions — All Done!",
                color=discord.Color.green(),
                description=(
                    "You’ve completed all of Rusty’s starter missions.\n\n"
                    "Keep expanding your factory, unlock Facilities, and watch for his "
                    "📣 **NPC material requests** in the configured channel!"
                ),
            )
            embed.set_footer(text="Rusty: “You’re not a rookie anymore, boss.”")
            return await interaction.response.send_message(embed=embed, ephemeral=True)

        mission_def = RUSTY_MISSIONS.get(step)
        progress, target, progress_label = get_rusty_progress(player, step)
        done = target > 0 and progress >= target

        just_completed = False
        reward_summary = ""

        if done and step not in completed:
            # Pay out rewards
            reward_money = int(mission_def.get("reward_money", 0) or 0)
            reward_items = mission_def.get("reward_items", {}) or {}

            if reward_money:
                player["money"] = int(player.get("money", 0) or 0) + reward_money
                reward_summary += f"• 💵 **${reward_money:,}**\n"

            if reward_items:
                inv = player.setdefault("inventory", {})
                for item_name, qty in reward_items.items():
                    inv[item_name] = int(inv.get(item_name, 0) or 0) + qty
                    reward_summary += f"• 📦 **{qty}× {item_name}**\n"

            completed.append(step)
            state["completed"] = completed
            state["step"] = step + 1
            just_completed = True

            # Persist player changes
            self.save_players()

        if just_completed:
            embed = discord.Embed(
                title=f"✅ Starter Mission {step} Complete!",
                color=discord.Color.green(),
                description=(
                    f"**{mission_def['name']}**\n\n"
                    f"You met the goal: {mission_def['goal_text']}\n\n"
                    "**Reward:**\n"
                    f"{reward_summary or 'Rusty pats you on the back.'}"
                ),
            )
            embed.set_footer(
                text="Rusty: “Nice work, rookie. I’ve got another job when you’re ready.”"
            )
        else:
            # Show current mission + progress
            embed = discord.Embed(
                title=f"📋 Starter Mission {step} — {mission_def['name']}",
                color=discord.Color.blurple(),
                description=(
                    f"{mission_def['goal_text']}\n\n"
                    f"**Progress:** {progress_label}"
                ),
            )

            if step > 1 and completed:
                embed.add_field(
                    name="Completed Missions",
                    value=", ".join(str(s) for s in sorted(completed)),
                    inline=False,
                )

            embed.set_footer(
                text="Rusty: “Come back when you’ve hit the goal and I’ll pay up.”"
            )

        await interaction.response.send_message(embed=embed, ephemeral=True)


def setup(client, players, save_players, ensure_player):
    """
    Wire the NPC orders system into the existing client, just like your other cogs.
    """
    npc = NpcOrders(client, players, save_players, ensure_player)

    # Register the slash commands on this client's CommandTree
    client.tree.add_command(npc.npcsetchannel)
    client.tree.add_command(npc.npcforceorder)
    client.tree.add_command(npc.npcstatus)
    client.tree.add_command(npc.starter_mission)
