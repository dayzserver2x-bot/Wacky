from discord import app_commands, Interaction

UPGRADES = {
    # === Tier 0 Modules ===
    "autostart_mk0": {"description": "Automatically starts a machine for 30 minutes.", "cost": {"primitive_circuit": 1, "wire_mk0": 2, "scrap_metal": 3}, "effects": {"autostart_duration": 1800}, "tier_required": 0},
    "lens_module_mk0": {"description": "Displays machine progress, ETA, and cycle information.", "cost": {"glass_lens": 1, "wire_mk0": 1}, "effects": {"enable_progress_ui": True}, "tier_required": 0},
    "durability_monitor_mk0": {"description": "Displays machine durability and warns at low levels.", "cost": {"low_grade_ingot": 1, "scrap_metal": 3}, "effects": {"show_durability": True}, "tier_required": 0},
    "heat_stabilizer_mk0": {"description": "Slightly reduces overheating chance.", "cost": {"glass_lens": 1, "coal": 2, "scrap_metal": 3}, "effects": {"overheat_chance_multiplier": 0.9}, "tier_required": 0},

    # === Tier 0 Upgrades ===
    "t0_speed_tweak": {"description": "+1% machine speed", "cost": {"wire_mk0": 2, "bolts": 3, "scrap_metal": 4}, "effects": {"speed_multiplier": 1.01}, "tier_required": 0},
    "t0_patch_plate": {"description": "+3 max durability", "cost": {"low_grade_ingot": 2, "scrap_metal": 5}, "effects": {"durability_max_increase": 3}, "tier_required": 0},
    "t0_heat_stabilizer": {"description": "Reduces overheating chance", "cost": {"glass_lens": 1, "scrap_metal": 3, "coal": 2}, "effects": {"overheat_chance_multiplier": 0.90}, "tier_required": 0},
    "t0_autostart_module": {"description": "Auto-start for 30 minutes", "cost": {"primitive_circuit": 1, "wire_mk0": 2, "scrap_metal": 3}, "effects": {"autostart_duration": 1800}, "tier_required": 0},

    "Better Tools": {"min_tier": 1, "cost": 100, "type": "production", "value": 1},
    "Coffee Machine": {"min_tier": 1, "cost": 150, "type": "worker_efficiency", "value": 1},
    "Conveyor Belt 3000": {"min_tier": 2, "cost": 500, "type": "production", "value": 3},
    "Motivational Posters": {"min_tier": 2, "cost": 600, "type": "worker_efficiency", "value": 2},
    "Robot Foreman": {"min_tier": 3, "cost": 1500, "type": "worker_speed", "value": 1},
    "QA Scanner": {"min_tier": 3, "cost": 2000, "type": "money_bonus", "value": 0.10},
    "Auto-Oilers": {"min_tier": 4, "cost": 3500, "type": "production", "value": 5},
    "AI Scheduler": {"min_tier": 5, "cost": 8000, "type": "worker_efficiency", "value": 3},
    "Nano-Lubricants": {"min_tier": 7, "cost": 20000, "type": "production", "value": 12},
    "Quantum Router": {"min_tier": 10, "cost": 50000, "type": "money_bonus", "value": 0.25},
}


# Normalize tier fields so tier 0 upgrades with `tier_required` work like others
for _name, _u in UPGRADES.items():
    if "tier_required" in _u and "min_tier" not in _u:
        _u["min_tier"] = _u["tier_required"]


def apply_upgrade(player, upgrade):
    """
    Apply an upgrade to a player profile.

    Supports:
    - Rich "effects" dict (module-style, Tier 0, etc.)
    - Simple "type" / "value" scalar upgrades
    """
    # Rich effect dict support for module-style upgrades
    if "effects" in upgrade:
        effects = upgrade["effects"]
        for key, val in effects.items():
            # additive numeric effects
            if isinstance(val, (int, float)):
                player[key] = player.get(key, 0) + val
            else:
                # non-numeric effects toggle flags (booleans / modes)
                player[key] = val
        return

    # Backwards compatible simple upgrades using type/value
    t = upgrade.get("type")
    val = upgrade.get("value", 0)

    if t == "production":
        player["production"] = player.get("production", 1) + val
    elif t == "worker_efficiency":
        player["worker_efficiency"] = player.get("worker_efficiency", 1) + val
    elif t == "worker_speed":
        player["worker_speed"] = player.get("worker_speed", 1) + val
    elif t == "money_bonus":
        player["money_bonus"] = player.get("money_bonus", 1.0) + val


def setup(client, players, save_data, ensure_player):

    @client.tree.command(name="upgrades", description="View available upgrades for your tier.")
    async def upgrades(interaction: Interaction):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")

        p = players[uid]
        tier = p["tier"]
        lines = []
        for name, u in UPGRADES.items():
            if tier >= u["min_tier"]:
                lines.append(f"- **{name}** — ${u['cost']} (type: {u['type']}, +{u['value']})")
        text = "\n".join(lines) if lines else "No upgrades unlocked yet."
        await interaction.response.send_message(text)

    @client.tree.command(name="buyupgrade", description="Buy an upgrade by name.")
    async def buyupgrade(interaction: Interaction, name: str):
        uid = str(interaction.user.id)
        if not ensure_player(uid):
            return await interaction.response.send_message("Run **/start** first.")
        p = players[uid]

        u = UPGRADES.get(name)
        if not u or p["tier"] < u["min_tier"]:
            return await interaction.response.send_message("Upgrade not available at your tier.")
        if name in p.get("owned_upgrades", []):
            return await interaction.response.send_message("You already own this upgrade.")
        if p["money"] < u["cost"]:
            return await interaction.response.send_message("Not enough money.")

        p["money"] -= u["cost"]
        p.setdefault("owned_upgrades", []).append(name)
        apply_upgrade(p, u)
        save_data()
        await interaction.response.send_message(f"✅ Purchased **{name}**!")
